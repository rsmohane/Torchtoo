@echo off
REM HumanAssist Platform - Windows Startup Script
REM This script starts the HumanAssist API with all necessary services

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║  🚀 HumanAssist Platform - Initializing...                 ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

REM Check if SQL Server is running on Docker
echo ⏳ Checking SQL Server...
docker ps | find "humanassist-db" >nul 2>&1
if errorlevel 1 (
    echo 📦 SQL Server not running. Starting Docker container...
    docker run -d ^
        -e "ACCEPT_EULA=Y" ^
        -e "SA_PASSWORD=YourPassword123!" ^
        -p 1433:1433 ^
        --name humanassist-db ^
        mcr.microsoft.com/mssql/server:2022-latest
    echo ✅ SQL Server started
    timeout /t 5
) else (
    echo ✅ SQL Server is running
)

REM Navigate to application directory
if exist "\tmp\HumanAssist-Release\HumanAssist.dll" (
    set APP_DIR=\tmp\HumanAssist-Release
) else if exist "bin\Release\net8.0\HumanAssist.dll" (
    set APP_DIR=.
) else (
    echo ❌ HumanAssist.dll not found at expected locations
    echo Please build the application first:
    echo   dotnet publish -c Release
    pause
    exit /b 1
)

echo.
echo ⏳ Loading application configuration...

if not exist "%APP_DIR%\appsettings.json" (
    echo ❌ appsettings.json not found!
    echo Please copy appsettings.json to the application directory
    pause
    exit /b 1
)

echo.
echo ════════════════════════════════════════════════════════════
echo 📡 Starting HumanAssist API Server...
echo ════════════════════════════════════════════════════════════
echo.
echo API will be available at: http://localhost:5000
echo Swagger Documentation:   http://localhost:5000/swagger
echo Health Check:             http://localhost:5000/health
echo.
echo Press Ctrl+C to stop the server
echo ════════════════════════════════════════════════════════════
echo.

cd /d "%APP_DIR%"
dotnet HumanAssist.dll

if errorlevel 1 (
    echo.
    echo ❌ Error starting application
    echo Check that:
    echo - SQL Server is accessible
    echo - appsettings.json is properly configured
    echo - Port 5000 is not in use
    pause
    exit /b 1
)

pause
