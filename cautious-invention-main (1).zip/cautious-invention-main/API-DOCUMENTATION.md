# Human Assist Platform - Complete API Documentation

## Overview

The Human Assist Platform is a comprehensive ASP.NET Core + SQL Server solution providing AI-powered assistance with human problem-solving capabilities, security-first design, and multi-language support.

## Table of Contents

1. [Authentication](#authentication)
2. [User Management](#user-management)
3. [Support & Problem Handling](#support--problem-handling)
4. [API Key Management & Monitoring](#api-key-management--monitoring)
5. [Environment Management](#environment-management)
6. [Translation Services](#translation-services)
7. [AI & Code Generation](#ai--code-generation)
8. [Audit & Compliance](#audit--compliance)

---

## Authentication

### Register User
**POST** `/api/auth/register`

**Request:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response:** `200 OK`
```json
{
  "message": "Registration successful",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "User",
    "isActive": true,
    "createdAt": "2026-03-05T10:00:00Z"
  }
}
```

### Login
**POST** `/api/auth/login`

**Request:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

**Response:** `200 OK`
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "base64-encoded-refresh-token",
  "expiresIn": "3600 seconds"
}
```

### Refresh Token
**POST** `/api/auth/refresh-token`

**Request:**
```json
{
  "refreshToken": "base64-encoded-refresh-token"
}
```

**Response:** `200 OK`
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expiresIn": "3600 seconds"
}
```

### Get User Profile
**GET** `/api/auth/profile`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "userId": "1",
  "email": "user@example.com",
  "name": "John Doe",
  "role": "User"
}
```

### Logout
**POST** `/api/auth/logout`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "message": "Logged out successfully"
}
```

---

## Support & Problem Handling

### Get Available Problem Handling Skills
**GET** `/api/support/skills`

**Response:** `200 OK`
```json
{
  "skills": [
    {
      "id": 1,
      "name": "Database Connection Troubleshooting",
      "description": "Diagnose and resolve database connectivity issues",
      "category": "Database",
      "problemType": "Technical",
      "successRate": 95,
      "timeEstimateMinutes": 15,
      "requiredTools": "SQL Server, Diagnostics Tool"
    }
  ]
}
```

### Create Support Ticket
**POST** `/api/support/tickets`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "title": "Cannot connect to database",
  "description": "Getting connection timeout error when accessing production DB",
  "category": "Database",
  "severity": "High"
}
```

**Response:** `201 Created`
```json
{
  "id": 1,
  "userId": 1,
  "title": "Cannot connect to database",
  "description": "Getting connection timeout error when accessing production DB",
  "category": "Database",
  "status": "Open",
  "severity": "High",
  "assignedSkillId": 1,
  "assignedToUserId": 5,
  "createdAt": "2026-03-05T10:00:00Z"
}
```

### Get User Support Tickets
**GET** `/api/support/tickets`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "tickets": [
    {
      "id": 1,
      "title": "Cannot connect to database",
      "status": "In Progress",
      "severity": "High",
      "createdAt": "2026-03-05T10:00:00Z",
      "assignedSkill": {
        "id": 1,
        "name": "Database Connection Troubleshooting"
      }
    }
  ]
}
```

### Get Support Ticket Details
**GET** `/api/support/tickets/{id}`

**Response:** `200 OK`
```json
{
  "id": 1,
  "userId": 1,
  "title": "Cannot connect to database",
  "description": "Getting connection timeout error",
  "category": "Database",
  "status": "In Progress",
  "severity": "High",
  "estimatedResolutionTime": 15,
  "satisfactionScore": 0,
  "conversations": [
    {
      "id": 1,
      "senderUserId": 1,
      "message": "I'm having issues connecting to the database",
      "messageType": "Text",
      "isSolution": false,
      "createdAt": "2026-03-05T10:00:00Z"
    }
  ]
}
```

### Add Conversation to Ticket
**POST** `/api/support/tickets/{id}/conversation`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "message": "Try checking the firewall rules",
  "messageType": "Text",
  "isSolution": false
}
```

**Response:** `201 Created`

### Update Support Ticket
**PUT** `/api/support/tickets/{id}`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "status": "Resolved",
  "severity": "Medium",
  "resolutionNotes": "Updated firewall rules to allow DB connection"
}
```

**Response:** `204 No Content`

### Get Open Support Tickets (Assistants Only)
**GET** `/api/support/tickets/open`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "tickets": [
    {
      "id": 1,
      "title": "Cannot connect to database",
      "severity": "Critical",
      "user": { "id": 1, "email": "user@example.com" }
    }
  ]
}
```

---

## API Key Management & Monitoring

### Generate API Key
**POST** `/api/apikeys/generate`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "name": "Production Mobile App",
  "permissions": "read,write"
}
```

**Response:** `200 OK`
```json
{
  "key": "ha_prod_mobile_abc123xyz789...",
  "message": "API key generated successfully"
}
```

### Get User API Keys
**GET** `/api/apikeys`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "keys": [
    {
      "id": 1,
      "name": "Production Mobile App",
      "permissions": "read,write",
      "isActive": true,
      "createdAt": "2026-03-05T10:00:00Z",
      "expiresAt": "2027-03-05T10:00:00Z",
      "lastUsedAt": "2026-03-05T15:30:00Z",
      "key": "***abc123xyz789"
    }
  ]
}
```

### Revoke API Key
**DELETE** `/api/apikeys/{keyId}`

**Header:** `Authorization: Bearer <token>`

**Response:** `204 No Content`

### Check API Key Health
**GET** `/api/apikeymonitoring/{keyId}/health`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "healthy": true,
  "message": "Healthy - 99.5% success rate, 245ms avg response time"
}
```

### Get API Key Metrics
**GET** `/api/apikeymonitoring/{keyId}/metrics`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "apiKeyId": 1,
  "requestsToday": 1250,
  "successfulRequests": 1243,
  "failedRequests": 7,
  "successRate": 0.9944,
  "averageResponseTimeMs": 245.6,
  "daysActive": 45,
  "lastUsedAt": "2026-03-05T15:30:00Z",
  "isActive": true,
  "expiresAt": "2027-03-05T10:00:00Z"
}
```

### Get API Key Statistics
**GET** `/api/apikeymonitoring/statistics`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "statistics": [
    {
      "id": 1,
      "apiKeyId": 1,
      "requestsCount": 5000,
      "successfulRequests": 4980,
      "failedRequests": 20,
      "averageResponseTimeMs": 250.5,
      "dateFrom": "2026-03-05T00:00:00Z",
      "dateTo": "2026-03-05T23:59:59Z"
    }
  ]
}
```

### Record API Key Usage
**POST** `/api/apikeymonitoring/{keyId}/record-usage`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "success": true,
  "responseTimeMs": 245
}
```

**Response:** `200 OK`

### Get API Key Dashboard
**GET** `/api/apikeymonitoring/dashboard`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "totalApiKeys": 5,
  "activeApiKeys": 4,
  "totalRequests": 25000,
  "successfulRequests": 24800,
  "failedRequests": 200,
  "avgResponseTime": 245.5,
  "statistics": [...]
}
```

---

## Environment Management

### Create Environment
**POST** `/api/environments`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "name": "Production",
  "type": "Production",
  "environmentUrl": "https://api.prod.example.com",
  "description": "Main production environment"
}
```

**Response:** `201 Created`
```json
{
  "id": 1,
  "userId": 1,
  "name": "Production",
  "type": "Production",
  "environmentUrl": "https://api.prod.example.com",
  "description": "Main production environment",
  "isActive": true,
  "createdAt": "2026-03-05T10:00:00Z"
}
```

### Get User Environments
**GET** `/api/environments`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "environments": [
    {
      "id": 1,
      "name": "Production",
      "type": "Production",
      "environmentUrl": "https://api.prod.example.com",
      "description": "Main production environment",
      "isActive": true,
      "createdAt": "2026-03-05T10:00:00Z",
      "lastAccessedAt": "2026-03-05T15:30:00Z"
    }
  ]
}
```

### Get Environment Details
**GET** `/api/environments/{id}`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`

### Update Environment
**PUT** `/api/environments/{id}`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "name": "Production Updated",
  "environmentUrl": "https://api.prod-v2.example.com",
  "description": "Updated production environment"
}
```

**Response:** `204 No Content`

### Delete Environment
**DELETE** `/api/environments/{id}`

**Header:** `Authorization: Bearer <token>`

**Response:** `204 No Content`

### Set Environment Variables
**POST** `/api/environments/{id}/variables`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "DATABASE_URL": "Server=prod-db.example.com",
  "API_KEY": "secret-key-123",
  "LOG_LEVEL": "INFO"
}
```

**Response:** `204 No Content`

### Get Environment Variables
**GET** `/api/environments/{id}/variables`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "variables": {
    "DATABASE_URL": "Server=prod-db.example.com",
    "API_KEY": "***secret***",
    "LOG_LEVEL": "INFO"
  }
}
```

### Get Environment Access Logs
**GET** `/api/environments/{id}/access-logs`

**Header:** `Authorization: Bearer <token>`

**Query Parameters:**
- `fromDate` (optional): `2026-03-01T00:00:00Z`
- `toDate` (optional): `2026-03-05T23:59:59Z`

**Response:** `200 OK`
```json
{
  "logs": [
    {
      "id": 1,
      "environmentId": 1,
      "userId": 1,
      "action": "Read",
      "resourceAccessed": "database_config",
      "ipAddress": "192.168.1.100",
      "success": true,
      "createdAt": "2026-03-05T15:30:00Z"
    }
  ]
}
```

### Log Environment Access
**POST** `/api/environments/{id}/log-access`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "action": "Read",
  "resourceAccessed": "database_config",
  "success": true
}
```

**Response:** `200 OK`

---

## Translation Services

### Translate Text
**POST** `/api/translation/translate`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "text": "Hello, how can I help you?",
  "sourceLanguage": "en",
  "targetLanguage": "es"
}
```

**Response:** `200 OK`
```json
{
  "translatedText": "Hola, ¿cómo puedo ayudarte?",
  "sourceLanguage": "en",
  "targetLanguage": "es"
}
```

### Get Supported Languages
**GET** `/api/translation/languages`

**Response:** `200 OK`
```json
{
  "languages": [
    {
      "id": 1,
      "languageCode": "en",
      "languageName": "English",
      "nativeName": "English",
      "isActive": true,
      "nativeSpeakers": 1500000000
    },
    {
      "id": 2,
      "languageCode": "es",
      "languageName": "Spanish",
      "nativeName": "Español",
      "isActive": true,
      "nativeSpeakers": 500000000
    }
  ]
}
```

### Batch Translate
**POST** `/api/translation/batch-translate`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "texts": [
    "Hello",
    "Good morning",
    "How are you?"
  ],
  "sourceLanguage": "en",
  "targetLanguage": "fr"
}
```

**Response:** `200 OK`
```json
{
  "results": [
    {
      "originalText": "Hello",
      "translatedText": "Bonjour",
      "success": true
    },
    {
      "originalText": "Good morning",
      "translatedText": "Bon matin",
      "success": true
    },
    {
      "originalText": "How are you?",
      "translatedText": "Comment allez-vous ?",
      "success": true
    }
  ]
}
```

### Set Language Preference
**POST** `/api/translation/preferences`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "preferredLanguage": "es",
  "secondaryLanguage": "en"
}
```

**Response:** `200 OK`
```json
{
  "message": "Language preference updated"
}
```

### Get Language Preference
**GET** `/api/translation/preferences`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "id": 1,
  "userId": 1,
  "preferredLanguageCode": "es",
  "secondaryLanguageCode": "en",
  "autoTranslate": false,
  "showOriginalText": true,
  "createdAt": "2026-03-05T10:00:00Z"
}
```

---

## AI & Code Generation

### Generate Response with AI
**POST** `/api/ai/generate-response`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "prompt": "How do I optimize database queries?"
}
```

**Response:** `200 OK`
```json
{
  "response": "To optimize database queries, consider: 1. Add appropriate indexes... 2. Use query analysis tools... 3. Normalize your database schema..."
}
```

### Analyze Text with AI
**POST** `/api/ai/analyze`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "text": "The system is experiencing slow response times",
  "analysisType": "RootCause"
}
```

**Response:** `200 OK`
```json
{
  "analysis": "Based on the provided information, potential root causes could include: 1. High database load... 2. Network latency... 3. Application memory issues..."
}
```

### Generate Code
**POST** `/api/ai/generate-code`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "prompt": "Create a C# method to validate email addresses",
  "language": "csharp"
}
```

**Response:** `200 OK`
```json
{
  "code": "public static bool ValidateEmail(string email)\n{\n    try\n    {\n        var addr = new System.Net.Mail.MailAddress(email);\n        return addr.Address == email;\n    }\n    catch\n    {\n        return false;\n    }\n}"
}
```

### Validate Code
**POST** `/api/ai/validate-code`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "code": "public class Example { public void Method() {} }",
  "language": "csharp"
}
```

**Response:** `200 OK`
```json
{
  "valid": true,
  "message": "Code syntax is valid"
}
```

### Get Code Generation Requests
**GET** `/api/ai/code-requests`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "requests": [
    {
      "id": 1,
      "prompt": "Create email validation method",
      "language": "csharp",
      "status": "Completed",
      "generatedCode": "...",
      "createdAt": "2026-03-05T10:00:00Z",
      "completedAt": "2026-03-05T10:01:00Z"
    }
  ]
}
```

### Get Available AI Tools
**GET** `/api/ai/available-tools`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "tools": [
    "OpenAI",
    "CodeAnalysis",
    "DataProcessing",
    "InternetSearch"
  ]
}
```

### Execute AI Tool
**POST** `/api/ai/execute-tool/{toolId}`

**Header:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "input": "search for latest ASP.NET Core best practices"
}
```

**Response:** `200 OK`
```json
{
  "result": "Here are the latest ASP.NET Core best practices..."
}
```

---

## Audit & Compliance

### Get Audit Logs (Admin Only)
**GET** `/api/audit`

**Header:** `Authorization: Bearer <token>`

**Query Parameters:**
- `userId` (optional): `1`
- `fromDate` (optional): `2026-03-01T00:00:00Z`
- `toDate` (optional): `2026-03-05T23:59:59Z`

**Response:** `200 OK`
```json
{
  "logs": [
    {
      "id": 1,
      "userId": 1,
      "action": "Login",
      "entityType": "User",
      "changes": "user@example.com",
      "ipAddress": "192.168.1.100",
      "createdAt": "2026-03-05T10:00:00Z"
    }
  ],
  "count": 150
}
```

### Get Specific Audit Log
**GET** `/api/audit/{logId}`

**Header:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

## Error Handling

All endpoints return standard HTTP status codes:

- `200 OK` - Successful request
- `201 Created` - Resource created successfully
- `204 No Content` - Successful operation with no content to return
- `400 Bad Request` - Invalid request parameters
- `401 Unauthorized` - Missing or invalid authentication
- `403 Forbidden` - Access denied
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

### Error Response Format

```json
{
  "error": "Description of what went wrong",
  "details": "Additional error information if available"
}
```

---

## Security Best Practices

1. **API Keys**: Store securely, never commit to version control
2. **Tokens**: Always use HTTPS, include token in Authorization header
3. **Environment Variables**: Use encrypted storage for sensitive data
4. **Rate Limiting**: Implement per-API-key rate limiting
5. **Audit Logging**: All actions are logged for compliance

---

## Rate Limiting

- **Default**: 60 requests per minute
- **API Key Limit**: 1000 requests per day (configurable)

---

## Webhooks & Notifications

Coming soon - Real-time support ticket updates and AI analysis results

---

## Support

For API support, create a support ticket through the platform or contact: support@humanassist.example.com
