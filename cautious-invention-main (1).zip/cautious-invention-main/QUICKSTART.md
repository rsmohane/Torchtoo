# Quick Start Guide - Human Assist Platform

Get the platform up and running in minutes!

## 🚀 Quick Start with Docker

The easiest and fastest way to get started:

```bash
# Clone and navigate to the project
cd /workspaces/cautious-invention

# Start all services (SQL Server + API)
docker-compose up -d

# Wait for services to initialize (30-60 seconds)

# Access the API
# Swagger UI: http://localhost:5000/swagger
# Health Check: http://localhost:5000/health
```

## 💻 Manual Setup (Local Development)

### Prerequisites
- .NET 8.0 SDK installed
- SQL Server 2019+ installed locally

### Step 1: Install Dependencies
```bash
dotnet restore
```

### Step 2: Configure Database
Edit `appsettings.json` and update the connection string:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=YOUR_SERVER_NAME;Database=HumanAssistDB;User Id=YOUR_USER;Password=YOUR_PASSWORD;Encrypt=false;TrustServerCertificate=true;"
}
```

### Step 3: Create Database
```bash
# Create initial migration
dotnet ef migrations add InitialCreate

# Apply database migrations
dotnet ef database update
```

### Step 4: Run the Application
```bash
dotnet run
```

The API will be available at: `http://localhost:5000`

## 🧪 Test the API

### Create a User
```bash
curl -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "phoneNumber": "+1234567890",
    "role": "User"
  }'
```

### Create an Assistance Request
First, note the user ID from the previous request (e.g., 1):

```bash
curl -X POST http://localhost:5000/api/assistancerequests \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "title": "Need help with account",
    "description": "I cannot access my account",
    "category": "Account",
    "priority": "High"
  }'
```

### Get All Requests
```bash
curl http://localhost:5000/api/assistancerequests
```

### Add a Conversation
```bash
curl -X POST http://localhost:5000/api/conversations \
  -H "Content-Type: application/json" \
  -d '{
    "assistanceRequestId": 1,
    "senderUserId": 1,
    "message": "Please help me reset my password",
    "messageType": "Text"
  }'
```

## 📊 Access Swagger Documentation

Open your browser and navigate to:
```
http://localhost:5000/swagger
```

You can test all API endpoints directly from the Swagger UI!

## 🛑 Stop Services

### Docker
```bash
docker-compose down
```

### Local Development
Press `Ctrl+C` in the terminal running `dotnet run`

## 📁 Project Structure

```
Folder          Purpose
─────────────────────────────────────────────
Models/         Entity models (User, Request, etc.)
Data/           Database context & migrations
Controllers/    API endpoints
Services/       Business logic (for future use)
Properties/     Launch settings
```

## 🔧 Useful Commands

### Create a New Migration
```bash
dotnet ef migrations add [NameOfMigration]
```

### Database Operations
```bash
# Update database to latest migration
dotnet ef database update

# Revert to previous migration
dotnet ef database update [PreviousMigration]

# Remove last migration
dotnet ef migrations remove
```

### Build & Publish
```bash
# Build the project
dotnet build

# Publish for production
dotnet publish -c Release
```

## 🐛 Troubleshooting

### Database Connection Issues
- Verify connection string in `appsettings.json`
- Ensure SQL Server is running: `sqlcmd -S localhost -U sa`
- Check firewall settings

### Port Already in Use
- Change port in `docker-compose.yml` or `launchSettings.json`
- Kill process: `lsof -i :5000` (macOS/Linux) or `netstat -ano | findstr :5000` (Windows)

### Migration Issues
```bash
# Reset database (warning: loses data)
dotnet ef database drop
dotnet ef database update
```

## 📚 Next Steps

1. **Add Authentication**: Implement JWT authentication
2. **Add Authorization**: Role-based access control
3. **Add Validation**: Input validation & error handling
4. **Add Logging**: Advanced logging with Serilog
5. **Add Tests**: Unit and integration tests
6. **Add Frontend**: React/Angular UI for mobile (MOB)

## 📖 Additional Resources

- [ASP.NET Core Documentation](https://docs.microsoft.com/aspnet/core)
- [Entity Framework Core](https://docs.microsoft.com/ef/core)
- [SQL Server Documentation](https://docs.microsoft.com/sql)
- [Docker Documentation](https://docs.docker.com)

## 💡 Tips

- Use Postman or Insomnia for advanced API testing
- Monitor SQL Server with SQL Server Management Studio
- Check logs with: `docker-compose logs -f api`
- Use `dotnet watch run` for hot reload during development

---

**Happy coding! 🎉**
