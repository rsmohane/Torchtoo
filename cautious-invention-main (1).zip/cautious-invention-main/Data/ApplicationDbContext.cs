using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using EnvironmentModel = HumanAssist.Models.Environment;

namespace HumanAssist.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; }
    public DbSet<AssistanceRequest> AssistanceRequests { get; set; }
    public DbSet<Conversation> Conversations { get; set; }
    public DbSet<AuthUser> AuthUsers { get; set; }
    public DbSet<ApiKey> ApiKeys { get; set; }
    public DbSet<AuditLog> AuditLogs { get; set; }
    public DbSet<AITool> AITools { get; set; }
    public DbSet<ToolUsageLog> ToolUsageLogs { get; set; }
    public DbSet<CodeGenRequest> CodeGenRequests { get; set; }
    public DbSet<Instruction> Instructions { get; set; }
    public DbSet<InstructionExecution> InstructionExecutions { get; set; }
    public DbSet<ProblemHandlingSkill> ProblemHandlingSkills { get; set; }
    public DbSet<SupportTicket> SupportTickets { get; set; }
    public DbSet<SupportConversation> SupportConversations { get; set; }
    public DbSet<EnvironmentModel> Environments { get; set; }
    public DbSet<EnvironmentAccessLog> EnvironmentAccessLogs { get; set;}
    public DbSet<ApiKeyUsageStatistics> ApiKeyUsageStatistics { get; set; }
    public DbSet<SupportedLanguage> SupportedLanguages { get; set; }
    public DbSet<TranslationCache> TranslationCache { get; set; }
    public DbSet<UserLanguagePreference> UserLanguagePreferences { get; set; }

    // Geolocation DbSets
    public DbSet<UserGeolocationPreference> UserGeolocationPreferences { get; set; }
    public DbSet<UserLocation> UserLocations { get; set; }

    // Audio DbSets
    public DbSet<AudioUsageLog> AudioUsageLogs { get; set; }

    // Image DbSets
    public DbSet<ImageUsageLog> ImageUsageLogs { get; set; }

    // Environment Configuration DbSets
    public DbSet<EnvironmentConfig> EnvironmentConfigs { get; set; }
    public DbSet<EnvironmentAuditLog> EnvironmentAuditLogs { get; set; }
    public DbSet<EnvironmentSecret> EnvironmentSecrets { get; set; }
    public DbSet<EnvironmentMetric> EnvironmentMetrics { get; set; }

    // Image Editing DbSets
    public DbSet<ImageEditLog> ImageEditLogs { get; set; }

    // Translation DbSets
    public DbSet<TranslationQualityLog> TranslationQualityLogs { get; set; }

    // Audio DbSets
    public DbSet<AudioReplacementLog> AudioReplacementLogs { get; set; }

    // Social Authentication DbSets
    public DbSet<SocialAuthUser> SocialAuthUsers { get; set; }

    // Country Environment DbSets
    public DbSet<CountryEnvironment> CountryEnvironments { get; set; }
    public DbSet<CountryWorkProcess> CountryWorkProcesses { get; set; }

    // Cognitive Skills DbSets
    public DbSet<CognitiveProfile> CognitiveProfiles { get; set; }
    public DbSet<WorkCapacity> WorkCapacities { get; set; }
    public DbSet<LearningProfile> LearningProfiles { get; set; }
    public DbSet<ExperienceProfile> ExperienceProfiles { get; set; }
    public DbSet<ExpertiseProfile> ExpertiseProfiles { get; set; }
    public DbSet<NanoTechExpertise> NanoTechExpertises { get; set; }
    public DbSet<RoboticsExpertise> RoboticsExpertises { get; set; }
    public DbSet<AutomationExpertise> AutomationExpertises { get; set; }
    public DbSet<CognitiveSkill> CognitiveSkills { get; set; }

    // Work Process Management DbSets
    public DbSet<WorkProcess> WorkProcesses { get; set; }
    public DbSet<ProcessStep> ProcessSteps { get; set; }
    public DbSet<ProcessMetric> ProcessMetrics { get; set; }
    public DbSet<Situation> Situations { get; set; }
    public DbSet<SituationResponse> SituationResponses { get; set; }
    public DbSet<AutomationRule> AutomationRules { get; set; }
    public DbSet<AutomationExecution> AutomationExecutions { get; set; }
    public DbSet<ProcessOptimization> ProcessOptimizations { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // User configuration
        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Email).IsRequired().HasMaxLength(256);
            entity.Property(e => e.FirstName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.LastName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Role).HasMaxLength(50);
            entity.HasIndex(e => e.Email).IsUnique();
        });

        // AssistanceRequest configuration
        modelBuilder.Entity<AssistanceRequest>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Description).IsRequired();
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.Priority).HasMaxLength(50);
            
            entity.HasOne(e => e.User)
                .WithMany(u => u.AssistanceRequests)
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.AssignedTo)
                .WithMany()
                .HasForeignKey(e => e.AssignedToId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // Conversation configuration
        modelBuilder.Entity<Conversation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Message).IsRequired();
            entity.Property(e => e.MessageType).HasMaxLength(50);

            entity.HasOne(e => e.AssistanceRequest)
                .WithMany(ar => ar.Conversations)
                .HasForeignKey(e => e.AssistanceRequestId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.SenderUser)
                .WithMany()
                .HasForeignKey(e => e.SenderUserId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.AssistantUser)
                .WithMany()
                .HasForeignKey(e => e.AssistantUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // AuthUser configuration
        modelBuilder.Entity<AuthUser>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PasswordHash).IsRequired();
            entity.HasIndex(e => e.UserId).IsUnique();

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ApiKey configuration
        modelBuilder.Entity<ApiKey>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Key).IsRequired().HasMaxLength(500);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.HasIndex(e => e.Key).IsUnique();

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // AuditLog configuration
        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Action).IsRequired().HasMaxLength(100);
            entity.Property(e => e.EntityType).HasMaxLength(100);
            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.CreatedAt);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // AITool configuration
        modelBuilder.Entity<AITool>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Type).HasMaxLength(50);
            entity.HasIndex(e => e.Name).IsUnique();
        });

        // ToolUsageLog configuration
        modelBuilder.Entity<ToolUsageLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.CreatedAt);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.Tool)
                .WithMany(t => t.UsageLogs)
                .HasForeignKey(e => e.ToolId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // CodeGenRequest configuration
        modelBuilder.Entity<CodeGenRequest>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Prompt).IsRequired();
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.HasIndex(e => e.CreatedAt);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Instruction configuration
        modelBuilder.Entity<Instruction>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Category).HasMaxLength(50);

            entity.HasOne(e => e.CreatedBy)
                .WithMany()
                .HasForeignKey(e => e.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // InstructionExecution configuration
        modelBuilder.Entity<InstructionExecution>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.HasIndex(e => e.CreatedAt);

            entity.HasOne(e => e.Instruction)
                .WithMany(i => i.Executions)
                .HasForeignKey(e => e.InstructionId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.ExecutedBy)
                .WithMany()
                .HasForeignKey(e => e.ExecutedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // ProblemHandlingSkill configuration
        modelBuilder.Entity<ProblemHandlingSkill>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Category).HasMaxLength(50);
            entity.Property(e => e.ProblemType).HasMaxLength(50);
            entity.HasIndex(e => e.Category);
        });

        // SupportTicket configuration
        modelBuilder.Entity<SupportTicket>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.Severity).HasMaxLength(50);
            entity.HasIndex(e => e.CreatedAt);
            entity.HasIndex(e => e.Status);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.AssignedSkill)
                .WithMany(s => s.SupportTickets)
                .HasForeignKey(e => e.AssignedSkillId)
                .OnDelete(DeleteBehavior.SetNull);

            entity.HasOne(e => e.AssignedTo)
                .WithMany()
                .HasForeignKey(e => e.AssignedToUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // SupportConversation configuration
        modelBuilder.Entity<SupportConversation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Message).IsRequired();
            entity.Property(e => e.MessageType).HasMaxLength(50);
            entity.HasIndex(e => e.CreatedAt);

            entity.HasOne(e => e.SupportTicket)
                .WithMany(st => st.Conversations)
                .HasForeignKey(e => e.SupportTicketId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.SenderUser)
                .WithMany()
                .HasForeignKey(e => e.SenderUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Environment configuration
        modelBuilder.Entity<EnvironmentModel>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Type).HasMaxLength(50);
            entity.HasIndex(e => e.UserId);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // EnvironmentAccessLog configuration
        modelBuilder.Entity<EnvironmentAccessLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Action).HasMaxLength(50);
            entity.HasIndex(e => e.CreatedAt);
            entity.HasIndex(e => e.EnvironmentId);

            entity.HasOne(e => e.Environment)
                .WithMany(env => env.AccessLogs)
                .HasForeignKey(e => e.EnvironmentId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // ApiKeyUsageStatistics configuration
        modelBuilder.Entity<ApiKeyUsageStatistics>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.ApiKeyId);

            entity.HasOne(e => e.ApiKey)
                .WithMany()
                .HasForeignKey(e => e.ApiKeyId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // SupportedLanguage configuration
        modelBuilder.Entity<SupportedLanguage>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.LanguageCode).IsRequired().HasMaxLength(10);
            entity.Property(e => e.LanguageName).IsRequired().HasMaxLength(50);
            entity.HasIndex(e => e.LanguageCode).IsUnique();
        });

        // TranslationCache configuration
        modelBuilder.Entity<TranslationCache>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SourceLanguage).HasMaxLength(10);
            entity.Property(e => e.TargetLanguage).HasMaxLength(10);
            entity.Property(e => e.TranslationProvider).HasMaxLength(50);
        });

        // UserLanguagePreference configuration
        modelBuilder.Entity<UserLanguagePreference>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PreferredLanguageCode).HasMaxLength(10);
            entity.Property(e => e.SecondaryLanguageCode).HasMaxLength(10);
            entity.HasIndex(e => e.UserId).IsUnique();

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // UserGeolocationPreference configuration
        modelBuilder.Entity<UserGeolocationPreference>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.AllowedCountries).HasMaxLength(500);
            entity.HasIndex(e => e.UserId);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // UserLocation configuration
        modelBuilder.Entity<UserLocation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Action).IsRequired().HasMaxLength(100);
            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.RecordedAt);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // AudioUsageLog configuration
        modelBuilder.Entity<AudioUsageLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Action).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Language).IsRequired().HasMaxLength(10);
            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.LoggedAt);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ImageUsageLog configuration
        modelBuilder.Entity<ImageUsageLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Action).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Details).IsRequired();
            entity.HasIndex(e => e.UserId);
            entity.HasIndex(e => e.LoggedAt);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // EnvironmentConfig configuration
        modelBuilder.Entity<EnvironmentConfig>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.EnvironmentName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.EnvironmentType).IsRequired().HasMaxLength(50);
            entity.Property(e => e.DatabaseConnectionString).IsRequired().HasMaxLength(500);
            entity.Property(e => e.ApiBaseUrl).IsRequired().HasMaxLength(500);
            entity.HasIndex(e => new { e.UserId, e.EnvironmentName }).IsUnique();

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // EnvironmentAuditLog configuration
        modelBuilder.Entity<EnvironmentAuditLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Action).IsRequired().HasMaxLength(50);
            entity.HasIndex(e => new { e.UserId, e.EnvironmentName });
            entity.HasIndex(e => e.ChangedAt);
        });

        // EnvironmentSecret configuration
        modelBuilder.Entity<EnvironmentSecret>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SecretName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.EncryptedValue).IsRequired().HasMaxLength(500);
            entity.HasIndex(e => new { e.EnvironmentConfigId, e.SecretName }).IsUnique();
        });

        // EnvironmentMetric configuration
        modelBuilder.Entity<EnvironmentMetric>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.MetricName).IsRequired().HasMaxLength(100);
            entity.HasIndex(e => new { e.EnvironmentConfigId, e.MetricName });
            entity.HasIndex(e => e.RecordedAt);
        });

        // ImageEditLog configuration
        modelBuilder.Entity<ImageEditLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Operation).IsRequired().HasMaxLength(100);
            entity.HasIndex(e => new { e.UserId, e.EditedAt });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // TranslationQualityLog configuration
        modelBuilder.Entity<TranslationQualityLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SourceLanguage).IsRequired().HasMaxLength(10);
            entity.Property(e => e.TargetLanguage).IsRequired().HasMaxLength(10);
            entity.Property(e => e.Mode).HasMaxLength(50);
            entity.Property(e => e.TranslationType).HasMaxLength(50);
            entity.HasIndex(e => new { e.UserId, e.LoggedAt });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // AudioReplacementLog configuration
        modelBuilder.Entity<AudioReplacementLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SourceLanguage).IsRequired().HasMaxLength(10);
            entity.Property(e => e.TargetLanguage).IsRequired().HasMaxLength(10);
            entity.HasIndex(e => new { e.UserId, e.ProcessedAt });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // CountryEnvironment configuration
        modelBuilder.Entity<CountryEnvironment>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.CountryCode).IsRequired().HasMaxLength(3);
            entity.Property(e => e.CountryName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Region).IsRequired().HasMaxLength(50);
            entity.HasIndex(e => e.CountryCode).IsUnique();
            entity.HasIndex(e => e.Region);
        });

        // CountryWorkProcess configuration
        modelBuilder.Entity<CountryWorkProcess>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ProcessName).IsRequired().HasMaxLength(200);
            entity.HasIndex(e => e.CountryEnvironmentId);

            entity.HasOne(e => e.CountryEnvironment)
                .WithMany(c => c.WorkProcesses)
                .HasForeignKey(e => e.CountryEnvironmentId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // CognitiveProfile configuration
        modelBuilder.Entity<CognitiveProfile>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.AssessmentDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // WorkCapacity configuration
        modelBuilder.Entity<WorkCapacity>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.EvaluationDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // LearningProfile configuration
        modelBuilder.Entity<LearningProfile>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.AnalysisDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ExperienceProfile configuration
        modelBuilder.Entity<ExperienceProfile>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.BuildDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ExpertiseProfile configuration
        modelBuilder.Entity<ExpertiseProfile>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Domain).IsRequired().HasMaxLength(100);
            entity.HasIndex(e => new { e.UserId, e.Domain });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // NanoTechExpertise configuration
        modelBuilder.Entity<NanoTechExpertise>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.TrainingDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // RoboticsExpertise configuration
        modelBuilder.Entity<RoboticsExpertise>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.TrainingDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // AutomationExpertise configuration
        modelBuilder.Entity<AutomationExpertise>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.TrainingDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // CognitiveSkill configuration
        modelBuilder.Entity<CognitiveSkill>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SkillName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.SkillCategory).HasMaxLength(50);
            entity.HasIndex(e => new { e.UserId, e.SkillCategory });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // WorkProcess configuration
        modelBuilder.Entity<WorkProcess>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ProcessName).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Category).HasMaxLength(50);
            entity.Property(e => e.Priority).HasMaxLength(20);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.HasIndex(e => new { e.UserId, e.Status });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ProcessStep configuration
        modelBuilder.Entity<ProcessStep>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.StepName).IsRequired().HasMaxLength(200);
            entity.Property(e => e.AssignedRole).HasMaxLength(50);
            entity.HasIndex(e => new { e.ProcessId, e.StepOrder });

            entity.HasOne(e => e.Process)
                .WithMany(p => p.Steps)
                .HasForeignKey(e => e.ProcessId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ProcessMetric configuration
        modelBuilder.Entity<ProcessMetric>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.ProcessId, e.RecordedAt });
            entity.HasIndex(e => new { e.UserId, e.RecordedAt });

            entity.HasOne(e => e.Process)
                .WithMany(p => p.Metrics)
                .HasForeignKey(e => e.ProcessId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Situation configuration
        modelBuilder.Entity<Situation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SituationType).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Urgency).IsRequired().HasMaxLength(20);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.HasIndex(e => new { e.UserId, e.Status });
            entity.HasIndex(e => e.ReportedAt);

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // SituationResponse configuration
        modelBuilder.Entity<SituationResponse>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ResponseType).IsRequired().HasMaxLength(50);
            entity.Property(e => e.Priority).IsRequired().HasMaxLength(20);
            entity.HasIndex(e => new { e.SituationId, e.GeneratedAt });

            entity.HasOne(e => e.Situation)
                .WithMany()
                .HasForeignKey(e => e.SituationId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // AutomationRule configuration
        modelBuilder.Entity<AutomationRule>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.RuleName).IsRequired().HasMaxLength(200);
            entity.Property(e => e.RuleType).IsRequired().HasMaxLength(50);
            entity.HasIndex(e => new { e.UserId, e.IsActive });
            entity.HasIndex(e => e.Priority);

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // AutomationExecution configuration
        modelBuilder.Entity<AutomationExecution>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.HasIndex(e => new { e.RuleId, e.ExecutedAt });
            entity.HasIndex(e => new { e.UserId, e.ExecutedAt });

            entity.HasOne(e => e.Rule)
                .WithMany(r => r.Executions)
                .HasForeignKey(e => e.RuleId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // ProcessOptimization configuration
        modelBuilder.Entity<ProcessOptimization>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.ProcessId, e.OptimizationDate });
            entity.HasIndex(e => new { e.UserId, e.OptimizationDate });

            entity.HasOne<User>()
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // SocialAuthUser configuration
        modelBuilder.Entity<SocialAuthUser>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Provider).IsRequired().HasMaxLength(50);
            entity.Property(e => e.ProviderId).IsRequired().HasMaxLength(500);
            entity.Property(e => e.Email).IsRequired().HasMaxLength(256);
            entity.HasIndex(e => new { e.Provider, e.ProviderId }).IsUnique();
            entity.HasIndex(e => e.UserId);

            entity.HasOne(e => e.User)
                .WithMany()
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
