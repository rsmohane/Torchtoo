# Testing Guide

## Overview

This guide covers unit testing, integration testing, and manual testing for the Human Assistance Platform.

---

## 1. Unit Testing Setup

### Package Dependencies

```bash
cd /workspaces/cautious-invention

# Add testing packages
dotnet add package xunit
dotnet add package xunit.runner.visualstudio
dotnet add package Moq
dotnet add package FluentAssertions
```

### Project Structure

```
Tests/
├── Unit/
│   ├── Services/
│   │   ├── EncryptionServiceTests.cs
│   │   ├── AuthenticationServiceTests.cs
│   │   ├── SupportServiceTests.cs
│   │   ├── TranslationServiceTests.cs
│   │   └── ApiKeyMonitoringServiceTests.cs
│   ├── Controllers/
│   │   ├── AuthControllerTests.cs
│   │   └── SupportControllerTests.cs
│   └── Utilities/
│       └── TestDataBuilder.cs
├── Integration/
│   ├── AuthFlowTests.cs
│   ├── SupportTicketFlowTests.cs
│   └── EnvironmentManagementTests.cs
└── appsettings.test.json
```

---

## 2. Unit Tests

### Encryption Service Tests

```csharp
// Tests/Unit/Services/EncryptionServiceTests.cs
using Xunit;
using FluentAssertions;
using YourApp.Services;

public class EncryptionServiceTests
{
    private readonly EncryptionService _service;

    public EncryptionServiceTests()
    {
        _service = new EncryptionService("test-encryption-key-64-chars-min");
    }

    [Fact]
    public void Encrypt_DecryptRoundTrip_ReturnsSameValue()
    {
        // Arrange
        var originalText = "sensitive-data";

        // Act
        var encrypted = _service.Encrypt(originalText);
        var decrypted = _service.Decrypt(encrypted);

        // Assert
        decrypted.Should().Be(originalText);
    }

    [Fact]
    public void Encrypt_DifferentCalls_ProduceDifferentCiphertexts()
    {
        // Arrange
        var text = "test";

        // Act
        var encrypted1 = _service.Encrypt(text);
        var encrypted2 = _service.Encrypt(text);

        // Assert (due to random IV)
        encrypted1.Should().NotBe(encrypted2);
    }

    [Fact]
    public void HashPassword_VerifyPassword_Succeeds()
    {
        // Arrange
        var password = "SecurePassword123!";

        // Act
        var hash = _service.HashPassword(password);
        var isValid = _service.VerifyPassword(password, hash);

        // Assert
        isValid.Should().BeTrue();
    }

    [Fact]
    public void VerifyPassword_WithWrongPassword_ReturnsFalse()
    {
        // Arrange
        var password = "SecurePassword123!";
        var wrongPassword = "WrongPassword123!";
        var hash = _service.HashPassword(password);

        // Act
        var isValid = _service.VerifyPassword(wrongPassword, hash);

        // Assert
        isValid.Should().BeFalse();
    }
}
```

### Support Service Tests

```csharp
// Tests/Unit/Services/SupportServiceTests.cs
using Xunit;
using FluentAssertions;
using Moq;
using YourApp.Services;
using YourApp.Models;

public class SupportServiceTests
{
    private readonly Mock<IRepository<SupportTicket>> _mockTicketRepo;
    private readonly SupportService _service;

    public SupportServiceTests()
    {
        _mockTicketRepo = new Mock<IRepository<SupportTicket>>();
        _service = new SupportService(_mockTicketRepo.Object);
    }

    [Fact]
    public async Task CreateSupportTicket_WithValidData_ReturnsTicket()
    {
        // Arrange
        var ticket = new SupportTicket
        {
            Title = "Database Issue",
            Description = "Cannot connect",
            Severity = "High",
            Status = "Open"
        };

        _mockTicketRepo.Setup(r => r.AddAsync(It.IsAny<SupportTicket>()))
            .ReturnsAsync(ticket);

        // Act
        var result = await _service.CreateTicketAsync(ticket);

        // Assert
        result.Should().NotBeNull();
        result.Title.Should().Be("Database Issue");
        _mockTicketRepo.Verify(r => r.AddAsync(It.IsAny<SupportTicket>()), Times.Once);
    }

    [Fact]
    public async Task AssignTicket_WithAvailableAssistant_AssignsSuccessfully()
    {
        // Arrange
        var ticketId = 1;
        var assistantId = 5;
        var ticket = new SupportTicket { TicketId = ticketId, Status = "Open" };

        _mockTicketRepo.Setup(r => r.GetByIdAsync(ticketId))
            .ReturnsAsync(ticket);

        // Act
        await _service.AssignTicketAsync(ticketId, assistantId);

        // Assert
        ticket.AssignedToUserId.Should().Be(assistantId);
        _mockTicketRepo.Verify(r => r.UpdateAsync(ticket), Times.Once);
    }
}
```

### API Key Monitoring Tests

```csharp
// Tests/Unit/Services/ApiKeyMonitoringServiceTests.cs
using Xunit;
using FluentAssertions;
using YourApp.Services;
using YourApp.Models;

public class ApiKeyMonitoringServiceTests
{
    [Fact]
    public async Task CheckHealth_WithGoodMetrics_ReturnsHealthy()
    {
        // Arrange
        var stats = new ApiKeyUsageStatistics
        {
            RequestCount = 1000,
            SuccessCount = 990,
            FailureCount = 10,
            AverageResponseTimeMs = 150
        };

        var service = new ApiKeyMonitoringService();

        // Act
        var health = await service.CheckHealthAsync(stats);

        // Assert
        health.IsHealthy.Should().BeTrue();
        health.SuccessRate.Should().Be(99.0);
    }

    [Fact]
    public async Task CheckHealth_WithHighErrorRate_ReturnsUnhealthy()
    {
        // Arrange
        var stats = new ApiKeyUsageStatistics
        {
            RequestCount = 100,
            SuccessCount = 30,  // 30% success rate
            FailureCount = 70,
            AverageResponseTimeMs = 5000  // Very slow
        };

        var service = new ApiKeyMonitoringService();

        // Act
        var health = await service.CheckHealthAsync(stats);

        // Assert
        health.IsHealthy.Should().BeFalse();
        health.SuccessRate.Should().Be(30.0);
        health.Issues.Should().Contain("Success rate below threshold");
    }
}
```

---

## 3. Integration Tests

### Authentication Flow

```csharp
// Tests/Integration/AuthFlowTests.cs
using Xunit;
using FluentAssertions;
using System.Net.Http.Json;
using YourApp.Models;
using YourApp.Dtos;

public class AuthFlowTests : IAsyncLifetime
{
    private readonly HttpClient _httpClient;
    private readonly TestWebApplicationFactory _factory;

    public AuthFlowTests()
    {
        _factory = new TestWebApplicationFactory();
        _httpClient = _factory.CreateClient();
    }

    public async Task InitializeAsync()
    {
        // Setup test database
        await _factory.InitializeAsync();
    }

    public async Task DisposeAsync()
    {
        await _factory.DisposeAsync();
    }

    [Fact]
    public async Task Register_Login_GetProfile_CompletesFlow()
    {
        // Register
        var registerRequest = new RegisterRequest
        {
            Email = "test@example.com",
            Password = "SecurePassword123!",
            FirstName = "John",
            LastName = "Doe"
        };

        var registerResponse = await _httpClient.PostAsJsonAsync(
            "/api/auth/register", 
            registerRequest
        );

        registerResponse.IsSuccessStatusCode.Should().BeTrue();

        // Login
        var loginRequest = new LoginRequest
        {
            Email = "test@example.com",
            Password = "SecurePassword123!"
        };

        var loginResponse = await _httpClient.PostAsJsonAsync(
            "/api/auth/login", 
            loginRequest
        );

        loginResponse.IsSuccessStatusCode.Should().BeTrue();

        var loginData = await loginResponse.Content.ReadAsAsync<LoginResponse>();
        var token = loginData.AccessToken;

        // Get profile
        _httpClient.DefaultRequestHeaders.Authorization = 
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var profileResponse = await _httpClient.GetAsync("/api/auth/profile");
        profileResponse.IsSuccessStatusCode.Should().BeTrue();

        var profile = await profileResponse.Content.ReadAsAsync<UserProfile>();
        profile.Email.Should().Be("test@example.com");
    }
}
```

### Support Ticket Flow

```csharp
// Tests/Integration/SupportTicketFlowTests.cs
[Fact]
public async Task CreateTicket_AssignToAssistant_AddConversation_CompleteFlow()
{
    // Create ticket
    var createTicketRequest = new CreateTicketRequest
    {
        Title = "Cannot connect to database",
        Description = "Production database unreachable",
        Category = "Database",
        Severity = "High"
    };

    var createResponse = await _httpClient.PostAsJsonAsync(
        "/api/support/tickets",
        createTicketRequest,
        _userAuthHeader
    );

    createResponse.IsSuccessStatusCode.Should().BeTrue();
    var ticketData = await createResponse.Content.ReadAsAsync<SupportTicketResponse>();
    var ticketId = ticketData.TicketId;

    // Verify ticket created
    var getResponse = await _httpClient.GetAsync(
        $"/api/support/tickets/{ticketId}",
        _userAuthHeader
    );

    getResponse.IsSuccessStatusCode.Should().BeTrue();

    // Assign to assistant
    var assignResponse = await _httpClient.PutAsJsonAsync(
        $"/api/support/tickets/{ticketId}/assign",
        new { assistantId = _assistantUserId },
        _adminAuthHeader
    );

    assignResponse.IsSuccessStatusCode.Should().BeTrue();

    // Add conversation
    var conversationRequest = new AddConversationRequest
    {
        Message = "Please try restarting the database service",
        MessageType = "Text"
    };

    var conversationResponse = await _httpClient.PostAsJsonAsync(
        $"/api/support/tickets/{ticketId}/conversation",
        conversationRequest,
        _assistantAuthHeader
    );

    conversationResponse.IsSuccessStatusCode.Should().BeTrue();

    // Get ticket with conversations
    var finalResponse = await _httpClient.GetAsync(
        $"/api/support/tickets/{ticketId}",
        _userAuthHeader
    );

    var finalTicket = await finalResponse.Content.ReadAsAsync<SupportTicketResponse>();
    finalTicket.Conversations.Should().HaveCount(1);
    finalTicket.Conversations[0].Message.Should().Contain("database service");
}
```

---

## 4. Manual Testing

### Test Postman Collection

```json
{
  "info": {
    "name": "Human Assistance API",
    "description": "Testing collection for API"
  },
  "item": [
    {
      "name": "Authentication",
      "item": [
        {
          "name": "Register User",
          "request": {
            "method": "POST",
            "url": "http://localhost:5000/api/auth/register",
            "body": {
              "mode": "raw",
              "raw": "{\"email\":\"user@example.com\",\"password\":\"Pass123!\",\"firstName\":\"John\",\"lastName\":\"Doe\"}"
            }
          }
        },
        {
          "name": "Login",
          "request": {
            "method": "POST",
            "url": "http://localhost:5000/api/auth/login",
            "body": {
              "raw": "{\"email\":\"user@example.com\",\"password\":\"Pass123!\"}"
            }
          }
        }
      ]
    },
    {
      "name": "Support Tickets",
      "item": [
        {
          "name": "Create Ticket",
          "request": {
            "method": "POST",
            "url": "http://localhost:5000/api/support/tickets",
            "header": {
              "Authorization": "Bearer {{token}}"
            },
            "body": {
              "raw": "{\"title\":\"API Error\",\"description\":\"Endpoint returning 500\",\"category\":\"API\",\"severity\":\"High\"}"
            }
          }
        }
      ]
    }
  ]
}
```

### Manual Test Cases

#### Test Case 1: API Key Generation and Usage

**Steps:**
1. Register user
2. Login and get token
3. Generate API key: POST `/api/apikeys/generate`
4. Use API key to make authenticated request
5. Check health: GET `/api/apikeymonitoring/{id}/health`

**Expected Result:**
- API key created successfully
- API key works for authentication
- Health shows usage statistics

---

#### Test Case 2: Support Ticket Workflow

**Steps:**
1. User creates support ticket
2. System auto-assigns to available assistant
3. Assistant adds conversation message
4. User marks as solved
5. System records satisfaction score

**Expected Result:**
- Ticket moves through all statuses
- Assistant receives notification
- Conversation logged properly

---

#### Test Case 3: Environment Variable Encryption

**Steps:**
1. Create environment
2. Add variables (DATABASE_URL, API_KEY)
3. Retrieve environment
4. Verify variables are decrypted
5. Check access log

**Expected Result:**
- Variables stored encrypted in database
- Decrypted when retrieved
- All accesses logged with IP address

---

#### Test Case 4: Translation Service

**Steps:**
1. Translate "Hello" from English to Spanish
2. Translate again (should use cache)
3. Batch translate 5 strings
4. Update user language preference
5. Verify cache was used

**Expected Result:**
- Translation returned in target language
- Cache reduces API calls
- Batch translation efficient

---

## 5. Running Tests

### Run All Tests

```bash
dotnet test
```

### Run Specific Test Class

```bash
dotnet test --filter "EncryptionServiceTests"
```

### Run with Code Coverage

```bash
dotnet test /p:CollectCoverage=true /p:CoverageFormat=lcov
```

### Run Integration Tests Only

```bash
dotnet test --filter "Category=Integration"
```

---

## 6. Test Data Builders

```csharp
// Tests/Unit/Utilities/TestDataBuilder.cs
public class SupportTicketBuilder
{
    private var _ticket = new SupportTicket();

    public SupportTicketBuilder()
    {
        _ticket = new SupportTicket
        {
            Title = "Test Ticket",
            Description = "Test Description",
            Category = "General",
            Severity = "Medium",
            Status = "Open",
            UserId = 1
        };
    }

    public SupportTicketBuilder WithTitle(string title)
    {
        _ticket.Title = title;
        return this;
    }

    public SupportTicketBuilder WithSeverity(string severity)
    {
        _ticket.Severity = severity;
        return this;
    }

    public SupportTicket Build()
    {
        return _ticket;
    }
}

// Usage
var ticket = new SupportTicketBuilder()
    .WithTitle("Database Issue")
    .WithSeverity("High")
    .Build();
```

---

## 7. Performance Testing

### Load Test with Apache Bench

```bash
# Send 1000 requests, 10 concurrent
ab -n 1000 -c 10 http://localhost:5000/api/health

# With authentication header
ab -n 1000 -c 10 \
  -H "Authorization: Bearer your-token" \
  http://localhost:5000/api/support/tickets
```

### Test Endpoints for Performance

- GET `/api/support/tickets` (pagination test)
- POST `/api/translation/batch-translate` (large batch)
- GET `/api/apikeymonitoring/dashboard` (aggregation test)

---

## 8. Security Testing

### Test HTTPS Enforcement

```bash
curl -i http://localhost:5000/api/health  # Should redirect to HTTPS
```

### Test Authentication Bypass

```bash
# Should fail without token
curl http://localhost:5000/api/support/tickets

# Should fail with invalid token
curl -H "Authorization: Bearer invalid-token" http://localhost:5000/api/support/tickets
```

### Test Authorization

```bash
# User should not access admin endpoint
curl -H "Authorization: Bearer user-token" http://localhost:5000/api/audit/logs
```

### Test SQL Injection Protection

```bash
# Should be safely escaped
curl "http://localhost:5000/api/support/tickets?title=Test'; DROP TABLE SupportTickets; --"
```

---

## 9. Continuous Integration

### GitHub Actions Workflow

```yaml
# .github/workflows/test.yml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup .NET
      uses: actions/setup-dotnet@v1
      with:
        dotnet-version: '8.0'
    
    - name: Restore dependencies
      run: dotnet restore
    
    - name: Build
      run: dotnet build --no-restore
    
    - name: Test
      run: dotnet test --no-build --verbosity normal
    
    - name: Upload coverage
      uses: codecov/codecov-action@v2
```

---

## 10. Test Coverage Goals

- **Services**: 90%+ coverage (encrypt, auth, support, translation)
- **Controllers**: 80%+ coverage (normal and error paths)
- **Models**: 100% (validate all properties)
- **Utilities**: 100% (all helper functions)

Target overall coverage: **85%+**

---

## Troubleshooting Tests

### Test Database Issues

```bash
# Use in-memory database for tests
var options = new DbContextOptionsBuilder<ApplicationDbContext>()
    .UseInMemoryDatabase("test-db")
    .Options;
```

### Mock Issues

```csharp
// Ensure mocks are configured before test
_mockService.Setup(s => s.Method(It.IsAny<T>()))
    .ReturnsAsync(expectedValue);
```

### Async Test Issues

```csharp
// Always use async/await in async tests
[Fact]
public async Task TestAsync()
{
    var result = await Service.DoSomethingAsync();
    result.Should().NotBeNull();
}
```

---

## Next Steps

1. Create test project structure
2. Implement unit tests for services
3. Add integration tests for API flows
4. Set up CI/CD pipeline
5. Aim for 85%+ code coverage
