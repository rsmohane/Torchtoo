# Deployment Guide

## Overview

Complete production deployment guide for the Human Assistance Platform including Docker, cloud deployment options, and operational procedures.

---

## 1. Pre-Deployment Checklist

- [ ] All tests passing (unit + integration)
- [ ] Code coverage at 80%+
- [ ] Security scan completed (dependencies, secrets, vulnerabilities)
- [ ] Database migrations tested on staging
- [ ] API key credentials configured
- [ ] SSL/TLS certificates obtained
- [ ] Load testing completed
- [ ] Monitoring and alerting configured
- [ ] Backup strategy implemented
- [ ] Disaster recovery plan documented

---

## 2. Docker Deployment

### Dockerfile

```dockerfile
# Dockerfile
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /app

# Copy project files
COPY *.csproj ./
RUN dotnet restore

# Copy source
COPY . ./
RUN dotnet publish -c Release -o /app/publish

# Runtime stage
FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app
COPY --from=build /app/publish .

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s --retries=3 \
    CMD curl -f http://localhost:8080/health || exit 1

EXPOSE 8080
ENTRYPOINT ["dotnet", "HumanAssistanceAPI.dll"]
```

### Docker Compose

```yaml
# docker-compose.yml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "5000:8080"
    environment:
      - ASPNETCORE_ENVIRONMENT=Production
      - ConnectionStrings__DefaultConnection=Server=db;Database=HumanAssistDb;User Id=sa;Password=${SA_PASSWORD};Encrypt=false
      - Jwt__SecretKey=${JWT_SECRET_KEY}
      - Encryption__Key=${ENCRYPTION_KEY}
      - OpenAI__ApiKey=${OPENAI_API_KEY}
      - Translation__GoogleApiKey=${GOOGLE_API_KEY}
    depends_on:
      - db
    restart: always
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  db:
    image: mcr.microsoft.com/mssql/server:2022-latest
    environment:
      - ACCEPT_EULA=Y
      - SA_PASSWORD=${SA_PASSWORD}
    ports:
      - "1433:1433"
    volumes:
      - sqldata:/var/opt/mssql/data
    restart: always
    healthcheck:
      test: ["CMD", "sqlcmd", "-U", "sa", "-P", "${SA_PASSWORD}", "-Q", "SELECT 1"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  sqldata:
```

### Environment Variables (.env)

```bash
# .env file
ASPNETCORE_ENVIRONMENT=Production
SA_PASSWORD=YourComplexPassword123!@#
JWT_SECRET_KEY=your-super-secret-jwt-key-minimum-32-characters
ENCRYPTION_KEY=your-base64-encoded-encryption-key-64-chars
OPENAI_API_KEY=sk-...
GOOGLE_API_KEY=AIza...
```

### Deploy with Docker Compose

```bash
# Build and start services
docker-compose up -d

# View logs
docker-compose logs -f api

# Stop services
docker-compose down

# Scale API replicas (requires load balancer)
docker-compose up -d --scale api=3
```

---

## 3. Azure Deployment

### Azure SQL Database Setup

```bash
# Create resource group
az group create --name humanassist-rg --location eastus

# Create SQL Server
az sql server create \
  --resource-group humanassist-rg \
  --name humanassist-sql-server \
  --admin-user sqladmin \
  --admin-password YourPassword123!@#

# Create database
az sql db create \
  --resource-group humanassist-rg \
  --server humanassist-sql-server \
  --name HumanAssistDb \
  --service-objective S1
```

### Azure App Service Deployment

```bash
# Create App Service Plan
az appservice plan create \
  --name humanassist-plan \
  --resource-group humanassist-rg \
  --sku B2

# Create Web App
az webapp create \
  --resource-group humanassist-rg \
  --plan humanassist-plan \
  --name humanassist-api

# Configure connection string
az webapp config connection-string set \
  --resource-group humanassist-rg \
  --name humanassist-api \
  --settings DefaultConnection="Server=tcp:humanassist-sql-server.database.windows.net,1433;Initial Catalog=HumanAssistDb;Persist Security Info=False;User ID=sqladmin;Password=YourPassword123!@#;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;" \
  --connection-string-type SQLAzure

# Deploy code
az webapp up --name humanassist-api
```

### Azure Key Vault Integration

```bash
# Create key vault
az keyvault create --name humanassist-vault --resource-group humanassist-rg

# Store secrets
az keyvault secret set --vault-name humanassist-vault --name "jwt-secret-key" --value "your-secret"
az keyvault secret set --vault-name humanassist-vault --name "encryption-key" --value "your-encryption-key"
az keyvault secret set --vault-name humanassist-vault --name "openai-api-key" --value "sk-..."

# Configure app to use Key Vault
# In Program.cs:
var keyVaultUrl = new Uri("https://humanassist-vault.vault.azure.net/");
builder.Configuration.AddAzureKeyVault(keyVaultUrl, new DefaultAzureCredential());
```

---

## 4. AWS Deployment

### RDS Database Setup

```bash
# Create RDS SQL Server instance
aws rds create-db-instance \
  --db-instance-identifier humanassist-db \
  --db-instance-class db.t3.micro \
  --engine sqlserver-ex \
  --master-username admin \
  --master-user-password YourPassword123!@# \
  --allocated-storage 20 \
  --region us-east-1
```

### Elastic Beanstalk Deployment

```bash
# Initialize Elastic Beanstalk
eb init humanassist-api --region us-east-1 --platform "Windows Server 2022 running IIS 10.0"

# Create environment
eb create humanassist-api-env

# Configure environment variables
eb setenv JWT_SECRET_KEY="your-secret-key" \
  ENCRYPTION_KEY="your-encryption-key" \
  OPENAI_API_KEY="sk-..."

# Deploy application
eb deploy

# Monitor deployment
eb logs
```

### Auto Scaling Configuration

```yaml
# .ebextensions/autoscaling.config
Resources:
  AutoScalingGroup:
    Type: AWS::AutoScaling::AutoScalingGroup
    Properties:
      MinSize: 2
      MaxSize: 10
      DesiredCapacity: 3
      LaunchConfigurationName: !Ref LaunchConfig
  
  ScaleUpPolicy:
    Type: AWS::AutoScaling::ScalingPolicy
    Properties:
      AdjustmentType: ChangeInCapacity
      AutoScalingGroupName: !Ref AutoScalingGroup
      ScalingAdjustment: 2
      MetricAggregationType: Average
```

---

## 5. Kubernetes Deployment (EKS/AKS)

### Kubernetes Manifests

```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: humanassist

---
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: humanassist-api
  namespace: humanassist
spec:
  replicas: 3
  selector:
    matchLabels:
      app: humanassist-api
  template:
    metadata:
      labels:
        app: humanassist-api
    spec:
      containers:
      - name: api
        image: your-registry.azurecr.io/humanassist:latest
        ports:
        - containerPort: 8080
        env:
        - name: ConnectionStrings__DefaultConnection
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: db-connection
        - name: Jwt__SecretKey
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5

---
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: humanassist-api-service
  namespace: humanassist
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 8080
  selector:
    app: humanassist-api

---
# k8s/hpa.yaml (Horizontal Pod Autoscaler)
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: humanassist-hpa
  namespace: humanassist
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: humanassist-api
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

### Deploy to Kubernetes

```bash
# Create namespace
kubectl apply -f k8s/namespace.yaml

# Create secrets
kubectl create secret generic app-secrets \
  --from-literal=db-connection="Server=..." \
  --from-literal=jwt-secret="..." \
  -n humanassist

# Deploy application
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/hpa.yaml

# Check deployment
kubectl get deployments -n humanassist
kubectl get pods -n humanassist
kubectl get services -n humanassist

# View logs
kubectl logs -f deployment/humanassist-api -n humanassist

# Scale manually if needed
kubectl scale deployment humanassist-api --replicas=5 -n humanassist
```

---

## 6. SSL/TLS Configuration

### Generate Self-Signed Certificate (Development)

```bash
# Generate private key
openssl genrsa -out private.key 2048

# Generate certificate
openssl req -new -x509 -key private.key -out certificate.crt -days 365
```

### Configure HTTPS in Program.cs

```csharp
// Program.cs
if (app.Environment.IsProduction())
{
    // Use HTTPS
    app.UseHsts();
    app.UseHttpsRedirection();
    
    // Load certificate from Key Vault
    var certificatePath = builder.Configuration["Certificates:Path"];
    var certificatePassword = builder.Configuration["Certificates:Password"];
    
    var cert = new X509Certificate2(certificatePath, certificatePassword);
    var webBuilder = builder.WebHost;
    webBuilder.ConfigureKestrel(serverOptions =>
    {
        serverOptions.ListenAnyIP(443, listenOptions =>
        {
            listenOptions.UseHttps(cert);
        });
    });
}
```

---

## 7. Monitoring & Logging

### Application Insights Integration

```csharp
// Program.cs
builder.Services.AddApplicationInsightsTelemetry();

// Log custom events
var telemetry = new TelemetryClient();
telemetry.TrackEvent("SupportTicketCreated", new Dictionary<string, string>
{
    { "Severity", "High" },
    { "Category", "Database" }
});
```

### Health Check Endpoints

```csharp
// Program.cs
builder.Services.AddHealthChecks()
    .AddDbContextCheck<ApplicationDbContext>()
    .AddCheck("OpenAI-Service", new OpenAIHealthCheck())
    .AddCheck("Translation-Service", new TranslationHealthCheck());

app.UseHealthChecks("/health");
app.UseHealthChecks("/ready", new HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready")
});
```

### Structured Logging Configuration

```csharp
// Program.cs
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console(new JsonFormatter())
    .WriteTo.File("logs/app-.txt", 
        rollingInterval: RollingInterval.Day,
        outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} {Level:u3} {Message:lj}{NewLine}{Exception}")
    .Enrich.FromLogContext()
    .Enrich.WithMachineName()
    .Enrich.WithEnvironmentUserName()
    .CreateLogger();

builder.Host.UseSerilog();
```

---

## 8. Backup & Recovery

### Database Backup Strategy

```bash
# Scheduled daily backup to Azure Blob Storage
az sql db export \
  --resource-group humanassist-rg \
  --server humanassist-sql-server \
  --name HumanAssistDb \
  --admin-user sqladmin \
  --admin-password ${PASSWORD} \
  --storage-key ${STORAGE_KEY} \
  --storage-uri "https://storageaccount.blob.core.windows.net/backups/humanassist-$(date +%Y%m%d).bacpac"
```

### Restore from Backup

```bash
# Restore to new database
az sql db import \
  --resource-group humanassist-rg \
  --server humanassist-sql-server \
  --name HumanAssistDb-Restored \
  --admin-user sqladmin \
  --admin-password ${PASSWORD} \
  --storage-key ${STORAGE_KEY} \
  --storage-uri "https://storageaccount.blob.core.windows.net/backups/humanassist-20240101.bacpac"
```

---

## 9. Security Hardening

### Network Security

```yaml
# Azure Network Security Group rules
- name: AllowHTTPS
  protocol: 'Tcp'
  sourcePortRange: '*'
  destinationPortRange: '443'
  sourceAddressPrefix: '*'
  destinationAddressPrefix: '*'
  access: 'Allow'
  priority: 100

- name: DenyHTTP
  protocol: 'Tcp'
  sourcePortRange: '*'
  destinationPortRange: '80'
  sourceAddressPrefix: '*'
  destinationAddressPrefix: '*'
  access: 'Deny'
  priority: 101
```

### WAF Rules

```csharp
// Program.cs - Content Security Policy
app.Use(async (context, next) =>
{
    context.Response.Headers.Add(
        "Content-Security-Policy", 
        "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'");
    context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
    context.Response.Headers.Add("X-Frame-Options", "DENY");
    context.Response.Headers.Add("X-XSS-Protection", "1; mode=block");
    await next.Invoke();
});
```

---

## 10. Performance Optimization

### Caching Strategy

```csharp
// Program.cs
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = builder.Configuration.GetConnectionString("Redis");
});

// In services (example)
var key = $"translation:{sourceLanguage}:{targetLanguage}:{text}";
var cached = await _cache.GetStringAsync(key);

if (cached == null)
{
    var result = await TranslateAsync();
    await _cache.SetStringAsync(key, result, new DistributedCacheEntryOptions
    {
        AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24)
    });
}
```

### Database Query Optimization

```csharp
// Use query batching
var tickets = await context.SupportTickets
    .AsNoTracking()  // Read-only queries
    .Include(t => t.User)
    .Include(t => t.Conversations)
    .Where(t => t.Status == "Open")
    .OrderByDescending(t => t.CreatedAt)
    .Skip((page - 1) * pageSize)
    .Take(pageSize)
    .ToListAsync();
```

---

## 11. Deployment Checklist

Before each deployment:

- [ ] All tests passing
- [ ] Security scan clean
- [ ] Database migration tested
- [ ] Backup created
- [ ] Load testing completed
- [ ] Monitoring configured
- [ ] Team notified
- [ ] Rollback plan documented
- [ ] Environment variables updated
- [ ] SSL certificates valid

---

## 12. Rollback Procedure

If deployment fails:

```bash
# Kubernetes rollback
kubectl rollout undo deployment/humanassist-api -n humanassist

# Azure App Service rollback
az webapp up --slot-swap-source-slot

# Docker Compose
docker-compose down
docker-compose up -d  # Previous version
```

---

## 13. Disaster Recovery

### Recovery Time Objective (RTO): 1 hour
### Recovery Point Objective (RPO): 24 hours

**Steps:**
1. Restore from latest backup
2. Run migrations (if needed)
3. Seed critical data
4. Health check endpoints
5. Run smoke tests
6. Notify users of recovery

---

## Post-Deployment Validation

```bash
#!/bin/bash

# Health check
curl -f http://api.example.com/health || exit 1

# API test
curl -X POST http://api.example.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password"}'

# Database connectivity
curl http://api.example.com/api/support/tickets \
  -H "Authorization: Bearer $TOKEN"

echo "Deployment validation passed!"
```

---

## Support & Escalation

**Deployment Issues:** contact devops@example.com
**Security Concerns:** security@example.com
**Performance Issues:** performance@example.com
