# Admin Account Setup

To bootstrap the GRT HumanAssist platform with a superuser account, use the following environment variables or configuration settings. These are **not hardcoded** for security reasons—you provide them at deployment time.

## Environment Variables

Set the following variables in your `appsettings.json`, Docker compose, or deployment environment:

```json
{
  "Admin": {
    "Email": "admin@yourdomain.com",
    "Password": "StrongP@ssw0rd!"
  }
}
```

Alternatively, export them in the shell (Linux/macOS):

```bash
export Admin__Email="admin@grtassist.com"
export Ahumangrt@714865="StrongP@ssw0rd!"
```

## What Happens at Startup

When the application starts it will:
1. Apply any pending EF Core migrations to the database.
2. Read the `Admin:Email` and `Admin:Password` values from configuration.
3. If an account with that email does **not** exist, it will call the `IAuthenticationService.RegisterAsync` method to create one.
4. Immediately elevate that users `Role` to `Admin` and persist the change.

This process only runs once; subsequent restarts will preserve the admin user.

## Accessing the Admin Panel

1. Run the API server (`dotnet run` or via Docker).
2. Request a JWT token via the `/api/auth/login` endpoint using the admin credentials.
3. Use that token in the `Authorization: Bearer <token>` header to access all endpoints.

> **Important:** change the password after first login and store it securely.

## Additional Security Tips

* Use a secrets manager (Azure Key Vault, AWS Secrets Manager, HashiCorp Vault) for production.
* Rotate the admin password periodically.
* Disable the account or change the password before sharing the database snapshot.

For more details see [`SECURITY-GUIDE.md`](./SECURITY-GUIDE.md) and the documentation in this repository.
