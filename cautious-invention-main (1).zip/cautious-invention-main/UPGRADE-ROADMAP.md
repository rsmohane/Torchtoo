# GRT HumanAssist Upgrade Roadmap

This document summarizes the next steps required to transition the current API into a full industry-grade platform with social access, front‑end applications, mobile clients, and extended automation functionality. It also contains deployment and security guidance.

## 1. Backend Enhancements

### 1.1 Industry & API‑Key Scope

- **Add `Industry` entity** that groups users, API keys, and projects.
- Extend `ApiKey` model with `Scope` and `IndustryId` foreign key.
- Implement `IndustryService` with CRUD operations.
- Restrict API key usage based on scope:
  - `read:data`, `write:data`, `admin:users`, etc.
  - Validate key scopes in middleware or service layer.

### 1.2 Social Authentication & Sharing

- Register OAuth clients (Google, Facebook, Twitter, LinkedIn).
- Add `SocialAuthController` with endpoints to exchange provider tokens.
- Store social profile links in `SocialAuthUser` entity.
- Implement "share to social" endpoints that generate short links and optionally post updates via provider APIs.

### 1.3 User Modes & Automation

- Extend `User` model with `Mode` enum (`Auto`, `Working`, `Support`).
- Add endpoints to toggle mode and audit each change.
- Implement task automation engine or integrate with existing workflow tool (e.g., Hangfire, Quartz.NET) to support `Auto` mode operations.

### 1.4 Google & GitHub API Services

- Create `IGoogleApiService` and `IGitHubService` wrappers for common tasks (e.g. sending email, uploading files, creating repos).
- Use `Google.Apis` NuGet packages and `Octokit` for GitHub.
- Add controllers to expose these actions to authenticated users.

## 2. Front‑End & Mobile Applications

### 2.1 Web Client

- Build using a modern SPA framework (React, Angular, or Vue).
- Implement pages for:
  - Login / registration / social login
  - Admin dashboard
  - Industry and API key management
  - Environment configuration
  - Code review / intelligent assistant UI
  - Image/audio editing tools
- Use token-based auth; store JWT in secure httpOnly cookie or local storage.

### 2.2 Mobile App (Android)

- Prototype with **Flutter** or **React Native** for cross-platform support.
- Mirror critical functionality: login, environment switching, basic AI tools, support ticket submission.
- Authenticate via the API and store tokens securely (Keystore/KSM).

### 2.3 Admin Portal

- Specialized interface with role-checks for elevated operations.
- Include user management, industry configuration, and system health metrics.

## 3. Data & Infrastructure

- Use **SQL Server** or **PostgreSQL** for relational storage as configured.
- Implement Redis or Memcached for caching translation and AI results.
- Use **Kafka** or **RabbitMQ** if you need event-driven automation.
- Support multiple environments (Dev/Staging/Prod) with `EnvironmentConfig` service.

## 4. Deployment Steps

1. **Build** backend: `dotnet publish -c Release -o ./publish`.
2. **Configure** environment variables (see `SETUP-ADMIN.md`).
3. **Provision** database; run migrations (automatic on startup).
4. **Deploy** Docker container using the provided `Dockerfile` or Kubernetes manifests.
5. **Point** your DNS to the load‑balanced service.
6. **Configure** external services (Google, GitHub, SMTP).
7. **Seed** initial data (admin user, supported languages, tools, etc.).

## 5. Security & Compliance

- Always use HTTPS with valid certificates.
- Use a secrets manager for sensitive values.
- Regularly rotate API keys and tokens.
- Implement rate-limiting, IP whitelisting, and DDOS protection.

## 6. Admin Credentials & Contact

- Admin credentials are never committed; they must be configured manually (see `SETUP-ADMIN.md`).
- Customer support and contact information should be placed at `/contact` on the frontend; example email: **info@grt.com**.

## 7. Continuous Integration

- Set up GitHub Actions or Azure DevOps pipelines to run tests, build containers, and deploy.
- Include unit tests for all services (existing tests cover core modules; new features should have corresponding tests).

## 8. Dependency Management

- Keep NuGet packages up to date; `dotnet list package --outdated` shows updates.
- For front-end/mobile, use `npm` / `yarn` / `pub` as appropriate and check for security advisories.

## 9. Next Concrete Tasks (Short‑term)
1. Merge the multi-environment feature and ensure API build passes.
2. Add `Industry` model plus service / controller.
3. Implement Google & GitHub API wrappers and test with dummy commands.
4. Extend authentication to support OAuth providers.
5. Scaffold basic web client and mobile template.
6. Document each step for developers and administrators.

This roadmap is iterative; address items in priority order based on business needs. Feedback and additional requirements should be added to this document as they arise.