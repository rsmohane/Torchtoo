namespace HumanAssist.Models;

public class AssistanceRequest
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Status { get; set; } = "Open"; // Open, In Progress, Resolved, Closed
    public int? AssignedToId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ResolvedAt { get; set; }
    public string Priority { get; set; } = "Medium"; // Low, Medium, High, Critical

    // Navigation properties
    public User? User { get; set; }
    public User? AssignedTo { get; set; }
    public ICollection<Conversation>? Conversations { get; set; }
}
