namespace HumanAssist.Models;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

[Table("CountryEnvironments")]
public class CountryEnvironment
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(3)]
    public string CountryCode { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string CountryName { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Region { get; set; } = string.Empty; // Africa, Americas, Asia, Europe, Oceania

    [StringLength(50)]
    public string? TimeZone { get; set; }

    [StringLength(10)]
    public string? Currency { get; set; }

    [StringLength(10)]
    public string? LanguageCode { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? LegalRequirements { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? TaxRegulations { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? WorkCulture { get; set; }

    public double AutomationLevel { get; set; } = 0.5; // 0.0 to 1.0

    public DateTime CreatedAt { get; set; }

    public DateTime LastModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;

    // Navigation properties
    public virtual ICollection<CountryWorkProcess> WorkProcesses { get; set; } = new List<CountryWorkProcess>();
}

[Table("CountryWorkProcesses")]
public class CountryWorkProcess
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int CountryEnvironmentId { get; set; }

    [Required]
    [StringLength(200)]
    public string ProcessName { get; set; } = string.Empty;

    [Column(TypeName = "nvarchar(max)")]
    public string? Description { get; set; }

    [StringLength(50)]
    public string? Industry { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? ProcessSteps { get; set; } // JSON array of steps

    [Column(TypeName = "nvarchar(max)")]
    public string? RequiredSkills { get; set; } // JSON array of skills

    public double EfficiencyRating { get; set; } = 0.5;

    public DateTime LastUpdated { get; set; }

    // Navigation property
    [ForeignKey("CountryEnvironmentId")]
    public virtual CountryEnvironment? CountryEnvironment { get; set; }
}

[Table("CognitiveProfiles")]
public class CognitiveProfile
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime AssessmentDate { get; set; }

    public double FocusLevel { get; set; } // 0.0 to 1.0

    public double MemoryRetention { get; set; } // 0.0 to 1.0

    public double ProblemSolving { get; set; } // 0.0 to 1.0

    public double Creativity { get; set; } // 0.0 to 1.0

    public double EmotionalIntelligence { get; set; } // 0.0 to 1.0

    public double StressManagement { get; set; } // 0.0 to 1.0

    public double OverallScore { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? AssessmentDetails { get; set; } // JSON with detailed assessment data
}

[Table("WorkCapacities")]
public class WorkCapacity
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime EvaluationDate { get; set; }

    public double ProductivityScore { get; set; } // 0.0 to 1.0

    public double EnduranceLevel { get; set; } // 0.0 to 1.0

    public double TaskCompletionRate { get; set; } // 0.0 to 1.0

    public double MultitaskingAbility { get; set; } // 0.0 to 1.0

    public double TimeManagement { get; set; } // 0.0 to 1.0

    public double OverallCapacity { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? EvaluationDetails { get; set; } // JSON with detailed evaluation data
}

[Table("LearningProfiles")]
public class LearningProfile
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime AnalysisDate { get; set; }

    public double AdaptiveLearningRate { get; set; } // 0.0 to 1.0

    public double KnowledgeRetention { get; set; } // 0.0 to 1.0

    public double SkillAcquisitionSpeed { get; set; } // 0.0 to 1.0

    public double ProblemSolvingImprovement { get; set; } // 0.0 to 1.0

    public double OverallLearningScore { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? LearningActivitiesJson { get; set; } // JSON serialized activities

    // Not mapped to database - computed property
    [NotMapped]
    public List<LearningActivity> LearningActivities
    {
        get => string.IsNullOrEmpty(LearningActivitiesJson) ?
               new List<LearningActivity>() :
               System.Text.Json.JsonSerializer.Deserialize<List<LearningActivity>>(LearningActivitiesJson) ?? new List<LearningActivity>();
        set => LearningActivitiesJson = System.Text.Json.JsonSerializer.Serialize(value);
    }
}

public class LearningActivity
{
    public string ActivityType { get; set; } = string.Empty;
    public double AdaptiveLearningRate { get; set; }
    public double KnowledgeRetention { get; set; }
    public double SkillAcquisitionSpeed { get; set; }
    public double ProblemSolvingImprovement { get; set; }
    public DateTime CompletedAt { get; set; }
}

[Table("ExperienceProfiles")]
public class ExperienceProfile
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime BuildDate { get; set; }

    public double TotalYearsExperience { get; set; }

    public double ExpertiseLevel { get; set; } // 0.0 to 1.0

    public int SkillDiversity { get; set; }

    public bool LeadershipExperience { get; set; }

    public double OverallExperienceScore { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? ExperienceRecordsJson { get; set; } // JSON serialized records

    // Not mapped to database - computed property
    [NotMapped]
    public List<ExperienceRecord> ExperienceRecords
    {
        get => string.IsNullOrEmpty(ExperienceRecordsJson) ?
               new List<ExperienceRecord>() :
               System.Text.Json.JsonSerializer.Deserialize<List<ExperienceRecord>>(ExperienceRecordsJson) ?? new List<ExperienceRecord>();
        set => ExperienceRecordsJson = System.Text.Json.JsonSerializer.Serialize(value);
    }
}

public class ExperienceRecord
{
    public string SkillCategory { get; set; } = string.Empty;
    public double YearsExperience { get; set; }
    public double ExpertiseLevel { get; set; }
    public bool LeadershipRole { get; set; }
    public string Organization { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
}

[Table("ExpertiseProfiles")]
public class ExpertiseProfile
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string Domain { get; set; } = string.Empty;

    public DateTime DevelopmentDate { get; set; }

    public double CurrentLevel { get; set; } // 0.0 to 1.0

    public double TargetLevel { get; set; } // 0.0 to 1.0

    public double ProgressRate { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? DevelopmentPath { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? SkillsDevelopedJson { get; set; } // JSON array of skills

    // Not mapped to database - computed property
    [NotMapped]
    public List<string> SkillsDeveloped
    {
        get => string.IsNullOrEmpty(SkillsDevelopedJson) ?
               new List<string>() :
               System.Text.Json.JsonSerializer.Deserialize<List<string>>(SkillsDevelopedJson) ?? new List<string>();
        set => SkillsDevelopedJson = System.Text.Json.JsonSerializer.Serialize(value);
    }
}

[Table("NanoTechExpertises")]
public class NanoTechExpertise
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime TrainingDate { get; set; }

    public double NanotechnologyKnowledge { get; set; } // 0.0 to 1.0

    public double MaterialScience { get; set; } // 0.0 to 1.0

    public double QuantumMechanics { get; set; } // 0.0 to 1.0

    public double NanoFabrication { get; set; } // 0.0 to 1.0

    public double NanoSensors { get; set; } // 0.0 to 1.0

    public double NanoRobotics { get; set; } // 0.0 to 1.0

    public double OverallExpertise { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? TrainingDetails { get; set; } // JSON with training data
}

[Table("RoboticsExpertises")]
public class RoboticsExpertise
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime TrainingDate { get; set; }

    public double MechanicalEngineering { get; set; } // 0.0 to 1.0

    public double ControlSystems { get; set; } // 0.0 to 1.0

    public double ArtificialIntelligence { get; set; } // 0.0 to 1.0

    public double ComputerVision { get; set; } // 0.0 to 1.0

    public double SensorIntegration { get; set; } // 0.0 to 1.0

    public double HumanRobotInteraction { get; set; } // 0.0 to 1.0

    public double OverallExpertise { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? TrainingDetails { get; set; } // JSON with training data
}

[Table("AutomationExpertises")]
public class AutomationExpertise
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime TrainingDate { get; set; }

    public double ProcessAutomation { get; set; } // 0.0 to 1.0

    public double IoTIntegration { get; set; } // 0.0 to 1.0

    public double MachineLearning { get; set; } // 0.0 to 1.0

    public double DataAnalytics { get; set; } // 0.0 to 1.0

    public double SystemIntegration { get; set; } // 0.0 to 1.0

    public double PredictiveMaintenance { get; set; } // 0.0 to 1.0

    public double OverallExpertise { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? TrainingDetails { get; set; } // JSON with training data
}

[Table("CognitiveSkills")]
public class CognitiveSkill
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string SkillName { get; set; } = string.Empty;

    [StringLength(50)]
    public string SkillCategory { get; set; } = string.Empty; // MindActivity, Learning, Experience, Expertise

    public double ProficiencyLevel { get; set; } // 0.0 to 1.0

    public DateTime LastAssessed { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? AssessmentData { get; set; } // JSON with assessment details
}

[Table("WorkProcesses")]
public class WorkProcess
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(200)]
    public string ProcessName { get; set; } = string.Empty;

    [Column(TypeName = "nvarchar(max)")]
    public string? Description { get; set; }

    [StringLength(50)]
    public string? Category { get; set; }

    [StringLength(20)]
    public string? Priority { get; set; } // Low, Medium, High, Critical

    [StringLength(50)]
    public string? Status { get; set; } // Active, Inactive, Completed, Archived

    public DateTime CreatedAt { get; set; }

    public DateTime LastModifiedAt { get; set; }

    // Navigation properties
    public virtual ICollection<ProcessStep> Steps { get; set; } = new List<ProcessStep>();
    public virtual ICollection<ProcessMetric> Metrics { get; set; } = new List<ProcessMetric>();
}

[Table("ProcessSteps")]
public class ProcessStep
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int ProcessId { get; set; }

    [Required]
    [StringLength(200)]
    public string StepName { get; set; } = string.Empty;

    [Column(TypeName = "nvarchar(max)")]
    public string? Description { get; set; }

    public int StepOrder { get; set; }

    public double EstimatedDuration { get; set; } // in minutes

    [StringLength(50)]
    public string? AssignedRole { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? RequiredResources { get; set; } // JSON array

    // Navigation property
    [ForeignKey("ProcessId")]
    public virtual WorkProcess? Process { get; set; }
}

[Table("ProcessMetrics")]
public class ProcessMetric
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int ProcessId { get; set; }

    [Required]
    public int UserId { get; set; }

    public int StepId { get; set; }

    public double Efficiency { get; set; } // 0.0 to 1.0

    public double Quality { get; set; } // 0.0 to 1.0

    public double TimeSpent { get; set; } // in minutes

    public DateTime RecordedAt { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? Notes { get; set; }

    // Navigation property
    [ForeignKey("ProcessId")]
    public virtual WorkProcess? Process { get; set; }
}

[Table("Situations")]
public class Situation
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string SituationType { get; set; } = string.Empty; // Technical, Process, Resource, Quality, etc.

    [Required]
    [StringLength(20)]
    public string Urgency { get; set; } = "Medium"; // Low, Medium, High, Critical

    [Column(TypeName = "nvarchar(max)")]
    public string? Description { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? ContextData { get; set; } // JSON with situation context

    [StringLength(50)]
    public string? Status { get; set; } = "Reported"; // Reported, Analyzing, ResponseGenerated, Resolved

    public DateTime ReportedAt { get; set; }

    public DateTime? ResolvedAt { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? Resolution { get; set; }
}

[Table("SituationResponses")]
public class SituationResponse
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int SituationId { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(50)]
    public string ResponseType { get; set; } = string.Empty;

    [Required]
    [StringLength(20)]
    public string Priority { get; set; } = "Medium";

    [Column(TypeName = "nvarchar(max)")]
    public string? RecommendedActionsJson { get; set; } // JSON array of actions

    public TimeSpan EstimatedResolutionTime { get; set; }

    public DateTime GeneratedAt { get; set; }

    // Navigation property
    [ForeignKey("SituationId")]
    public virtual Situation? Situation { get; set; }

    // Not mapped to database - computed property
    [NotMapped]
    public List<string> RecommendedActions
    {
        get => string.IsNullOrEmpty(RecommendedActionsJson) ?
               new List<string>() :
               System.Text.Json.JsonSerializer.Deserialize<List<string>>(RecommendedActionsJson) ?? new List<string>();
        set => RecommendedActionsJson = System.Text.Json.JsonSerializer.Serialize(value);
    }
}

[Table("AutomationRules")]
public class AutomationRule
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(200)]
    public string RuleName { get; set; } = string.Empty;

    [Column(TypeName = "nvarchar(max)")]
    public string? Description { get; set; }

    [Required]
    [StringLength(50)]
    public string RuleType { get; set; } = string.Empty; // Process, Quality, Resource, Notification, etc.

    [Column(TypeName = "nvarchar(max)")]
    public string? Conditions { get; set; } // JSON with trigger conditions

    [Column(TypeName = "nvarchar(max)")]
    public string? Actions { get; set; } // JSON with actions to perform

    public int Priority { get; set; } = 1;

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; }

    public DateTime LastModifiedAt { get; set; }

    // Navigation properties
    public virtual ICollection<AutomationExecution> Executions { get; set; } = new List<AutomationExecution>();
}

[Table("AutomationExecutions")]
public class AutomationExecution
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int RuleId { get; set; }

    [Required]
    public int UserId { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? ExecutionContext { get; set; } // JSON with execution context

    [Column(TypeName = "nvarchar(max)")]
    public string? Result { get; set; } // JSON with execution result

    [StringLength(50)]
    public string? Status { get; set; } = "Completed"; // Completed, Failed, Pending

    public DateTime ExecutedAt { get; set; }

    // Navigation property
    [ForeignKey("RuleId")]
    public virtual AutomationRule? Rule { get; set; }
}

[Table("ProcessOptimizations")]
public class ProcessOptimization
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int ProcessId { get; set; }

    [Required]
    public int UserId { get; set; }

    public DateTime OptimizationDate { get; set; }

    public double EfficiencyGain { get; set; } // 0.0 to 1.0

    [Column(TypeName = "nvarchar(max)")]
    public string? BottleneckIdentified { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? RecommendationsJson { get; set; } // JSON array of recommendations

    public double EstimatedImprovement { get; set; } // 0.0 to 1.0

    // Not mapped to database - computed property
    [NotMapped]
    public List<string> Recommendations
    {
        get => string.IsNullOrEmpty(RecommendationsJson) ?
               new List<string>() :
               System.Text.Json.JsonSerializer.Deserialize<List<string>>(RecommendationsJson) ?? new List<string>();
        set => RecommendationsJson = System.Text.Json.JsonSerializer.Serialize(value);
    }
}

// DTO Classes for API Requests

public class MindActivityData
{
    public double FocusLevel { get; set; } // 0.0 to 1.0
    public double MemoryRetention { get; set; } // 0.0 to 1.0
    public double CreativityScore { get; set; } // 0.0 to 1.0
    public double EmotionalIntelligence { get; set; } // 0.0 to 1.0
    public double ProblemSolvingAbility { get; set; } // 0.0 to 1.0
    public double AttentionSpan { get; set; } // minutes
    public int TasksCompleted { get; set; }
    public int DistractionsCount { get; set; }
    public Dictionary<string, double> CognitiveMetrics { get; set; } = new Dictionary<string, double>();
}

public class WorkCapacityData
{
    public double ProductivityScore { get; set; } // 0.0 to 1.0
    public double EnduranceLevel { get; set; } // 0.0 to 1.0
    public double MultitaskingAbility { get; set; } // 0.0 to 1.0
    public double StressManagement { get; set; } // 0.0 to 1.0
    public double TimeManagement { get; set; } // 0.0 to 1.0
    public int HoursWorked { get; set; }
    public int BreaksTaken { get; set; }
    public int TasksCompleted { get; set; }
    public Dictionary<string, double> WorkMetrics { get; set; } = new Dictionary<string, double>();
}

public class LearningActivityData
{
    public List<LearningActivityDto> Activities { get; set; } = new List<LearningActivityDto>();
    public double AverageLearningRate { get; set; } // 0.0 to 1.0
    public string PreferredLearningStyle { get; set; } = string.Empty; // Visual, Auditory, Kinesthetic, Reading
    public int TotalStudyHours { get; set; }
    public int CoursesCompleted { get; set; }
    public Dictionary<string, double> LearningMetrics { get; set; } = new Dictionary<string, double>();
}

public class LearningActivityDto
{
    public string ActivityType { get; set; } = string.Empty; // Course, Tutorial, Practice, Assessment
    public string Subject { get; set; } = string.Empty;
    public double CompletionRate { get; set; } // 0.0 to 1.0
    public double PerformanceScore { get; set; } // 0.0 to 1.0
    public int TimeSpentMinutes { get; set; }
    public DateTime CompletedAt { get; set; }
}

public class ExperienceData
{
    public List<ExperienceEntry> Experiences { get; set; } = new List<ExperienceEntry>();
    public double LeadershipScore { get; set; } // 0.0 to 1.0
    public double TeamworkScore { get; set; } // 0.0 to 1.0
    public double CommunicationScore { get; set; } // 0.0 to 1.0
    public int TotalYearsExperience { get; set; }
    public Dictionary<string, double> ExperienceMetrics { get; set; } = new Dictionary<string, double>();
}

public class ExperienceEntry
{
    public string Role { get; set; } = string.Empty;
    public string Company { get; set; } = string.Empty;
    public string Industry { get; set; } = string.Empty;
    public int YearsExperience { get; set; }
    public List<string> SkillsDeveloped { get; set; } = new List<string>();
    public List<string> Achievements { get; set; } = new List<string>();
    public double PerformanceRating { get; set; } // 0.0 to 1.0
}

public class TrainingData
{
    public string TrainingType { get; set; } = string.Empty; // NanoTech, Robotics, Automation
    public List<TrainingModule> Modules { get; set; } = new List<TrainingModule>();
    public double CurrentProficiency { get; set; } // 0.0 to 1.0
    public int HoursTrained { get; set; }
    public Dictionary<string, double> TrainingMetrics { get; set; } = new Dictionary<string, double>();
}

public class TrainingModule
{
    public string ModuleName { get; set; } = string.Empty;
    public string Topic { get; set; } = string.Empty;
    public double CompletionRate { get; set; } // 0.0 to 1.0
    public double AssessmentScore { get; set; } // 0.0 to 1.0
    public int TimeSpentMinutes { get; set; }
    public DateTime CompletedAt { get; set; }
}
