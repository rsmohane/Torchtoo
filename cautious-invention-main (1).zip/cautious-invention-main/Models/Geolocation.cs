namespace HumanAssist.Models;

public class GeolocationData
{
    public string? IpAddress { get; set; }
    public string? Country { get; set; }
    public string? CountryCode { get; set; }
    public string? Region { get; set; }
    public string? City { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string? Timezone { get; set; }
    public string? ISP { get; set; }
    public string? Organization { get; set; }
    public DateTime RequestedAt { get; set; }
}

public class UserGeolocationPreference
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public bool AllowTracking { get; set; } = false;
    public string? AllowedCountries { get; set; }
    public DateTime SetAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
}

public class UserLocation
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string Action { get; set; } = string.Empty;
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
}

public class AudioUsageLog
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Action { get; set; } = string.Empty;
    public int DurationSeconds { get; set; }
    public string Language { get; set; } = string.Empty;
    public DateTime LoggedAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
}

public class ImageUsageLog
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Action { get; set; } = string.Empty;
    public string Details { get; set; } = string.Empty;
    public DateTime LoggedAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
}

