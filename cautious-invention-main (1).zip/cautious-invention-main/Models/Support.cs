namespace HumanAssist.Models;

public class ProblemHandlingSkill
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string ProblemType { get; set; } = string.Empty; // Technical, Business, Operational, etc.
    public string SolutionApproach { get; set; } = string.Empty;
    public string ResolutionSteps { get; set; } = string.Empty; // JSON format
    public int SuccessRate { get; set; } // Percentage
    public int TimeEstimateMinutes { get; set; }
    public string RequiredTools { get; set; } = string.Empty; // CSV
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Navigation
    public ICollection<SupportTicket>? SupportTickets { get; set; }
}

public class SupportTicket
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int? AssignedSkillId { get; set; }
    public int? AssignedToUserId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Status { get; set; } = "Open"; // Open, In Progress, Resolved, Closed
    public string Severity { get; set; } = "Medium"; // Low, Medium, High, Critical
    public int EstimatedResolutionTime { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ResolvedAt { get; set; }
    public string? ResolutionNotes { get; set; }
    public int SatisfactionScore { get; set; } // 1-5 scale

    // Navigation
    public User? User { get; set; }
    public ProblemHandlingSkill? AssignedSkill { get; set; }
    public User? AssignedTo { get; set; }
    public ICollection<SupportConversation>? Conversations { get; set; }
}

public class SupportConversation
{
    public int Id { get; set; }
    public int SupportTicketId { get; set; }
    public int SenderUserId { get; set; }
    public string Message { get; set; } = string.Empty;
    public string MessageType { get; set; } = "Text"; // Text, Document, Code, Log
    public bool IsSolution { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public SupportTicket? SupportTicket { get; set; }
    public User? SenderUser { get; set; }
}

public class Environment
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty; // Development, Staging, Production
    public string EnvironmentUrl { get; set; } = string.Empty;
    public string EnvironmentVariablesEncrypted { get; set; } = string.Empty;
    public string AccessTokenEncrypted { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastAccessedAt { get; set; }

    // Navigation
    public User? User { get; set; }
    public ICollection<EnvironmentAccessLog>? AccessLogs { get; set; }
}

public class EnvironmentAccessLog
{
    public int Id { get; set; }
    public int EnvironmentId { get; set; }
    public int UserId { get; set; }
    public string Action { get; set; } = string.Empty; // Read, Write, Delete, Execute
    public string ResourceAccessed { get; set; } = string.Empty;
    public string IpAddress { get; set; } = string.Empty;
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public Environment? Environment { get; set; }
    public User? User { get; set; }
}

public class ApiKeyUsageStatistics
{
    public int Id { get; set; }
    public int ApiKeyId { get; set; }
    public int RequestsCount { get; set; }
    public int SuccessfulRequests { get; set; }
    public int FailedRequests { get; set; }
    public double AverageResponseTimeMs { get; set; }
    public DateTime DateFrom { get; set; }
    public DateTime DateTo { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public ApiKey? ApiKey { get; set; }
}
