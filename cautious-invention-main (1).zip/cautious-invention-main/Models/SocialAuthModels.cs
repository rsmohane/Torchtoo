namespace HumanAssist.Models;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

[Table("SocialAuthUsers")]
public class SocialAuthUser
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(50)]
    public string Provider { get; set; } = string.Empty; // Google, Facebook, Microsoft, Twitter

    [Required]
    [StringLength(500)]
    public string ProviderId { get; set; } = string.Empty; // Unique ID from the provider

    [Required]
    [StringLength(256)]
    public string Email { get; set; } = string.Empty;

    [StringLength(200)]
    public string? Name { get; set; }

    [StringLength(500)]
    public string? ProfilePictureUrl { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime LastLogin { get; set; }

    public bool IsActive { get; set; } = true;

    // Navigation property
    [ForeignKey("UserId")]
    public virtual User? User { get; set; }
}
