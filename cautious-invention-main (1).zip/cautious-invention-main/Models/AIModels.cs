namespace HumanAssist.Models;

public class AITool
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty; // Search, CodeGen, Analysis, DataProcessing
    public string Description { get; set; } = string.Empty;
    public string ApiEndpoint { get; set; } = string.Empty;
    public string ApiKeyEncrypted { get; set; } = string.Empty;
    public bool IsEnabled { get; set; } = true;
    public string Capabilities { get; set; } = string.Empty; // JSON array of capabilities
    public int RateLimitPerDay { get; set; } = 1000;
    public int CurrentUsageToday { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Navigation
    public ICollection<ToolUsageLog>? UsageLogs { get; set; }
}

public class ToolUsageLog
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int ToolId { get; set; }
    public string InputData { get; set; } = string.Empty;
    public string OutputData { get; set; } = string.Empty;
    public int ResponseTimeMs { get; set; }
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public User? User { get; set; }
    public AITool? Tool { get; set; }
}

public class CodeGenRequest
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Prompt { get; set; } = string.Empty;
    public string Language { get; set; } = "csharp"; // csharp, python, javascript, etc.
    public string? GeneratedCode { get; set; }
    public string Status { get; set; } = "Pending"; // Pending, Processing, Completed, Failed
    public string? ErrorMessage { get; set; }
    public int ExecutionTimeMs { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }

    // Navigation
    public User? User { get; set; }
}

public class Instruction
{
    public int Id { get; set; }
    public int CreatedByUserId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Tags { get; set; } = string.Empty; // CSV format
    public bool IsPublic { get; set; }
    public int ExecutionCount { get; set; }
    public string RelatedCapabilities { get; set; } = string.Empty; // JSON
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Navigation
    public User? CreatedBy { get; set; }
    public ICollection<InstructionExecution>? Executions { get; set; }
}

public class InstructionExecution
{
    public int Id { get; set; }
    public int InstructionId { get; set; }
    public int ExecutedByUserId { get; set; }
    public string Input { get; set; } = string.Empty;
    public string? Output { get; set; }
    public string Status { get; set; } = "Pending";
    public string? Log { get; set; }
    public int ExecutionTimeMs { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public Instruction? Instruction { get; set; }
    public User? ExecutedBy { get; set; }
}
