namespace HumanAssist.Models;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

[Table("EnvironmentConfigs")]
public class EnvironmentConfig
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string EnvironmentName { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string EnvironmentType { get; set; } = "Development"; // Development, Staging, Production, Testing

    [Required]
    [StringLength(500)]
    public string DatabaseConnectionString { get; set; } = string.Empty;

    [Required]
    [StringLength(500)]
    public string ApiBaseUrl { get; set; } = string.Empty;

    [StringLength(50)]
    public string LogLevel { get; set; } = "Information"; // Trace, Debug, Information, Warning, Error, Critical

    public bool EnableDebugMode { get; set; } = false;

    public int MaxConnections { get; set; } = 100;

    public int RequestTimeout { get; set; } = 30; // seconds

    public bool CacheEnabled { get; set; } = true;

    public int CacheDuration { get; set; } = 300; // seconds

    [Column(TypeName = "nvarchar(max)")]
    public string? Variables { get; set; } // JSON string for custom environment variables

    public DateTime CreatedAt { get; set; }

    public DateTime LastModifiedAt { get; set; }

    [StringLength(500)]
    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;
}

[Table("EnvironmentAuditLogs")]
public class EnvironmentAuditLog
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string EnvironmentName { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Action { get; set; } = string.Empty; // CREATE, UPDATE, DELETE, SWITCH, CLONE

    [Column(TypeName = "nvarchar(max)")]
    public string? Details { get; set; }

    public DateTime ChangedAt { get; set; }

    [StringLength(50)]
    public string? IpAddress { get; set; }

    [StringLength(500)]
    public string? UserAgent { get; set; }
}

[Table("EnvironmentSecrets")]
public class EnvironmentSecret
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EnvironmentConfigId { get; set; }

    [Required]
    [StringLength(100)]
    public string SecretName { get; set; } = string.Empty;

    [Required]
    [StringLength(500)]
    public string EncryptedValue { get; set; } = string.Empty;

    [StringLength(200)]
    public string? Description { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime LastAccessedAt { get; set; }

    public bool IsActive { get; set; } = true;
}

[Table("EnvironmentMetrics")]
public class EnvironmentMetric
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EnvironmentConfigId { get; set; }

    [Required]
    [StringLength(100)]
    public string MetricName { get; set; } = string.Empty; // RequestCount, ErrorCount, ResponseTime, DatabaseConnectionsUsed, etc.

    public double MetricValue { get; set; }

    [StringLength(50)]
    public string Unit { get; set; } = string.Empty; // ms, count, percentage, etc.

    public DateTime RecordedAt { get; set; }

    [StringLength(200)]
    public string? Tag { get; set; }
}

[Table("ImageEditLogs")]
public class ImageEditLog
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string Operation { get; set; } = string.Empty; // Resize, Crop, Filter, Enhance, etc.

    [Column(TypeName = "nvarchar(max)")]
    public string? Details { get; set; } // JSON serialized operation parameters

    [StringLength(500)]
    public string? ImageFileName { get; set; }

    public long? FileSizeBytes { get; set; }

    public DateTime EditedAt { get; set; }

    [StringLength(50)]
    public string? Status { get; set; } = "Completed"; // Completed, Failed, Processing

    [StringLength(500)]
    public string? ErrorMessage { get; set; }
}

[Table("TranslationQualityLogs")]
public class TranslationQualityLog
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(10)]
    public string SourceLanguage { get; set; } = string.Empty;

    [Required]
    [StringLength(10)]
    public string TargetLanguage { get; set; } = string.Empty;

    [Column(TypeName = "nvarchar(max)")]
    public string? SourceText { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string? TranslatedText { get; set; }

    [StringLength(50)]
    public string Mode { get; set; } = "Standard"; // Standard, Formal, Casual, Technical, Creative, Simplified

    public double ConfidenceScore { get; set; } // 0.0 to 1.0

    [StringLength(50)]
    public string TranslationType { get; set; } = "Text"; // Text, Speech, Document

    public int CharacterCount { get; set; }

    public DateTime LoggedAt { get; set; }

    [StringLength(50)]
    public string? QualityRating { get; set; } // Excellent, Good, Average, Poor
}

[Table("AudioReplacementLogs")]
public class AudioReplacementLog
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int UserId { get; set; }

    [Required]
    [StringLength(10)]
    public string SourceLanguage { get; set; } = string.Empty;

    [Required]
    [StringLength(10)]
    public string TargetLanguage { get; set; } = string.Empty;

    public bool FrequencyPreserved { get; set; }

    public int SourceFrequencyHz { get; set; }

    public int TargetFrequencyHz { get; set; }

    public int AudioDurationMs { get; set; }

    public DateTime ProcessedAt { get; set; }

    [StringLength(50)]
    public string? Status { get; set; } = "Completed"; // Completed, Failed, Processing

    [Column(TypeName = "nvarchar(max)")]
    public string? ProcessingDetails { get; set; }
}
