namespace HumanAssist.Models;

public class SupportedLanguage
{
    public int Id { get; set; }
    public string LanguageCode { get; set; } = string.Empty; // en, es, fr, de, etc.
    public string LanguageName { get; set; } = string.Empty;
    public string NativeName { get; set; } = string.Empty; // Español, Français, etc.
    public bool IsActive { get; set; } = true;
    public int NativeSpeakers { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class TranslationCache
{
    public int Id { get; set; }
    public string SourceText { get; set; } = string.Empty;
    public string SourceLanguage { get; set; } = string.Empty;
    public string TargetLanguage { get; set; } = string.Empty;
    public string TranslatedText { get; set; } = string.Empty;
    public string TranslationProvider { get; set; } = string.Empty; // Google, Azure, OpenAI
    public double ConfidenceScore { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastAccessedAt { get; set; }
    public int AccessCount { get; set; }
}

public class UserLanguagePreference
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string PreferredLanguageCode { get; set; } = string.Empty;
    public string SecondaryLanguageCode { get; set; } = string.Empty;
    public bool AutoTranslate { get; set; }
    public bool ShowOriginalText { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Navigation
    public User? User { get; set; }
}
