namespace HumanAssist.Models;

public class Conversation
{
    public int Id { get; set; }
    public int AssistanceRequestId { get; set; }
    public int SenderUserId { get; set; }
    public int? AssistantUserId { get; set; }
    public string Message { get; set; } = string.Empty;
    public string MessageType { get; set; } = "Text"; // Text, Document, Image
    public bool IsResolved { get; set; } = false;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation properties
    public AssistanceRequest? AssistanceRequest { get; set; }
    public User? SenderUser { get; set; }
    public User? AssistantUser { get; set; }
}
