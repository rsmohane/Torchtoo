# Quick Reference Guide

A cheat sheet for developers and operations teams working with the Human Assistance Platform.

---

## 🔥 Common Commands

### Development

```bash
# Build project
dotnet build

# Run application
dotnet run

# Run with watch mode
dotnet watch

# Clean build
dotnet clean

# Restore packages
dotnet restore
```

### Database

```bash
# Create migration
dotnet ef migrations add MigrationName

# Apply migrations
dotnet ef database update

# Remove last migration
dotnet ef migrations remove

# View migrations
dotnet ef migrations list

# Drop database
dotnet ef database drop

# Create initial database
dotnet ef database create
```

### Testing

```bash
# Run all tests
dotnet test

# Run specific test class
dotnet test --filter "TestClass"

# Run with verbose output
dotnet test --verbosity normal

# Generate code coverage
dotnet test /p:CollectCoverage=true
```

### Docker

```bash
# Build image
docker build -t humanassist:latest .

# Run container
docker run -p 5000:8080 humanassist:latest

# Docker Compose
docker-compose up -d           # Start
docker-compose down            # Stop
docker-compose logs -f api     # View logs
docker-compose ps              # Status
```

---

## 🔐 Security Essentials

### Generate Keys

```bash
# Generate JWT secret (min 32 chars)
openssl rand -base64 32

# Generate encryption key (64 chars)
openssl rand -base64 64

# Generate API key (64 bytes)
openssl rand -hex 32
```

### Encryption/Decryption

```csharp
// Encrypt
var encrypted = _encryptionService.Encrypt("secret-data");

// Decrypt
var decrypted = _encryptionService.Decrypt(encrypted);

// Hash password
var hash = _encryptionService.HashPassword("password123");

// Verify password
bool valid = _encryptionService.VerifyPassword("password123", hash);
```

### JWT Token

```csharp
// Generate token
var token = _authService.GenerateJwtToken(userId);

// Refresh token
var newToken = _authService.RefreshToken(refreshToken);

// Validate token
var principal = _authService.ValidateToken(token);
```

---

## 📊 API Quick Reference

### Authentication

**Register User:**
```bash
POST /api/auth/register
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Login:**
```bash
POST /api/auth/login
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
# Returns: { "accessToken": "...", "refreshToken": "..." }
```

**Refresh Token:**
```bash
POST /api/auth/refresh-token
{
  "refreshToken": "..."
}
```

### Support Tickets

**Create:**
```bash
POST /api/support/tickets
{
  "title": "Issue Title",
  "description": "Detailed description",
  "category": "Database",
  "severity": "High"
}
```

**Get All:**
```bash
GET /api/support/tickets?page=1&pageSize=10
```

**Get One:**
```bash
GET /api/support/tickets/{id}
```

**Update:**
```bash
PUT /api/support/tickets/{id}
{
  "status": "Resolved",
  "resolutionNotes": "Fixed by restarting service"
}
```

**Add Conversation:**
```bash
POST /api/support/tickets/{id}/conversation
{
  "message": "Here's the solution...",
  "messageType": "Text",
  "isSolution": true
}
```

### API Keys

**Generate:**
```bash
POST /api/apikeys/generate
{
  "name": "Mobile App",
  "permissions": "read,write"
}
# Returns: { "apiKey": "...", "createdAt": "..." }
```

**List:**
```bash
GET /api/apikeys
```

**Revoke:**
```bash
DELETE /api/apikeys/{id}
```

**Check Health:**
```bash
GET /api/apikeymonitoring/{id}/health
# Returns: { "successRate": 99.5, "avgResponseTime": 150, "isHealthy": true }
```

### Environments

**Create:**
```bash
POST /api/environments
{
  "name": "Production",
  "type": "Production",
  "environmentUrl": "https://api.prod.example.com"
}
```

**Set Variables:**
```bash
POST /api/environments/{id}/variables
{
  "DATABASE_URL": "Server=db.example.com;...",
  "API_KEY": "secret-value",
  "LOG_LEVEL": "INFO"
}
```

**Get Variables:**
```bash
GET /api/environments/{id}
# Returns encrypted variables automatically decrypted
```

**View Access Logs:**
```bash
GET /api/environments/{id}/access-logs
```

### Translation

**Translate:**
```bash
POST /api/translation/translate
{
  "text": "Hello world",
  "sourceLanguage": "en",
  "targetLanguage": "es"
}
# Returns: { "translatedText": "Hola mundo", "confidence": 0.95 }
```

**Batch Translate:**
```bash
POST /api/translation/batch-translate
{
  "texts": ["Hello", "Good morning"],
  "sourceLanguage": "en",
  "targetLanguage": "fr"
}
```

**Set Preference:**
```bash
POST /api/translation/preferences
{
  "preferredLanguage": "es",
  "secondaryLanguage": "en"
}
```

---

## 📁 Project Structure

```
/
├── Models/                    # Data models
│   ├── Authentication.cs      # User, ApiKey, AuditLog
│   ├── Support.cs             # Tickets, Skills, Conversations
│   ├── Languages.cs           # Translation models
│   └── AIModels.cs            # AI, Instructions, Tools
├── Data/                      # Database layer
│   ├── ApplicationDbContext.cs # DB configuration
│   └── Migrations/
├── Services/                  # Business logic (11 services)
│   ├── EncryptionService.cs
│   ├── AuthenticationService.cs
│   ├── SupportService.cs
│   ├── TranslationService.cs
│   ├── ApiKeyMonitoringService.cs
│   └── ...
├── Controllers/               # API endpoints (14 controllers)
│   ├── AuthController.cs
│   ├── SupportController.cs
│   ├── EnvironmentsController.cs
│   ├── TranslationController.cs
│   ├── ApiKeysController.cs
│   └── ...
├── appsettings.json           # Configuration
├── Program.cs                 # Startup
├── Dockerfile                 # Docker setup
└── docker-compose.yml         # Orchestration
```

---

## 🗄️ Database Quick Reference

### Connection String (LocalDB)

```
Server=(localdb)\mssqllocaldb;Database=HumanAssistDb;Integrated Security=true;
```

### Connection String (SQL Server)

```
Server=hostname;Database=HumanAssistDb;User Id=sa;Password=your-password;
```

### Key Tables

```sql
-- Users and Authentication
SELECT * FROM AspNetUsers;
SELECT * FROM ApiKeys;
SELECT * FROM AuditLogs;

-- Support System
SELECT * FROM SupportTickets;
SELECT * FROM SupportConversations;
SELECT * FROM ProblemHandlingSkills;

-- Environments
SELECT * FROM Environments;
SELECT * FROM EnvironmentVariables;
SELECT * FROM EnvironmentAccessLogs;

-- Translation
SELECT * FROM SupportedLanguages;
SELECT * FROM TranslationCaches;
SELECT * FROM UserLanguagePreferences;
```

---

## 🧪 Testing Patterns

### Unit Test Template

```csharp
[Fact]
public async Task MethodName_Scenario_ExpectedResult()
{
    // Arrange
    var service = new MyService();
    var input = "test data";

    // Act
    var result = await service.ProcessAsync(input);

    // Assert
    result.Should().NotBeNull();
    result.Value.Should().Be("expected");
}
```

### Mock Dependencies

```csharp
var mockRepo = new Mock<IRepository<Entity>>();
mockRepo.Setup(r => r.GetByIdAsync(1))
    .ReturnsAsync(new Entity { Id = 1 });

var service = new Service(mockRepo.Object);
```

### Integration Test

```csharp
public class ApiTests : IAsyncLifetime
{
    private HttpClient _client;

    public async Task InitializeAsync()
    {
        var factory = new TestWebApplicationFactory();
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetEndpoint_ReturnsOk()
    {
        var response = await _client.GetAsync("/api/endpoint");
        response.IsSuccessStatusCode.Should().BeTrue();
    }
}
```

---

## 🚀 Deployment Checklist

### Pre-Deployment
- [ ] All tests passing
- [ ] Code review completed
- [ ] Security scan passed
- [ ] Database migration tested
- [ ] Backup created
- [ ] Load testing completed
- [ ] Team notified

### Deployment
- [ ] Apply database migrations
- [ ] Update configuration values
- [ ] Deploy to target environment
- [ ] Verify health checks
- [ ] Run smoke tests
- [ ] Monitor logs

### Post-Deployment
- [ ] Verify all endpoints accessible
- [ ] Check database connectivity
- [ ] Confirm external service integrations
- [ ] Review error logs
- [ ] Notify users of completion

---

## 🔧 Troubleshooting

### Database Issues

```bash
# Check connection
sqlcmd -S (localdb)\mssqllocaldb -Q "SELECT 1"

# Recre database
dotnet ef database drop --force
dotnet ef database create
dotnet ef database update

# View migrations
dotnet ef migrations list
```

### API Issues

```bash
# Health check
curl http://localhost:5000/health

# Check logs
dotnet run
# Or in Docker
docker-compose logs api

# Test endpoint
curl -X GET http://localhost:5000/api/auth/profile \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Authentication Issues

```csharp
// Verify token
var principal = _tokenService.ValidateToken(token);

// Check claims
var userId = principal.FindFirst(ClaimTypes.NameIdentifier);

// Generate new token
var newToken = _authService.GenerateJwtToken(userId);
```

---

## 📈 Performance Tips

### Query Optimization

```csharp
// Use AsNoTracking for read-only queries
var data = context.Data.AsNoTracking().ToList();

// Include related data to avoid N+1
var tickets = context.SupportTickets
    .Include(t => t.User)
    .Include(t => t.Conversations)
    .ToList();

// Use pagination
var page = context.Data
    .Skip((pageNumber - 1) * pageSize)
    .Take(pageSize)
    .ToList();
```

### Caching

```csharp
// Cache translation results
var key = $"translation:{sourceLang}:{targetLang}:{text}";
var cached = await _cache.GetAsync(key);

if (cached == null)
{
    var result = await TranslateAsync();
    await _cache.SetAsync(key, result, TimeSpan.FromHours(24));
}
```

### Async Operations

```csharp
// Always use async for I/O operations
var data = await _repository.GetAsync(id);
var result = await _externalService.CallAsync();
```

---

## 🔐 Security Tips

### Secrets Management

```csharp
// Use configuration for secrets
var secret = builder.Configuration["Jwt:SecretKey"];

// Or Azure Key Vault (production)
builder.Configuration.AddAzureKeyVault(...);
```

### Data Encryption

```csharp
// Always encrypt sensitive data before storage
string encrypted = _encryptionService.Encrypt(apiKey);
await _repository.SaveAsync(encrypted);

// Decrypt when retrieving
string decrypted = _encryptionService.Decrypt(storedValue);
```

### Input Validation

```csharp
// Validate inputs
if (string.IsNullOrWhiteSpace(input))
    throw new ArgumentException("Input required");

// Use model validation
[Required]
[EmailAddress]
public string Email { get; set; }
```

---

## 📝 Common Curl Commands

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}'

# Get profile
curl http://localhost:5000/api/auth/profile \
  -H "Authorization: Bearer YOUR_TOKEN"

# Create support ticket
curl -X POST http://localhost:5000/api/support/tickets \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title":"Issue",
    "description":"Description",
    "category":"Database",
    "severity":"High"
  }'

# Generate API key
curl -X POST http://localhost:5000/api/apikeys/generate \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Mobile App"}'

# Translate text
curl -X POST http://localhost:5000/api/translation/translate \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "text":"Hello",
    "sourceLanguage":"en",
    "targetLanguage":"es"
  }'
```

---

## 📚 Important Files

| File | Purpose |
|------|---------|
| appsettings.json | Configuration & secrets |
| Program.cs | Application startup |
| Dockerfile | Container image |
| docker-compose.yml | Container orchestration |
| API-DOCUMENTATION.md | API reference |
| IMPLEMENTATION-GUIDE.md | Setup guide |
| MIGRATION-GUIDE.md | Database management |
| DEPLOYMENT-GUIDE.md | Deployment procedures |
| TESTING-GUIDE.md | Testing strategies |

---

## 🔗 Useful Links

- ASP.NET Core Docs: https://docs.microsoft.com/dotnet/core/
- Entity Framework Core: https://docs.microsoft.com/ef/core/
- SQL Server Docs: https://docs.microsoft.com/sql/
- OpenAI API: https://platform.openai.com/docs/
- Google Translate: https://cloud.google.com/translate/docs
- Azure Services: https://docs.microsoft.com/azure/

---

## 💡 Code Snippets

### Register a Service

```csharp
// Program.cs
builder.Services.AddScoped<IMyService, MyService>();
```

### Create Custom Middleware

```csharp
app.Use(async (context, next) =>
{
    // Before
    await next.Invoke();
    // After
});
```

### Add Database Migration

```csharp
// Models
public class Entity
{
    public int Id { get; set; }
    public string Name { get; set; }
}

// DbContext
public DbSet<Entity> Entities { get; set; }

// Then run
dotnet ef migrations add AddEntity
dotnet ef database update
```

---

**Last Updated:** 2024
**Version:** 1.0
