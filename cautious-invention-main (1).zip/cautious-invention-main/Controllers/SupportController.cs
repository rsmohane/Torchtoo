using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class SupportController : ControllerBase
{
    private readonly ISupportService _supportService;
    private readonly IAuditService _auditService;
    private readonly ILogger<SupportController> _logger;

    public SupportController(
        ISupportService supportService,
        IAuditService auditService,
        ILogger<SupportController> logger)
    {
        _supportService = supportService;
        _auditService = auditService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpGet("skills")]
    public async Task<ActionResult<object>> GetAvailableSkills()
    {
        var skills = await _supportService.GetAvailableSkillsAsync();
        return Ok(new { skills });
    }

    [HttpPost("tickets")]
    public async Task<ActionResult<object>> CreateTicket([FromBody] CreateTicketRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var ticket = new SupportTicket
        {
            UserId = userId,
            Title = request.Title,
            Description = request.Description,
            Category = request.Category,
            Severity = request.Severity,
            Status = "Open"
        };

        var (success, assignedTicket) = await _supportService.AutoAssignTicketAsync(ticket);
        if (!success)
            return BadRequest("Failed to create ticket");

        var created = await _supportService.CreateTicketAsync(assignedTicket);
        await _auditService.LogActionAsync(userId, "CreateSupportTicket", "SupportTicket", created.Id, request.Title, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return CreatedAtAction("GetTicket", new { id = created.Id }, created);
    }

    [HttpGet("tickets/{id}")]
    public async Task<ActionResult<object>> GetTicket(int id)
    {
        var ticket = await _supportService.GetTicketAsync(id);
        if (ticket == null)
            return NotFound();

        return Ok(ticket);
    }

    [HttpGet("tickets")]
    public async Task<ActionResult<object>> GetUserTickets()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var tickets = await _supportService.GetUserTicketsAsync(userId);
        return Ok(new { tickets });
    }

    [Authorize(Roles = "Assistant,Admin")]
    [HttpGet("tickets/open")]
    public async Task<ActionResult<object>> GetOpenTickets()
    {
        var tickets = await _supportService.GetOpenTicketsAsync();
        return Ok(new { tickets });
    }

    [HttpPut("tickets/{id}")]
    public async Task<IActionResult> UpdateTicket(int id, [FromBody] UpdateTicketRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var ticket = await _supportService.GetTicketAsync(id);
        if (ticket == null)
            return NotFound();

        // Only creator or assigned person can update
        if (ticket.UserId != userId && ticket.AssignedToUserId != userId)
            return Forbid();

        ticket.Status = request.Status;
        ticket.Severity = request.Severity;
        if (!string.IsNullOrEmpty(request.ResolutionNotes))
            ticket.ResolutionNotes = request.ResolutionNotes;

        if (request.Status == "Resolved")
            ticket.ResolvedAt = DateTime.UtcNow;

        var success = await _supportService.UpdateTicketAsync(ticket);
        if (!success)
            return BadRequest();

        await _auditService.LogActionAsync(userId, "UpdateSupportTicket", "SupportTicket", id, request.Status, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }

    [HttpPost("tickets/{id}/conversation")]
    public async Task<ActionResult<object>> AddConversation(int id, [FromBody] AddConversationRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var ticket = await _supportService.GetTicketAsync(id);
        if (ticket == null)
            return NotFound();

        var conversation = new SupportConversation
        {
            SupportTicketId = id,
            SenderUserId = userId,
            Message = request.Message,
            MessageType = request.MessageType ?? "Text",
            IsSolution = request.IsSolution
        };

        var created = await _supportService.AddConversationAsync(conversation);
        return CreatedAtAction("GetTicketConversations", new { ticketId = id }, created);
    }

    [HttpGet("tickets/{ticketId}/conversations")]
    public async Task<ActionResult<object>> GetTicketConversations(int ticketId)
    {
        var conversations = await _supportService.GetTicketConversationsAsync(ticketId);
        return Ok(new { conversations });
    }
}

public class CreateTicketRequest
{
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Severity { get; set; } = "Medium";
}

public class UpdateTicketRequest
{
    public string Status { get; set; } = string.Empty;
    public string Severity { get; set; } = string.Empty;
    public string? ResolutionNotes { get; set; }
}

public class AddConversationRequest
{
    public string Message { get; set; } = string.Empty;
    public string? MessageType { get; set; }
    public bool IsSolution { get; set; }
}
