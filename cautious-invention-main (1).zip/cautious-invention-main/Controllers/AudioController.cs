using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class AudioController : ControllerBase
{
    private readonly IAudioService _audioService;
    private readonly ILogger<AudioController> _logger;

    public AudioController(
        IAudioService audioService,
        ILogger<AudioController> logger)
    {
        _audioService = audioService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpPost("transcribe")]
    public async Task<ActionResult> TranscribeAudio([FromForm] IFormFile audioFile, [FromForm] string language = "en")
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (audioFile == null || audioFile.Length == 0)
            return BadRequest("No audio file provided");

        using (var stream = audioFile.OpenReadStream())
        {
            var (success, transcribedText, error) = await _audioService.TranscribeAudioAsync(stream, language, userId);
            
            if (!success)
                return BadRequest(error);

            return Ok(new { success = true, transcribedText });
        }
    }

    [HttpPost("synthesize")]
    public async Task<ActionResult> SynthesizeSpeech([FromBody] SynthesizeSpeechRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (string.IsNullOrEmpty(request.Text))
            return BadRequest("Text is required");

        var (success, audioStream, error) = await _audioService.SynthesizeSpeechAsync(request.Text, request.Language, request.Voice, userId);
        
        if (!success)
            return BadRequest(error);

        return File(audioStream, "audio/mpeg", "speech.mp3");
    }

    [HttpPost("translate-audio")]
    public async Task<ActionResult> TranslateAudio([FromForm] IFormFile audioFile, [FromForm] string sourceLanguage, [FromForm] string targetLanguage)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (audioFile == null || audioFile.Length == 0)
            return BadRequest("No audio file provided");

        using (var stream = audioFile.OpenReadStream())
        {
            var (success, translatedText, error) = await _audioService.TranslateAudioAsync(stream, sourceLanguage, targetLanguage, userId);
            
            if (!success)
                return BadRequest(error);

            return Ok(new { success = true, translatedText });
        }
    }

    [HttpGet("supported-languages")]
    public async Task<ActionResult> GetSupportedLanguages()
    {
        var languages = await _audioService.GetSupportedLanguagesAsync();
        return Ok(new { success = true, languages });
    }

    [HttpGet("voices/{language}")]
    public async Task<ActionResult> GetVoices(string language)
    {
        var voices = await _audioService.GetAvailableVoicesAsync(language);
        return Ok(new { success = true, voices });
    }
}

public class SynthesizeSpeechRequest
{
    public string Text { get; set; } = string.Empty;
    public string Language { get; set; } = "en";
    public string Voice { get; set; } = "default";
}
