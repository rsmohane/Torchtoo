using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HumanAssist.Services;
using System.ComponentModel.DataAnnotations;

namespace HumanAssist.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,User")]
    public class ImageEditingController : ControllerBase
    {
        private readonly IImageEditingService _imageEditingService;
        private readonly ILogger<ImageEditingController> _logger;

        public ImageEditingController(IImageEditingService imageEditingService, ILogger<ImageEditingController> logger)
        {
            _imageEditingService = imageEditingService;
            _logger = logger;
        }

        /// <summary>
        /// Resize an image to specified dimensions
        /// </summary>
        [HttpPost("resize")]
        public async Task<IActionResult> ResizeImage([FromForm] IFormFile file, [FromForm] int width, [FromForm] int height, [FromForm] double quality = 0.9)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.ResizeImageAsync(stream, width, height, quality);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"resized_{width}x{height}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resizing image");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Crop an image to specified rectangle area
        /// </summary>
        [HttpPost("crop")]
        public async Task<IActionResult> CropImage([FromForm] IFormFile file, [FromForm] int x, [FromForm] int y, [FromForm] int width, [FromForm] int height)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.CropImageAsync(stream, x, y, width, height);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"cropped_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error cropping image");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Rotate an image by specified degrees
        /// </summary>
        [HttpPost("rotate")]
        public async Task<IActionResult> RotateImage([FromForm] IFormFile file, [FromForm] float degrees)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.RotateImageAsync(stream, degrees);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"rotated_{degrees}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error rotating image");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Adjust image brightness
        /// </summary>
        [HttpPost("adjust-brightness")]
        public async Task<IActionResult> AdjustBrightness([FromForm] IFormFile file, [FromForm] float factor)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.AdjustBrightnessAsync(stream, factor);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"brightness_{factor}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adjusting brightness");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Adjust image contrast
        /// </summary>
        [HttpPost("adjust-contrast")]
        public async Task<IActionResult> AdjustContrast([FromForm] IFormFile file, [FromForm] float factor)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.AdjustContrastAsync(stream, factor);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"contrast_{factor}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adjusting contrast");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Adjust image saturation
        /// </summary>
        [HttpPost("adjust-saturation")]
        public async Task<IActionResult> AdjustSaturation([FromForm] IFormFile file, [FromForm] float factor)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.AdjustSaturationAsync(stream, factor);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"saturation_{factor}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adjusting saturation");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Apply a filter to the image
        /// </summary>
        [HttpPost("apply-filter")]
        public async Task<IActionResult> ApplyFilter([FromForm] IFormFile file, [FromForm] string filterName, [FromForm] float intensity = 1.0f)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.ApplyFilterAsync(stream, filterName, intensity);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"filtered_{filterName}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error applying filter");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Apply blur effect to image
        /// </summary>
        [HttpPost("apply-blur")]
        public async Task<IActionResult> ApplyBlur([FromForm] IFormFile file, [FromForm] float radius)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.ApplyBlurAsync(stream, radius);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"blurred_{radius}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error applying blur");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Apply sharpen effect to image
        /// </summary>
        [HttpPost("apply-sharpen")]
        public async Task<IActionResult> ApplySharpen([FromForm] IFormFile file, [FromForm] float amount)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.ApplySharpenAsync(stream, amount);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"sharpened_{amount}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error applying sharpen");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Remove background from image
        /// </summary>
        [HttpPost("remove-background")]
        public async Task<IActionResult> RemoveBackground([FromForm] IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.RemoveBackgroundAsync(stream);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/png", $"no_bg_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing background");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Apply watermark to image
        /// </summary>
        [HttpPost("apply-watermark")]
        public async Task<IActionResult> ApplyWatermark([FromForm] IFormFile file, [FromForm] string text, [FromForm] float opacity = 0.5f)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.ApplyWatermarkAsync(stream, text, opacity);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"watermarked_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error applying watermark");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Convert image format
        /// </summary>
        [HttpPost("convert-format")]
        public async Task<IActionResult> ConvertFormat([FromForm] IFormFile file, [FromForm] string targetFormat)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.ConvertFormatAsync(stream, targetFormat);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                var contentType = targetFormat.ToLower() switch
                {
                    "png" => "image/png",
                    "gif" => "image/gif",
                    "webp" => "image/webp",
                    _ => "image/jpeg"
                };

                return File(result.data, contentType, $"converted.{targetFormat}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error converting format");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Compress image while maintaining quality
        /// </summary>
        [HttpPost("compress")]
        public async Task<IActionResult> CompressImage([FromForm] IFormFile file, [FromForm] int quality = 80)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.CompressImageAsync(stream, quality);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File(result.data, "image/jpeg", $"compressed_q{quality}_{file.FileName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error compressing image");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Extract metadata from image
        /// </summary>
        [HttpGet("metadata")]
        public async Task<IActionResult> GetImageMetadata([FromForm] IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file provided");

                using var stream = new MemoryStream();
                await file.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _imageEditingService.GetImageMetadataAsync(stream);
                if (!result.success)
                    return BadRequest(new { message = result.error });

                return Ok(result.data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting metadata");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Batch edit multiple images
        /// </summary>
        [HttpPost("batch-edit")]
        public async Task<IActionResult> BatchEditImages([FromForm] List<IFormFile> files, [FromForm] string operations)
        {
            try
            {
                if (files == null || files.Count == 0)
                    return BadRequest("No files provided");

                var fileStreams = new List<(Stream stream, string name)>();
                foreach (var file in files)
                {
                    var stream = new MemoryStream();
                    await file.CopyToAsync(stream);
                    stream.Position = 0;
                    fileStreams.Add((stream, file.FileName));
                }

                var result = await _imageEditingService.BatchEditAsync(fileStreams, operations);
                if (!result.success)
                {
                    foreach (var (stream, _) in fileStreams)
                        stream.Dispose();
                    return BadRequest(new { message = result.error });
                }

                // Return first edited image or success message
                return Ok(new { message = "Batch editing completed", count = result.data?.Count ?? 0 });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error batch editing images");
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
