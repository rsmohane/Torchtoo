using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize(Roles = "Admin")]
[ApiController]
[Route("api/[controller]")]
public class AuditController : ControllerBase
{
    private readonly IAuditService _auditService;
    private readonly ILogger<AuditController> _logger;

    public AuditController(
        IAuditService auditService,
        ILogger<AuditController> logger)
    {
        _auditService = auditService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<object>> GetAuditLogs(
        [FromQuery] int? userId = null,
        [FromQuery] DateTime? fromDate = null,
        [FromQuery] DateTime? toDate = null)
    {
        var logs = await _auditService.GetAuditLogsAsync(userId, fromDate, toDate);
        return Ok(new { logs, count = logs.Count });
    }

    [HttpGet("{logId}")]
    public async Task<ActionResult<object>> GetAuditLog(int logId)
    {
        var log = await _auditService.GetAuditLogAsync(logId);
        if (log == null)
            return NotFound();

        return Ok(log);
    }
}
