using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HumanAssist.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ConversationsController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<ConversationsController> _logger;

    public ConversationsController(ApplicationDbContext context, ILogger<ConversationsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet("request/{requestId}")]
    public async Task<ActionResult<IEnumerable<Conversation>>> GetConversations(int requestId)
    {
        try
        {
            var conversations = await _context.Conversations
                .Where(c => c.AssistanceRequestId == requestId)
                .Include(c => c.SenderUser)
                .Include(c => c.AssistantUser)
                .OrderBy(c => c.CreatedAt)
                .ToListAsync();

            return Ok(conversations);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting conversations for request {RequestId}", requestId);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPost]
    public async Task<ActionResult<Conversation>> CreateConversation(Conversation conversation)
    {
        try
        {
            conversation.CreatedAt = DateTime.UtcNow;
            _context.Conversations.Add(conversation);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetConversations", new { requestId = conversation.AssistanceRequestId }, conversation);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error creating conversation");
            return StatusCode(500, "Error creating conversation");
        }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateConversation(int id, Conversation conversation)
    {
        if (id != conversation.Id)
            return BadRequest();

        try
        {
            var existingConversation = await _context.Conversations.FindAsync(id);
            if (existingConversation == null)
                return NotFound();

            existingConversation.Message = conversation.Message;
            existingConversation.IsResolved = conversation.IsResolved;

            _context.Conversations.Update(existingConversation);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating conversation {ConversationId}", id);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteConversation(int id)
    {
        try
        {
            var conversation = await _context.Conversations.FindAsync(id);
            if (conversation == null)
                return NotFound();

            _context.Conversations.Remove(conversation);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting conversation {ConversationId}", id);
            return StatusCode(500, "Internal server error");
        }
    }
}
