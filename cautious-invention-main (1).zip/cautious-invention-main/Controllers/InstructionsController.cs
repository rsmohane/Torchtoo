using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class InstructionsController : ControllerBase
{
    private readonly IInstructionService _instructionService;
    private readonly IAuditService _auditService;
    private readonly ILogger<InstructionsController> _logger;

    public InstructionsController(
        IInstructionService instructionService,
        IAuditService auditService,
        ILogger<InstructionsController> logger)
    {
        _instructionService = instructionService;
        _auditService = auditService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [AllowAnonymous]
    [HttpGet("public")]
    public async Task<ActionResult<object>> GetPublicInstructions()
    {
        var instructions = await _instructionService.GetPublicInstructionsAsync();
        return Ok(new { instructions });
    }

    [HttpGet]
    public async Task<ActionResult<object>> GetUserInstructions()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var instructions = await _instructionService.GetUserInstructionsAsync(userId);
        return Ok(new { instructions });
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetInstruction(int id)
    {
        var instruction = await _instructionService.GetInstructionAsync(id);
        if (instruction == null)
            return NotFound();

        return Ok(instruction);
    }

    [HttpPost]
    public async Task<ActionResult<object>> CreateInstruction([FromBody] CreateInstructionRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var instruction = new Instruction
        {
            CreatedByUserId = userId,
            Title = request.Title,
            Content = request.Content,
            Category = request.Category,
            Tags = request.Tags,
            IsPublic = request.IsPublic,
            RelatedCapabilities = request.RelatedCapabilities
        };

        var created = await _instructionService.CreateInstructionAsync(instruction);
        await _auditService.LogActionAsync(userId, "CreateInstruction", "Instruction", created.Id, request.Title, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return CreatedAtAction("GetInstruction", new { id = created.Id }, created);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateInstruction(int id, [FromBody] UpdateInstructionRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var instruction = await _instructionService.GetInstructionAsync(id);
        if (instruction == null || instruction.CreatedByUserId != userId)
            return Forbid();

        instruction.Title = request.Title;
        instruction.Content = request.Content;
        instruction.Category = request.Category;
        instruction.Tags = request.Tags;
        instruction.IsPublic = request.IsPublic;

        var success = await _instructionService.UpdateInstructionAsync(instruction);
        if (!success)
            return BadRequest();

        await _auditService.LogActionAsync(userId, "UpdateInstruction", "Instruction", id, request.Title, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteInstruction(int id)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var success = await _instructionService.DeleteInstructionAsync(id, userId);
        if (!success)
            return NotFound();

        await _auditService.LogActionAsync(userId, "DeleteInstruction", "Instruction", id, "", HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }

    [HttpPost("{id}/execute")]
    public async Task<ActionResult<object>> ExecuteInstruction(int id, [FromBody] ExecuteInstructionRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var execution = await _instructionService.ExecuteInstructionAsync(id, request.Input, userId);
        
        await _auditService.LogActionAsync(userId, "ExecuteInstruction", "InstructionExecution", execution.Id, request.Input[..Math.Min(100, request.Input.Length)], HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return Ok(execution);
    }

    [HttpGet("{id}/executions")]
    public async Task<ActionResult<object>> GetInstructionExecutions(int id)
    {
        var executions = await _instructionService.GetInstructionExecutionsAsync(id);
        return Ok(new { executions });
    }
}

public class CreateInstructionRequest
{
    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Tags { get; set; } = string.Empty;
    public bool IsPublic { get; set; }
    public string RelatedCapabilities { get; set; } = string.Empty;
}

public class UpdateInstructionRequest
{
    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Tags { get; set; } = string.Empty;
    public bool IsPublic { get; set; }
}

public class ExecuteInstructionRequest
{
    public string Input { get; set; } = string.Empty;
}
