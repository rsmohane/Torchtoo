using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class AIController : ControllerBase
{
    private readonly IAIService _aiService;
    private readonly ICodeGenerationService _codeGenService;
    private readonly IAuditService _auditService;
    private readonly ILogger<AIController> _logger;

    public AIController(
        IAIService aiService,
        ICodeGenerationService codeGenService,
        IAuditService auditService,
        ILogger<AIController> logger)
    {
        _aiService = aiService;
        _codeGenService = codeGenService;
        _auditService = auditService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpPost("analyze")]
    public async Task<ActionResult<object>> AnalyzeText([FromBody] AnalysisRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, response, error) = await _aiService.AnalyzeTextAsync(request.Text, request.AnalysisType);
        
        if (!success)
            return BadRequest(new { error });

        await _auditService.LogActionAsync(userId, "AIAnalysis", "Text", null, request.AnalysisType, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return Ok(new { analysis = response });
    }

    [HttpPost("generate-response")]
    public async Task<ActionResult<object>> GenerateResponse([FromBody] GenerationRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, response, error) = await _aiService.GenerateResponseAsync(request.Prompt, userId);
        
        if (!success)
            return BadRequest(new { error });

        await _auditService.LogActionAsync(userId, "AIGeneration", "Response", null, request.Prompt[..Math.Min(100, request.Prompt.Length)], HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return Ok(new { response });
    }

    [HttpGet("available-tools")]
    public async Task<ActionResult<object>> GetAvailableTools()
    {
        var tools = await _aiService.GetAvailableToolsAsync();
        return Ok(new { tools });
    }

    [HttpPost("execute-tool/{toolId}")]
    public async Task<ActionResult<object>> ExecuteTool(int toolId, [FromBody] ToolExecutionRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, response, error) = await _aiService.ExecuteToolAsync(toolId, request.Input, userId);
        
        if (!success)
            return BadRequest(new { error });

        return Ok(new { result = response });
    }

    [HttpPost("generate-code")]
    public async Task<ActionResult<object>> GenerateCode([FromBody] CodeGenerationRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, code, error) = await _codeGenService.GenerateCodeAsync(request.Prompt, request.Language, userId);
        
        if (!success)
            return BadRequest(new { error });

        return Ok(new { code });
    }

    [HttpPost("validate-code")]
    public async Task<ActionResult<object>> ValidateCode([FromBody] CodeValidationRequest request)
    {
        var (success, result, error) = await _codeGenService.ValidateCodeAsync(request.Code, request.Language);
        
        if (!success)
            return BadRequest(new { error });

        return Ok(new { valid = success, message = result });
    }

    [HttpGet("code-requests")]
    public async Task<ActionResult<object>> GetCodeRequests()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var requests = await _codeGenService.GetUserCodeRequestsAsync(userId);
        return Ok(new { requests });
    }
}

public class AnalysisRequest
{
    public string Text { get; set; } = string.Empty;
    public string AnalysisType { get; set; } = string.Empty;
}

public class GenerationRequest
{
    public string Prompt { get; set; } = string.Empty;
}

public class ToolExecutionRequest
{
    public string Input { get; set; } = string.Empty;
}

public class CodeGenerationRequest
{
    public string Prompt { get; set; } = string.Empty;
    public string Language { get; set; } = "csharp";
}

public class CodeValidationRequest
{
    public string Code { get; set; } = string.Empty;
    public string Language { get; set; } = "csharp";
}
