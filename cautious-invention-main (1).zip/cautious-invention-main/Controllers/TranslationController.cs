using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class TranslationController : ControllerBase
{
    private readonly ITranslationService _translationService;
    private readonly ILogger<TranslationController> _logger;

    public TranslationController(
        ITranslationService translationService,
        ILogger<TranslationController> logger)
    {
        _translationService = translationService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpPost("translate")]
    public async Task<ActionResult<object>> Translate([FromBody] TranslateRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, translatedText, error) = await _translationService.TranslateAsync(
            request.Text,
            request.SourceLanguage,
            request.TargetLanguage,
            userId);

        if (!success)
            return BadRequest(new { error });

        return Ok(new { translatedText, sourceLanguage = request.SourceLanguage, targetLanguage = request.TargetLanguage });
    }

    [AllowAnonymous]
    [HttpGet("languages")]
    public async Task<ActionResult<object>> GetSupportedLanguages()
    {
        var languages = await _translationService.GetSupportedLanguagesAsync();
        return Ok(new { languages });
    }

    [HttpPost("preferences")]
    public async Task<ActionResult<object>> SetLanguagePreference([FromBody] SetLanguagePreferenceRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var success = await _translationService.SetUserLanguagePreferenceAsync(
            userId,
            request.PreferredLanguage,
            request.SecondaryLanguage);

        if (!success)
            return BadRequest();

        return Ok(new { message = "Language preference updated" });
    }

    [HttpGet("preferences")]
    public async Task<ActionResult<object>> GetLanguagePreference()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var preference = await _translationService.GetUserLanguagePreferenceAsync(userId);
        if (preference == null)
            return NotFound();

        return Ok(preference);
    }

    [HttpPost("batch-translate")]
    public async Task<ActionResult<object>> BatchTranslate([FromBody] BatchTranslateRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var results = new List<object>();
        foreach (var text in request.Texts)
        {
            var (success, translatedText, error) = await _translationService.TranslateAsync(
                text,
                request.SourceLanguage,
                request.TargetLanguage,
                userId);

            results.Add(new
            {
                originalText = text,
                translatedText = translatedText,
                success = success,
                error = error
            });
        }

        return Ok(new { results });
    }
}

public class TranslateRequest
{
    public string Text { get; set; } = string.Empty;
    public string SourceLanguage { get; set; } = "en";
    public string TargetLanguage { get; set; } = string.Empty;
}

public class SetLanguagePreferenceRequest
{
    public string PreferredLanguage { get; set; } = string.Empty;
    public string? SecondaryLanguage { get; set; }
}

public class BatchTranslateRequest
{
    public List<string> Texts { get; set; } = new();
    public string SourceLanguage { get; set; } = "en";
    public string TargetLanguage { get; set; } = string.Empty;
}
