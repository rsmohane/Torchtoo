using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HumanAssist.Services;
using System.ComponentModel.DataAnnotations;

namespace HumanAssist.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,User")]
    public class AdvancedLanguageController : ControllerBase
    {
        private readonly IAdvancedLanguageService _advancedLanguageService;
        private readonly ILogger<AdvancedLanguageController> _logger;

        public AdvancedLanguageController(IAdvancedLanguageService advancedLanguageService, ILogger<AdvancedLanguageController> logger)
        {
            _advancedLanguageService = advancedLanguageService;
            _logger = logger;
        }

        /// <summary>
        /// Get all supported languages for translation
        /// </summary>
        [HttpGet("supported-languages")]
        [AllowAnonymous]
        public async Task<IActionResult> GetSupportedLanguages()
        {
            try
            {
                var result = await _advancedLanguageService.GetSupportedLanguagesAsync();
                return Ok(new { languages = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting supported languages");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Translate text in reading mode (formal, literature-style)
        /// </summary>
        [HttpPost("translate-reading")]
        public async Task<IActionResult> TranslateReading([FromBody] AdvancedTranslateRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Text))
                    return BadRequest("Text is required");

                var result = await _advancedLanguageService.TranslateReadingAsync(
                    request.Text,
                    request.SourceLanguage,
                    request.TargetLanguage,
                    request.UserId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                return Ok(result.data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error translating in reading mode");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Translate text in writing mode (professional, business-appropriate)
        /// </summary>
        [HttpPost("translate-writing")]
        public async Task<IActionResult> TranslateWriting([FromBody] AdvancedTranslateRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Text))
                    return BadRequest("Text is required");

                var result = await _advancedLanguageService.TranslateWritingAsync(
                    request.Text,
                    request.SourceLanguage,
                    request.TargetLanguage,
                    request.UserId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                return Ok(result.data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error translating in writing mode");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Translate text in editing mode (context-aware, nuanced)
        /// </summary>
        [HttpPost("translate-editing")]
        public async Task<IActionResult> TranslateEditing([FromBody] AdvancedTranslateEditingRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Text))
                    return BadRequest("Text is required");

                var result = await _advancedLanguageService.TranslateEditingAsync(
                    request.Text,
                    request.SourceLanguage,
                    request.TargetLanguage,
                    request.Context,
                    request.UserId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                return Ok(result.data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error translating in editing mode");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Translate spoken audio in speaking mode (conversational, natural)
        /// </summary>
        [HttpPost("translate-speaking")]
        public async Task<IActionResult> TranslateSpeaking([FromForm] IFormFile audioFile, [FromForm] string sourceLanguage, [FromForm] string targetLanguage, [FromForm] string? userId = null)
        {
            try
            {
                if (audioFile == null || audioFile.Length == 0)
                    return BadRequest("Audio file is required");

                using var stream = new MemoryStream();
                await audioFile.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _advancedLanguageService.TranslateSpeakingAsync(
                    stream,
                    sourceLanguage,
                    targetLanguage,
                    userId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                return Ok(result.data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error translating in speaking mode");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Translate audio with automatic frequency detection and matching
        /// </summary>
        [HttpPost("translate-sound")]
        public async Task<IActionResult> TranslateSound([FromForm] IFormFile audioFile, [FromForm] string sourceLanguage, [FromForm] string targetLanguage, [FromForm] string? userId = null)
        {
            try
            {
                if (audioFile == null || audioFile.Length == 0)
                    return BadRequest("Audio file is required");

                using var stream = new MemoryStream();
                await audioFile.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _advancedLanguageService.TranslateSoundAsync(
                    stream,
                    sourceLanguage,
                    targetLanguage,
                    userId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                // Return audio with matched frequency
                return File((byte[])result.data?.TranslatedAudio!, "audio/wav", $"translated_{targetLanguage}.wav");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error translating with sound");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Replace audio while preserving original frequency characteristics
        /// </summary>
        [HttpPost("translate-sound-replacement")]
        public async Task<IActionResult> TranslateSoundReplacement([FromForm] IFormFile audioFile, [FromForm] string sourceLanguage, [FromForm] string targetLanguage, [FromForm] string? userId = null)
        {
            try
            {
                if (audioFile == null || audioFile.Length == 0)
                    return BadRequest("Audio file is required");

                using var stream = new MemoryStream();
                await audioFile.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _advancedLanguageService.TranslateSoundReplacementAsync(
                    stream,
                    sourceLanguage,
                    targetLanguage,
                    userId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                return File((byte[])result.data?.TranslatedAudio!, "audio/wav", $"replaced_{targetLanguage}.wav");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in sound replacement translation");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Perform simultaneous real-time translation with audio synthesis
        /// </summary>
        [HttpPost("translate-simultaneous")]
        public async Task<IActionResult> TranslateSimultaneous([FromForm] IFormFile audioFile, [FromForm] string sourceLanguage, [FromForm] string targetLanguage, [FromForm] string? userId = null)
        {
            try
            {
                if (audioFile == null || audioFile.Length == 0)
                    return BadRequest("Audio file is required");

                using var stream = new MemoryStream();
                await audioFile.CopyToAsync(stream);
                stream.Position = 0;

                var result = await _advancedLanguageService.TranslateSimultaneousAsync(
                    stream,
                    sourceLanguage,
                    targetLanguage,
                    userId);

                if (!result.success)
                    return BadRequest(new { message = result.error });

                return Ok(new {
                    originalText = result.data?.SourceText,
                    translatedText = result.data?.TargetText,
                    mode = result.data?.Mode,
                    timestamp = result.data?.Timestamp,
                    message = "Simultaneous translation completed"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in simultaneous translation");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Set user language preferences
        /// </summary>
        [HttpPost("set-language-preferences")]
        public async Task<IActionResult> SetLanguagePreferences([FromBody] SetLanguagePreferencesRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.UserId))
                    return BadRequest("UserId is required");

                await _advancedLanguageService.SetUserLanguagePreferencesAsync(
                    request.UserId,
                    request.PreferredSourceLanguage,
                    request.PreferredTargetLanguage);

                return Ok(new { message = "Language preferences updated" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting language preferences");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Get translation history for a user
        /// </summary>
        [HttpGet("translation-history/{userId}")]
        public async Task<IActionResult> GetTranslationHistory(string userId, [FromQuery] int? limit = 50)
        {
            try
            {
                // This would need to be implemented in the service
                // For now, return placeholder
                return Ok(new { 
                    userId = userId, 
                    message = "Translation history endpoint. Implementation pending.",
                    limitRecords = limit 
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting translation history");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Detect audio frequency characteristics
        /// </summary>
        [HttpPost("detect-frequency")]
        public async Task<IActionResult> DetectFrequency([FromForm] IFormFile audioFile)
        {
            try
            {
                if (audioFile == null || audioFile.Length == 0)
                    return BadRequest("Audio file is required");

                using var stream = new MemoryStream();
                await audioFile.CopyToAsync(stream);
                stream.Position = 0;

                var frequency = await _advancedLanguageService.DetectAudioFrequencyAsync(stream);

                return Ok(new { 
                    frequency = frequency, 
                    unit = "Hz",
                    referenceFrequency = 440,
                    message = "Frequency detection completed"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error detecting frequency");
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }

    // Request DTOs
    public class AdvancedTranslateRequest
    {
        [Required]
        public string Text { get; set; } = string.Empty;
        
        [Required]
        public string SourceLanguage { get; set; } = string.Empty;
        
        [Required]
        public string TargetLanguage { get; set; } = string.Empty;
        
        public string? UserId { get; set; }
    }

    public class AdvancedTranslateEditingRequest : AdvancedTranslateRequest
    {
        public string? Context { get; set; }
    }

    public class SetLanguagePreferencesRequest
    {
        [Required]
        public string UserId { get; set; } = string.Empty;
        
        [Required]
        public string PreferredSourceLanguage { get; set; } = string.Empty;
        
        [Required]
        public string PreferredTargetLanguage { get; set; } = string.Empty;
    }
}
