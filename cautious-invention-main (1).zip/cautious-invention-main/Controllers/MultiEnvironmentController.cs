using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HumanAssist.Services;
using System.ComponentModel.DataAnnotations;

namespace HumanAssist.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class MultiEnvironmentController : ControllerBase
    {
        private readonly IMultiEnvironmentService _multiEnvironmentService;
        private readonly ILogger<MultiEnvironmentController> _logger;

        public MultiEnvironmentController(IMultiEnvironmentService multiEnvironmentService, ILogger<MultiEnvironmentController> logger)
        {
            _multiEnvironmentService = multiEnvironmentService;
            _logger = logger;
        }

        /// <summary>
        /// Get all available environments
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllEnvironments()
        {
            try
            {
                var (success, configs, error) = await _multiEnvironmentService.GetAllEnvironmentsAsync();
                
                if (!success)
                    return BadRequest(new { message = error });

                return Ok(new { 
                    environments = configs,
                    count = configs.Count,
                    message = "Environments retrieved successfully"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all environments");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Get specific environment configuration
        /// </summary>
        [HttpGet("{environmentName}")]
        public async Task<IActionResult> GetEnvironment(string environmentName)
        {
            try
            {
                var (success, config, error) = await _multiEnvironmentService.GetEnvironmentConfigAsync(environmentName);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(new { 
                    environment = config,
                    message = "Environment retrieved successfully"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting environment");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Create a new environment
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CreateEnvironment([FromBody] CreateEnvironmentRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Name))
                    return BadRequest("Environment name is required");

                var (success, error) = await _multiEnvironmentService.CreateEnvironmentAsync(request);
                
                if (!success)
                    return BadRequest(new { message = error });

                return CreatedAtAction(nameof(GetEnvironment), new { environmentName = request.Name }, 
                    new { message = $"Environment '{request.Name}' created successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating environment");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Update an existing environment
        /// </summary>
        [HttpPut("{environmentName}")]
        public async Task<IActionResult> UpdateEnvironment(string environmentName, [FromBody] UpdateEnvironmentRequest request)
        {
            try
            {
                var (success, error) = await _multiEnvironmentService.UpdateEnvironmentAsync(environmentName, request);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(new { message = $"Environment '{environmentName}' updated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating environment");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Delete an environment
        /// </summary>
        [HttpDelete("{environmentName}")]
        public async Task<IActionResult> DeleteEnvironment(string environmentName)
        {
            try
            {
                var (success, error) = await _multiEnvironmentService.DeleteEnvironmentAsync(environmentName);
                
                if (!success)
                    return BadRequest(new { message = error });

                return Ok(new { message = $"Environment '{environmentName}' deleted successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting environment");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Switch to a different environment
        /// </summary>
        [HttpPost("{environmentName}/switch")]
        public async Task<IActionResult> SwitchEnvironment(string environmentName)
        {
            try
            {
                var (success, error) = await _multiEnvironmentService.SwitchEnvironmentAsync(environmentName);
                
                if (!success)
                    return BadRequest(new { message = error });

                return Ok(new { message = $"Switched to environment '{environmentName}'" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error switching environment");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Get database configuration for an environment
        /// </summary>
        [HttpGet("{environmentName}/database-config")]
        public async Task<IActionResult> GetDatabaseConfig(string environmentName)
        {
            try
            {
                var (success, config, error) = await _multiEnvironmentService.GetDatabaseConfigAsync(environmentName);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(new { databaseConfig = config });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting database config");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Get logging configuration for an environment
        /// </summary>
        [HttpGet("{environmentName}/logging-config")]
        public async Task<IActionResult> GetLoggingConfig(string environmentName)
        {
            try
            {
                var (success, config, error) = await _multiEnvironmentService.GetLoggingConfigAsync(environmentName);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(new { loggingConfig = config });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting logging config");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Get API configuration for an environment
        /// </summary>
        [HttpGet("{environmentName}/api-config")]
        public async Task<IActionResult> GetAPIConfig(string environmentName)
        {
            try
            {
                var (success, config, error) = await _multiEnvironmentService.GetAPIConfigAsync(environmentName);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(new { apiConfig = config });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting API config");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Get security configuration for an environment
        /// </summary>
        [HttpGet("{environmentName}/security-config")]
        public async Task<IActionResult> GetSecurityConfig(string environmentName)
        {
            try
            {
                var (success, config, error) = await _multiEnvironmentService.GetSecurityConfigAsync(environmentName);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(new { securityConfig = config });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting security config");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Perform health check on an environment
        /// </summary>
        [HttpPost("{environmentName}/health-check")]
        [AllowAnonymous]
        public async Task<IActionResult> HealthCheck(string environmentName)
        {
            try
            {
                var (success, health, error) = await _multiEnvironmentService.HealthCheckAsync(environmentName);
                
                if (!success)
                    return NotFound(new { message = error });

                return Ok(health);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error performing health check");
                return StatusCode(500, new { message = ex.Message });
            }
        }

        /// <summary>
        /// Validate environment configuration
        /// </summary>
        [HttpPost("{environmentName}/validate")]
        public async Task<IActionResult> ValidateEnvironment(string environmentName)
        {
            try
            {
                var isValid = await _multiEnvironmentService.ValidateEnvironmentAsync(environmentName);
                
                if (!isValid)
                    return BadRequest(new { message = $"Environment '{environmentName}' validation failed" });

                return Ok(new { message = $"Environment '{environmentName}' is valid" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating environment");
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
