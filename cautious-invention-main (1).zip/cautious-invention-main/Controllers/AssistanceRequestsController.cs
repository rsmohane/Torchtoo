using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HumanAssist.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AssistanceRequestsController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<AssistanceRequestsController> _logger;

    public AssistanceRequestsController(ApplicationDbContext context, ILogger<AssistanceRequestsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<AssistanceRequest>>> GetRequests([FromQuery] string? status = null)
    {
        try
        {
            var query = _context.AssistanceRequests
                .Include(r => r.User)
                .Include(r => r.AssignedTo)
                .AsQueryable();

            if (!string.IsNullOrEmpty(status))
                query = query.Where(r => r.Status == status);

            var requests = await query.ToListAsync();
            return Ok(requests);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting assistance requests");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<AssistanceRequest>> GetRequest(int id)
    {
        try
        {
            var request = await _context.AssistanceRequests
                .Include(r => r.User)
                .Include(r => r.AssignedTo)
                .Include(r => r.Conversations)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (request == null)
                return NotFound();

            return Ok(request);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting assistance request {RequestId}", id);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPost]
    public async Task<ActionResult<AssistanceRequest>> CreateRequest(AssistanceRequest request)
    {
        try
        {
            request.CreatedAt = DateTime.UtcNow;
            request.Status = "Open";
            _context.AssistanceRequests.Add(request);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetRequest", new { id = request.Id }, request);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error creating assistance request");
            return StatusCode(500, "Error creating request");
        }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateRequest(int id, AssistanceRequest request)
    {
        if (id != request.Id)
            return BadRequest();

        try
        {
            var existingRequest = await _context.AssistanceRequests.FindAsync(id);
            if (existingRequest == null)
                return NotFound();

            existingRequest.Title = request.Title;
            existingRequest.Description = request.Description;
            existingRequest.Category = request.Category;
            existingRequest.Status = request.Status;
            existingRequest.Priority = request.Priority;
            existingRequest.AssignedToId = request.AssignedToId;

            if (request.Status == "Resolved" && existingRequest.ResolvedAt == null)
                existingRequest.ResolvedAt = DateTime.UtcNow;

            _context.AssistanceRequests.Update(existingRequest);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating assistance request {RequestId}", id);
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("user/{userId}")]
    public async Task<ActionResult<IEnumerable<AssistanceRequest>>> GetUserRequests(int userId)
    {
        try
        {
            var requests = await _context.AssistanceRequests
                .Where(r => r.UserId == userId)
                .Include(r => r.AssignedTo)
                .ToListAsync();

            return Ok(requests);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting user {UserId} assistance requests", userId);
            return StatusCode(500, "Internal server error");
        }
    }
}
