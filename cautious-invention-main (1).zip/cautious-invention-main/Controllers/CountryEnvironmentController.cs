using HumanAssist.Controllers;
using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HumanAssist.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CountryEnvironmentController : ControllerBase
    {
        private readonly ICountryEnvironmentService _countryEnvironmentService;

        public CountryEnvironmentController(ICountryEnvironmentService countryEnvironmentService)
        {
            _countryEnvironmentService = countryEnvironmentService;
        }

        /// <summary>
        /// Get all available countries and their environments
        /// </summary>
        [HttpGet("countries")]
        public async Task<IActionResult> GetAllCountries()
        {
            try
            {
                var countries = await _countryEnvironmentService.GetAllCountriesAsync();
                return Ok(countries);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving countries", error = ex.Message });
            }
        }

        /// <summary>
        /// Get country environment by country code
        /// </summary>
        [HttpGet("countries/{countryCode}")]
        public async Task<IActionResult> GetCountryEnvironment(string countryCode)
        {
            try
            {
                var environment = await _countryEnvironmentService.GetCountryEnvironmentAsync(countryCode);
                if (environment == null)
                    return NotFound(new { message = $"Country environment for {countryCode} not found" });

                return Ok(environment);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving country environment", error = ex.Message });
            }
        }

        /// <summary>
        /// Create a new country environment
        /// </summary>
        [HttpPost("countries")]
        public async Task<IActionResult> CreateCountryEnvironment([FromBody] CountryEnvironment environment)
        {
            try
            {
                var result = await _countryEnvironmentService.CreateCountryEnvironmentAsync(environment);
                return CreatedAtAction(nameof(GetCountryEnvironment), new { countryCode = result.CountryCode }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error creating country environment", error = ex.Message });
            }
        }

        /// <summary>
        /// Update an existing country environment
        /// </summary>
        [HttpPut("countries/{countryCode}")]
        public async Task<IActionResult> UpdateCountryEnvironment(string countryCode, [FromBody] CountryEnvironment environment)
        {
            try
            {
                environment.CountryCode = countryCode;
                var result = await _countryEnvironmentService.UpdateCountryEnvironmentAsync(environment);
                if (result == null)
                    return NotFound(new { message = $"Country environment for {countryCode} not found" });

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error updating country environment", error = ex.Message });
            }
        }

        /// <summary>
        /// Delete a country environment
        /// </summary>
        [HttpDelete("countries/{countryCode}")]
        public async Task<IActionResult> DeleteCountryEnvironment(string countryCode)
        {
            try
            {
                var result = await _countryEnvironmentService.DeleteCountryEnvironmentAsync(countryCode);
                if (!result)
                    return NotFound(new { message = $"Country environment for {countryCode} not found" });

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error deleting country environment", error = ex.Message });
            }
        }

        /// <summary>
        /// Get countries by region
        /// </summary>
        [HttpGet("regions/{region}")]
        public async Task<IActionResult> GetCountriesByRegion(string region)
        {
            try
            {
                var countries = await _countryEnvironmentService.GetCountriesByRegionAsync(region);
                return Ok(countries);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving countries by region", error = ex.Message });
            }
        }

        /// <summary>
        /// Get country-specific configuration
        /// </summary>
        [HttpGet("countries/{countryCode}/config/{configType}")]
        public async Task<IActionResult> GetCountrySpecificConfig(string countryCode, string configType)
        {
            try
            {
                var config = await _countryEnvironmentService.GetCountrySpecificConfigAsync(countryCode, configType);
                if (config == null)
                    return NotFound(new { message = $"Configuration {configType} for {countryCode} not found" });

                return Ok(config);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving country configuration", error = ex.Message });
            }
        }

        /// <summary>
        /// Get work processes for a specific country
        /// </summary>
        [HttpGet("countries/{countryCode}/work-processes")]
        public async Task<IActionResult> GetCountryWorkProcesses(string countryCode)
        {
            try
            {
                var processes = await _countryEnvironmentService.GetCountryWorkProcessesAsync(countryCode);
                return Ok(processes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving country work processes", error = ex.Message });
            }
        }

        /// <summary>
        /// Create a work process for a specific country
        /// </summary>
        [HttpPost("countries/{countryCode}/work-processes")]
        public async Task<IActionResult> CreateCountryWorkProcess(string countryCode, [FromBody] CountryWorkProcess process)
        {
            try
            {
                var result = await _countryEnvironmentService.CreateCountryWorkProcessAsync(countryCode, process);
                return CreatedAtAction(nameof(GetCountryWorkProcesses), new { countryCode = countryCode }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error creating country work process", error = ex.Message });
            }
        }

        /// <summary>
        /// Get all regions available
        /// </summary>
        [HttpGet("regions")]
        public async Task<IActionResult> GetAllRegions()
        {
            try
            {
                var regions = await _countryEnvironmentService.GetAllRegionsAsync();
                return Ok(regions);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving regions", error = ex.Message });
            }
        }

        /// <summary>
        /// Get country environment statistics
        /// </summary>
        [HttpGet("statistics")]
        public async Task<IActionResult> GetCountryEnvironmentStatistics()
        {
            try
            {
                var stats = await _countryEnvironmentService.GetCountryEnvironmentStatisticsAsync();
                return Ok(stats);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving statistics", error = ex.Message });
            }
        }
    }
}