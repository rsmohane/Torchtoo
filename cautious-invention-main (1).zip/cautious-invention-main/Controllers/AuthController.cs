using HumanAssist.Data;
using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthenticationService _authService;
    private readonly IAuditService _auditService;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
        IAuthenticationService authService,
        IAuditService auditService,
        ILogger<AuthController> logger)
    {
        _authService = authService;
        _auditService = auditService;
        _logger = logger;
    }

    [HttpPost("register")]
    public async Task<ActionResult<object>> Register([FromBody] RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest("Email and password are required");

        var (success, user, error) = await _authService.RegisterAsync(request.Email, request.Password, request.FirstName, request.LastName);
        
        if (!success)
            return BadRequest(new { error });

        await _auditService.LogActionAsync(user?.Id, "Register", "User", user?.Id, "New user registration", HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return Ok(new { message = "Registration successful", user });
    }

    [HttpPost("login")]
    public async Task<ActionResult<object>> Login([FromBody] LoginRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest("Email and password are required");

        var (success, token, refreshToken, error) = await _authService.LoginAsync(request.Email, request.Password);
        
        if (!success)
            return Unauthorized(new { error });

        var ipAddress = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "";
        await _auditService.LogActionAsync(null, "Login", "User", null, request.Email, ipAddress);

        return Ok(new { token, refreshToken, expiresIn = "3600 seconds" });
    }

    [HttpPost("refresh-token")]
    public async Task<ActionResult<object>> RefreshToken([FromBody] RefreshTokenRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.RefreshToken))
            return BadRequest("Refresh token is required");

        var (success, token, error) = await _authService.RefreshTokenAsync(request.RefreshToken);
        
        if (!success)
            return Unauthorized(new { error });

        return Ok(new { token, expiresIn = "3600 seconds" });
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
        {
            await _authService.LogoutAsync(userId);
            await _auditService.LogActionAsync(userId, "Logout", "User", userId, "", HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");
            return Ok(new { message = "Logged out successfully" });
        }

        return BadRequest("Invalid user");
    }

    [Authorize]
    [HttpGet("profile")]
    public ActionResult<object> GetProfile()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        var emailClaim = User.FindFirst(ClaimTypes.Email);
        var nameClaim = User.FindFirst(ClaimTypes.Name);
        var roleClaim = User.FindFirst("role");

        return Ok(new
        {
            userId = userIdClaim?.Value,
            email = emailClaim?.Value,
            name = nameClaim?.Value,
            role = roleClaim?.Value
        });
    }
}

public class RegisterRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
}

public class LoginRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public class RefreshTokenRequest
{
    public string RefreshToken { get; set; } = string.Empty;
}
