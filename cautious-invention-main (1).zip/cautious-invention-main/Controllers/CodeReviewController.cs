namespace HumanAssist.Controllers;

using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class CodeReviewController : ControllerBase
{
    private readonly ICodeReviewService _reviewService;
    private readonly ILogger<CodeReviewController> _logger;

    public CodeReviewController(
        ICodeReviewService reviewService,
        ILogger<CodeReviewController> logger)
    {
        _reviewService = reviewService;
        _logger = logger;
    }

    [HttpPost("analyze")]
    public async Task<IActionResult> AnalyzeCode([FromBody] CodeAnalysisRequest request)
    {
        var (success, analysis, error) = await _reviewService.AnalyzeCodeAsync(request.Code, request.Language);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Analyzed {Language} code", request.Language);
        return Ok(analysis);
    }

    [HttpPost("review")]
    public async Task<IActionResult> ReviewCode([FromBody] CodeReviewRequest request)
    {
        var (success, feedback, error) = await _reviewService.ReviewCodeAsync(request.Code, request.Language, request.Description);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Reviewed {Language} code for: {Description}", request.Language, request.Description);
        return Ok(feedback);
    }

    [HttpPost("metrics")]
    public async Task<IActionResult> CalculateCodeMetrics([FromBody] CodeMetricsRequest request)
    {
        var (success, metrics, error) = await _reviewService.CalculateCodeMetricsAsync(request.Code, request.Language);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Calculated metrics for {Language} code", request.Language);
        return Ok(metrics);
    }

    [HttpPost("security")]
    public async Task<IActionResult> DetectSecurityIssues([FromBody] CodeAnalysisRequest request)
    {
        var (success, issues, error) = await _reviewService.DetectSecurityIssuesAsync(request.Code, request.Language);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Detected {Count} security issues in {Language} code", issues?.Count ?? 0, request.Language);
        return Ok(new { issues, count = issues?.Count ?? 0 });
    }

    [HttpPost("suggestions")]
    public async Task<IActionResult> SuggestImprovements([FromBody] CodeAnalysisRequest request)
    {
        var (success, suggestions, error) = await _reviewService.SuggestImprovementsAsync(request.Code, request.Language);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Generated {Count} improvement suggestions for {Language}", suggestions?.Count ?? 0, request.Language);
        return Ok(new { suggestions, count = suggestions?.Count ?? 0 });
    }

    [HttpPost("full-review")]
    public async Task<IActionResult> FullCodeReview([FromBody] FullCodeReviewRequest request)
    {
        var analysisTask = _reviewService.AnalyzeCodeAsync(request.Code, request.Language);
        var metricsTask = _reviewService.CalculateCodeMetricsAsync(request.Code, request.Language);
        var securityTask = _reviewService.DetectSecurityIssuesAsync(request.Code, request.Language);
        var suggestionsTask = _reviewService.SuggestImprovementsAsync(request.Code, request.Language);

        await Task.WhenAll(analysisTask, metricsTask, securityTask, suggestionsTask);

        var analysisResult = await analysisTask;
        var metricsResult = await metricsTask;
        var securityResult = await securityTask;
        var suggestionsResult = await suggestionsTask;

        var review = new
        {
            language = request.Language,
            analysis = analysisResult.analysis,
            metrics = metricsResult.metrics,
            securityIssues = securityResult.issues,
            suggestions = suggestionsResult.suggestions,
            timestamp = DateTime.UtcNow
        };

        _logger.LogInformation("Completed full code review for {Language}", request.Language);
        return Ok(review);
    }
}

public class CodeAnalysisRequest
{
    public string Code { get; set; } = string.Empty;
    public string Language { get; set; } = "csharp";
}

public class CodeReviewRequest : CodeAnalysisRequest
{
    public string Description { get; set; } = string.Empty;
}

public class CodeMetricsRequest : CodeAnalysisRequest
{
}

public class FullCodeReviewRequest : CodeAnalysisRequest
{
}
