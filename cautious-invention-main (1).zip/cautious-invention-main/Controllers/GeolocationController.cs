using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class GeolocationController : ControllerBase
{
    private readonly IGeolocationService _geolocationService;
    private readonly ILogger<GeolocationController> _logger;

    public GeolocationController(
        IGeolocationService geolocationService,
        ILogger<GeolocationController> logger)
    {
        _geolocationService = geolocationService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [AllowAnonymous]
    [HttpGet("ip/{ipAddress}")]
    public async Task<ActionResult<object>> GetLocationByIp(string ipAddress)
    {
        if (!IPAddress.TryParse(ipAddress, out _))
            return BadRequest("Invalid IP address");

        var (success, data, error) = await _geolocationService.GetGeolocationByIpAsync(ipAddress);
        
        if (!success)
            return BadRequest(error);

        return Ok(new { success = true, data });
    }

    [HttpGet("coordinates")]
    public async Task<ActionResult<object>> GetLocationByCoordinates([FromQuery] double latitude, [FromQuery] double longitude)
    {
        if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180)
            return BadRequest("Invalid coordinates");

        var (success, data, error) = await _geolocationService.GetGeolocationByCoordinatesAsync(latitude, longitude);
        
        if (!success)
            return BadRequest(error);

        var userId = GetUserId();
        if (userId > 0)
            await _geolocationService.LogLocationAccessAsync(userId, latitude, longitude, "query");

        return Ok(new { success = true, data });
    }

    [HttpGet("timezone")]
    public async Task<ActionResult<object>> GetTimezone([FromQuery] double latitude, [FromQuery] double longitude)
    {
        var (success, timezone, error) = await _geolocationService.GetTimezoneAsync(latitude, longitude);
        
        if (!success)
            return BadRequest(error);

        return Ok(new { success = true, timezone });
    }

    [HttpGet("permission")]
    public async Task<ActionResult<object>> CheckPermission()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, isAllowed, error) = await _geolocationService.CheckGeolocationPermissionAsync(userId);
        
        if (!success)
            return BadRequest(error);

        return Ok(new { success = true, isAllowed });
    }

    [HttpPost("permission")]
    public async Task<ActionResult<object>> SetPermission([FromBody] SetGeolocationPermissionRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var success = await _geolocationService.SetGeolocationPreferenceAsync(userId, request.AllowTracking, request.AllowedCountries);
        
        if (!success)
            return BadRequest("Failed to set preference");

        return Ok(new { success = true });
    }

    [HttpGet("history")]
    public async Task<ActionResult<object>> GetLocationHistory([FromQuery] int limit = 50)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var history = await _geolocationService.GetUserLocationHistoryAsync(userId, limit);
        return Ok(new { success = true, data = history });
    }
}

public class SetGeolocationPermissionRequest
{
    public bool AllowTracking { get; set; }
    public List<string>? AllowedCountries { get; set; }
}
