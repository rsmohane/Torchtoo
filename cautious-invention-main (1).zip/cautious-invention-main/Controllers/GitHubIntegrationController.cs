namespace HumanAssist.Controllers;

using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class GitHubIntegrationController : ControllerBase
{
    private readonly IGitHubIntegrationService _githubService;
    private readonly ILogger<GitHubIntegrationController> _logger;

    public GitHubIntegrationController(
        IGitHubIntegrationService githubService,
        ILogger<GitHubIntegrationController> logger)
    {
        _githubService = githubService;
        _logger = logger;
    }

    [HttpGet("repo/{owner}/{repo}")]
    public async Task<IActionResult> GetRepository(string owner, string repo)
    {
        var (success, repository, error) = await _githubService.GetRepositoryAsync(owner, repo);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved GitHub repository: {Owner}/{Repo}", owner, repo);
        return Ok(repository);
    }

    [HttpGet("user/{username}/repos")]
    public async Task<IActionResult> ListUserRepositories(string username)
    {
        var (success, repos, error) = await _githubService.ListUserRepositoriesAsync(username);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Listed repositories for user: {Username}", username);
        return Ok(new { repositories = repos, count = repos?.Count ?? 0 });
    }

    [HttpGet("repo/{owner}/{repo}/issues")]
    public async Task<IActionResult> ListRepositoryIssues(string owner, string repo)
    {
        var (success, issues, error) = await _githubService.ListRepositoryIssuesAsync(owner, repo);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Listed issues for {Owner}/{Repo}", owner, repo);
        return Ok(new { issues, count = issues?.Count ?? 0 });
    }

    [HttpGet("repo/{owner}/{repo}/pulls/{prNumber}")]
    public async Task<IActionResult> GetPullRequest(string owner, string repo, int prNumber)
    {
        var (success, pr, error) = await _githubService.GetPullRequestAsync(owner, repo, prNumber);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved PR #{Number} from {Owner}/{Repo}", prNumber, owner, repo);
        return Ok(pr);
    }

    [HttpGet("repo/{owner}/{repo}/commits")]
    public async Task<IActionResult> GetRepositoryCommits(string owner, string repo, [FromQuery] int limit = 10)
    {
        var (success, commits, error) = await _githubService.GetRepositoryCommitsAsync(owner, repo, limit);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved {Count} commits from {Owner}/{Repo}", commits?.Count ?? 0, owner, repo);
        return Ok(new { commits, count = commits?.Count ?? 0 });
    }

    [HttpGet("repo/{owner}/{repo}/content")]
    public async Task<IActionResult> GetFileContent(string owner, string repo, [FromQuery] string filePath)
    {
        if (string.IsNullOrEmpty(filePath))
            return BadRequest(new { error = "filePath parameter is required" });

        var (success, content, error) = await _githubService.GetFileContentAsync(owner, repo, filePath);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved file content from {Owner}/{Repo}: {FilePath}", owner, repo, filePath);
        return Ok(new { content });
    }

    [HttpGet("repo/{owner}/{repo}/releases")]
    public async Task<IActionResult> GetRepositoryReleases(string owner, string repo)
    {
        var (success, releases, error) = await _githubService.GetRepositoryReleasesAsync(owner, repo);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved releases from {Owner}/{Repo}", owner, repo);
        return Ok(new { releases, count = releases?.Count ?? 0 });
    }

    [HttpGet("user/{username}")]
    public async Task<IActionResult> GetUserInfo(string username)
    {
        var (success, user, error) = await _githubService.GetUserInfoAsync(username);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved user info: {Username}", username);
        return Ok(user);
    }
}
