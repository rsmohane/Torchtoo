namespace HumanAssist.Controllers;

using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class GoogleIntegrationController : ControllerBase
{
    private readonly IGoogleApiIntegrationService _googleService;
    private readonly ILogger<GoogleIntegrationController> _logger;

    public GoogleIntegrationController(
        IGoogleApiIntegrationService googleService,
        ILogger<GoogleIntegrationController> logger)
    {
        _googleService = googleService;
        _logger = logger;
    }

    [HttpPost("authenticate")]
    [AllowAnonymous]
    public async Task<IActionResult> AuthenticateGoogle([FromBody] string accessToken)
    {
        var (success, result, error) = await _googleService.AuthenticateGoogleAsync(accessToken);
        if (!success)
            return BadRequest(new { error });

        return Ok(new { message = "Google authentication successful", data = result });
    }

    [HttpGet("sheets/{spreadsheetId}")]
    public async Task<IActionResult> GetGoogleSheets(string spreadsheetId, [FromQuery] string range = "Sheet1")
    {
        var (success, data, error) = await _googleService.GetGoogleSheetsAsync(spreadsheetId, range);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved Google Sheets data");
        return Ok(data);
    }

    [HttpPost("sheets/{spreadsheetId}")]
    public async Task<IActionResult> WriteGoogleSheets(string spreadsheetId, [FromBody] WriteGoogleSheetsRequest request)
    {
        var (success, error) = await _googleService.WriteGoogleSheetsAsync(spreadsheetId, request.Range, request.Values);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Wrote data to Google Sheets");
        return Ok(new { message = "Data written successfully" });
    }

    [HttpGet("drive/files")]
    public async Task<IActionResult> ListGoogleDriveFiles()
    {
        var (success, files, error) = await _googleService.ListGoogleDriveFilesAsync();
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Listed Google Drive files");
        return Ok(new { files });
    }

    [HttpGet("drive/files/{fileId}")]
    public async Task<IActionResult> ReadGoogleDriveFile(string fileId)
    {
        var (success, content, error) = await _googleService.ReadGoogleDriveFileAsync(fileId);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Read Google Drive file");
        return Ok(new { content });
    }

    [HttpPost("gmail/send")]
    public async Task<IActionResult> SendGoogleGmail([FromBody] SendGmailRequest request)
    {
        var (success, error) = await _googleService.SendGoogleGmailAsync(request.To, request.Subject, request.Body);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Sent Google Gmail");
        return Ok(new { message = "Email sent successfully" });
    }

    [HttpGet("gmail/messages")]
    public async Task<IActionResult> GetGoogleGmail([FromQuery] string query = "is:unread", [FromQuery] int limit = 10)
    {
        var (success, emails, error) = await _googleService.GetGoogleGmailAsync(query, limit);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Retrieved Gmail messages");
        return Ok(new { emails });
    }
}

public class WriteGoogleSheetsRequest
{
    public string Range { get; set; } = "Sheet1";
    public List<List<object>> Values { get; set; } = new();
}

public class SendGmailRequest
{
    public string To { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
}
