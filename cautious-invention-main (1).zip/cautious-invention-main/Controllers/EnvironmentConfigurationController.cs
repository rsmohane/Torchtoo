namespace HumanAssist.Controllers;

using HumanAssist.Models;
using HumanAssist.Services;
using EnvironmentConfigModel = HumanAssist.Models.EnvironmentConfig;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class EnvironmentConfigurationController : ControllerBase
{
    private readonly IMultiEnvironmentConfigurationService _environmentService;
    private readonly ILogger<EnvironmentConfigurationController> _logger;

    public EnvironmentConfigurationController(
        IMultiEnvironmentConfigurationService environmentService,
        ILogger<EnvironmentConfigurationController> logger)
    {
        _environmentService = environmentService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId) ? userId : 0;
    }

    /// <summary>
    /// Get a specific environment configuration
    /// </summary>
    /// <param name="environmentName">The name of the environment</param>
    /// <returns>The environment configuration</returns>
    [HttpGet("{environmentName}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEnvironmentConfig(string environmentName)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        var (success, config, error) = await _environmentService.GetEnvironmentConfigAsync(environmentName, userId);

        if (!success)
            return NotFound(new { error });

        return Ok(config);
    }

    /// <summary>
    /// List all environment configurations for the user
    /// </summary>
    /// <returns>List of environment configurations</returns>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ListEnvironmentConfigs()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        var configs = await _environmentService.ListEnvironmentConfigsAsync(userId);
        return Ok(configs);
    }

    /// <summary>
    /// Create a new environment configuration
    /// </summary>
    /// <param name="config">The environment configuration to create</param>
    /// <returns>Success or error message</returns>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateEnvironmentConfig([FromBody] EnvironmentConfigModel config)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var (success, error) = await _environmentService.CreateEnvironmentConfigAsync(config, userId);

        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("User {UserId} created environment: {Environment}", userId, config.EnvironmentName);
        return CreatedAtAction(nameof(GetEnvironmentConfig), new { environmentName = config.EnvironmentName }, null);
    }

    /// <summary>
    /// Update an existing environment configuration
    /// </summary>
    /// <param name="environmentName">The name of the environment</param>
    /// <param name="config">The updated configuration</param>
    /// <returns>Success or error message</returns>
    [HttpPut("{environmentName}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEnvironmentConfig(string environmentName, [FromBody] EnvironmentConfigModel config)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        config.EnvironmentName = environmentName;

        var (success, error) = await _environmentService.UpdateEnvironmentConfigAsync(config, userId);

        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("User {UserId} updated environment: {Environment}", userId, environmentName);
        return Ok(new { message = "Environment updated successfully" });
    }

    /// <summary>
    /// Delete an environment configuration
    /// </summary>
    /// <param name="environmentName">The name of the environment</param>
    /// <returns>Success or error message</returns>
    [HttpDelete("{environmentName}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteEnvironmentConfig(string environmentName)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        var (success, error) = await _environmentService.DeleteEnvironmentConfigAsync(environmentName, userId);

        if (!success)
            return NotFound(new { error });

        _logger.LogInformation("User {UserId} deleted environment: {Environment}", userId, environmentName);
        return Ok(new { message = "Environment deleted successfully" });
    }

    /// <summary>
    /// Switch between two environments
    /// </summary>
    /// <param name="fromEnvironment">Source environment</param>
    /// <param name="toEnvironment">Target environment</param>
    /// <returns>Success or error message</returns>
    [HttpPost("switch")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SwitchEnvironment([FromQuery] string fromEnvironment, [FromQuery] string toEnvironment)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        if (string.IsNullOrEmpty(fromEnvironment) || string.IsNullOrEmpty(toEnvironment))
            return BadRequest(new { error = "Both fromEnvironment and toEnvironment parameters are required" });

        var (success, error) = await _environmentService.SwitchEnvironmentAsync(userId, fromEnvironment, toEnvironment);

        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("User {UserId} switched from {From} to {To}", userId, fromEnvironment, toEnvironment);
        return Ok(new { message = $"Switched from {fromEnvironment} to {toEnvironment}" });
    }

    /// <summary>
    /// Compare two environments
    /// </summary>
    /// <param name="env1">First environment name</param>
    /// <param name="env2">Second environment name</param>
    /// <returns>Comparison of the environments</returns>
    [HttpGet("compare")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CompareEnvironments([FromQuery] string env1, [FromQuery] string env2)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        if (string.IsNullOrEmpty(env1) || string.IsNullOrEmpty(env2))
            return BadRequest(new { error = "Both env1 and env2 parameters are required" });

        var (success, differences, error) = await _environmentService.CompareEnvironmentsAsync(env1, env2, userId);

        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("User {UserId} compared environments: {Env1} vs {Env2}", userId, env1, env2);
        return Ok(new { env1, env2, differences });
    }

    /// <summary>
    /// Clone an environment configuration
    /// </summary>
    /// <param name="sourceEnvironment">Source environment name</param>
    /// <param name="targetEnvironment">Target environment name</param>
    /// <returns>Success or error message</returns>
    [HttpPost("clone")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CloneEnvironment([FromQuery] string sourceEnvironment, [FromQuery] string targetEnvironment)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        if (string.IsNullOrEmpty(sourceEnvironment) || string.IsNullOrEmpty(targetEnvironment))
            return BadRequest(new { error = "Both sourceEnvironment and targetEnvironment parameters are required" });

        var (success, error) = await _environmentService.CloneEnvironmentAsync(sourceEnvironment, targetEnvironment, userId);

        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("User {UserId} cloned environment: {Source} -> {Target}", userId, sourceEnvironment, targetEnvironment);
        return CreatedAtAction(nameof(GetEnvironmentConfig), new { environmentName = targetEnvironment }, null);
    }

    /// <summary>
    /// Get the status of an environment
    /// </summary>
    /// <param name="environmentName">The name of the environment</param>
    /// <returns>Environment status information</returns>
    [HttpGet("{environmentName}/status")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEnvironmentStatus(string environmentName)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        var (success, status, error) = await _environmentService.GetEnvironmentStatusAsync(environmentName, userId);

        if (!success)
            return NotFound(new { error });

        return Ok(status);
    }

    /// <summary>
    /// Get the change history of an environment
    /// </summary>
    /// <param name="environmentName">The name of the environment</param>
    /// <param name="limit">Maximum number of records to retrieve (default: 100)</param>
    /// <returns>List of change audit logs</returns>
    [HttpGet("{environmentName}/history")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEnvironmentChangeHistory(string environmentName, [FromQuery] int limit = 100)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized("Invalid user");

        if (limit <= 0)
            limit = 100;

        var history = await _environmentService.GetEnvironmentChangeHistoryAsync(environmentName, userId, limit);
        return Ok(new { environmentName, recordCount = history.Count, records = history });
    }
}
