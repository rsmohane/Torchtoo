using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ApiKeysController : ControllerBase
{
    private readonly IApiKeyService _apiKeyService;
    private readonly IAuditService _auditService;
    private readonly ILogger<ApiKeysController> _logger;

    public ApiKeysController(
        IApiKeyService apiKeyService,
        IAuditService auditService,
        ILogger<ApiKeysController> logger)
    {
        _apiKeyService = apiKeyService;
        _auditService = auditService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpPost("generate")]
    public async Task<ActionResult<object>> GenerateApiKey([FromBody] GenerateApiKeyRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var (success, key, error) = await _apiKeyService.GenerateApiKeyAsync(userId, request.Name, request.Permissions);
        
        if (!success)
            return BadRequest(new { error });

        await _auditService.LogActionAsync(userId, "GenerateApiKey", "ApiKey", null, request.Name, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return Ok(new { key, message = "API key generated successfully" });
    }

    [HttpGet]
    public async Task<ActionResult<object>> GetApiKeys()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var keys = await _apiKeyService.GetUserApiKeysAsync(userId);
        return Ok(new { keys });
    }

    [HttpDelete("{keyId}")]
    public async Task<IActionResult> RevokeApiKey(int keyId)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var success = await _apiKeyService.RevokeApiKeyAsync(keyId, userId);
        
        if (!success)
            return NotFound();

        await _auditService.LogActionAsync(userId, "RevokeApiKey", "ApiKey", keyId, "", HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }
}

public class GenerateApiKeyRequest
{
    public string Name { get; set; } = string.Empty;
    public string Permissions { get; set; } = "read";
}
