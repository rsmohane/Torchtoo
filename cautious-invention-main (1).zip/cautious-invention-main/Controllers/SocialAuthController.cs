namespace HumanAssist.Controllers;

using HumanAssist.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authentication.Facebook;
using Microsoft.AspNetCore.Authentication.MicrosoftAccount;
using Microsoft.AspNetCore.Authentication.Twitter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
public class SocialAuthController : ControllerBase
{
    private readonly IAuthenticationService _authService;
    private readonly ILogger<SocialAuthController> _logger;

    public SocialAuthController(
        IAuthenticationService authService,
        ILogger<SocialAuthController> logger)
    {
        _authService = authService;
        _logger = logger;
    }

    /// <summary>
    /// Initiate Google OAuth login
    /// </summary>
    /// <returns>Challenge result for Google authentication</returns>
    [HttpGet("google")]
    [AllowAnonymous]
    public IActionResult GoogleLogin()
    {
        var properties = new AuthenticationProperties
        {
            RedirectUri = Url.Action("GoogleCallback", "SocialAuth")
        };
        return Challenge(properties, GoogleDefaults.AuthenticationScheme);
    }

    /// <summary>
    /// Handle Google OAuth callback
    /// </summary>
    /// <returns>JWT token for authenticated user</returns>
    [HttpGet("google/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> GoogleCallback()
    {
        var result = await HttpContext.AuthenticateAsync(GoogleDefaults.AuthenticationScheme);
        if (!result.Succeeded)
            return BadRequest("Google authentication failed");

        var claims = result.Principal.Identities.FirstOrDefault()?.Claims;
        var email = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
        var name = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
        var googleId = claims?.FirstOrDefault(c => c.Type == "sub")?.Value;

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(googleId))
            return BadRequest("Invalid Google authentication response");

        // Check if user exists, create if not
        var (success, token, error) = await _authService.AuthenticateOrCreateSocialUserAsync(
            email, name, "Google", googleId);

        if (!success)
            return BadRequest(error);

        _logger.LogInformation("User authenticated via Google: {Email}", email);
        return Ok(new { token, provider = "Google" });
    }

    /// <summary>
    /// Initiate Facebook OAuth login
    /// </summary>
    /// <returns>Challenge result for Facebook authentication</returns>
    [HttpGet("facebook")]
    [AllowAnonymous]
    public IActionResult FacebookLogin()
    {
        var properties = new AuthenticationProperties
        {
            RedirectUri = Url.Action("FacebookCallback", "SocialAuth")
        };
        return Challenge(properties, FacebookDefaults.AuthenticationScheme);
    }

    /// <summary>
    /// Handle Facebook OAuth callback
    /// </summary>
    /// <returns>JWT token for authenticated user</returns>
    [HttpGet("facebook/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> FacebookCallback()
    {
        var result = await HttpContext.AuthenticateAsync(FacebookDefaults.AuthenticationScheme);
        if (!result.Succeeded)
            return BadRequest("Facebook authentication failed");

        var claims = result.Principal.Identities.FirstOrDefault()?.Claims;
        var email = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
        var name = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
        var facebookId = claims?.FirstOrDefault(c => c.Type == "id")?.Value;

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(facebookId))
            return BadRequest("Invalid Facebook authentication response");

        var (success, token, error) = await _authService.AuthenticateOrCreateSocialUserAsync(
            email, name, "Facebook", facebookId);

        if (!success)
            return BadRequest(error);

        _logger.LogInformation("User authenticated via Facebook: {Email}", email);
        return Ok(new { token, provider = "Facebook" });
    }

    /// <summary>
    /// Initiate Microsoft OAuth login
    /// </summary>
    /// <returns>Challenge result for Microsoft authentication</returns>
    [HttpGet("microsoft")]
    [AllowAnonymous]
    public IActionResult MicrosoftLogin()
    {
        var properties = new AuthenticationProperties
        {
            RedirectUri = Url.Action("MicrosoftCallback", "SocialAuth")
        };
        return Challenge(properties, MicrosoftAccountDefaults.AuthenticationScheme);
    }

    /// <summary>
    /// Handle Microsoft OAuth callback
    /// </summary>
    /// <returns>JWT token for authenticated user</returns>
    [HttpGet("microsoft/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> MicrosoftCallback()
    {
        var result = await HttpContext.AuthenticateAsync(MicrosoftAccountDefaults.AuthenticationScheme);
        if (!result.Succeeded)
            return BadRequest("Microsoft authentication failed");

        var claims = result.Principal.Identities.FirstOrDefault()?.Claims;
        var email = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
        var name = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
        var microsoftId = claims?.FirstOrDefault(c => c.Type == "sub")?.Value;

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(microsoftId))
            return BadRequest("Invalid Microsoft authentication response");

        var (success, token, error) = await _authService.AuthenticateOrCreateSocialUserAsync(
            email, name, "Microsoft", microsoftId);

        if (!success)
            return BadRequest(error);

        _logger.LogInformation("User authenticated via Microsoft: {Email}", email);
        return Ok(new { token, provider = "Microsoft" });
    }

    /// <summary>
    /// Initiate Twitter OAuth login
    /// </summary>
    /// <returns>Challenge result for Twitter authentication</returns>
    [HttpGet("twitter")]
    [AllowAnonymous]
    public IActionResult TwitterLogin()
    {
        var properties = new AuthenticationProperties
        {
            RedirectUri = Url.Action("TwitterCallback", "SocialAuth")
        };
        return Challenge(properties, TwitterDefaults.AuthenticationScheme);
    }

    /// <summary>
    /// Handle Twitter OAuth callback
    /// </summary>
    /// <returns>JWT token for authenticated user</returns>
    [HttpGet("twitter/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> TwitterCallback()
    {
        var result = await HttpContext.AuthenticateAsync(TwitterDefaults.AuthenticationScheme);
        if (!result.Succeeded)
            return BadRequest("Twitter authentication failed");

        var claims = result.Principal.Identities.FirstOrDefault()?.Claims;
        var name = claims?.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
        var twitterId = claims?.FirstOrDefault(c => c.Type == "urn:twitter:id")?.Value;
        var screenName = claims?.FirstOrDefault(c => c.Type == "urn:twitter:screenname")?.Value;

        // Twitter doesn't always provide email, so we'll use screen name as identifier
        var email = $"{screenName}@twitter.local"; // Placeholder email for Twitter users

        if (string.IsNullOrEmpty(twitterId))
            return BadRequest("Invalid Twitter authentication response");

        var (success, token, error) = await _authService.AuthenticateOrCreateSocialUserAsync(
            email, name, "Twitter", twitterId);

        if (!success)
            return BadRequest(error);

        _logger.LogInformation("User authenticated via Twitter: {ScreenName}", screenName);
        return Ok(new { token, provider = "Twitter" });
    }

    /// <summary>
    /// Get available social login providers
    /// </summary>
    /// <returns>List of available providers</returns>
    [HttpGet("providers")]
    [AllowAnonymous]
    public IActionResult GetProviders()
    {
        var providers = new[]
        {
            new { name = "Google", url = Url.Action("GoogleLogin", "SocialAuth") },
            new { name = "Facebook", url = Url.Action("FacebookLogin", "SocialAuth") },
            new { name = "Microsoft", url = Url.Action("MicrosoftLogin", "SocialAuth") },
            new { name = "Twitter", url = Url.Action("TwitterLogin", "SocialAuth") }
        };

        return Ok(providers);
    }
}
