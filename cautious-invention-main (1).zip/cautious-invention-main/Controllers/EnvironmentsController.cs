using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using EnvironmentModel = HumanAssist.Models.Environment;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class EnvironmentsController : ControllerBase
{
    private readonly IEnvironmentService _environmentService;
    private readonly IAuditService _auditService;
    private readonly ILogger<EnvironmentsController> _logger;

    public EnvironmentsController(
        IEnvironmentService environmentService,
        IAuditService auditService,
        ILogger<EnvironmentsController> logger)
    {
        _environmentService = environmentService;
        _auditService = auditService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpPost]
    public async Task<ActionResult<object>> CreateEnvironment([FromBody] CreateEnvironmentRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var environment = new EnvironmentModel
        {
            UserId = userId,
            Name = request.Name,
            Type = request.Type,
            EnvironmentUrl = request.EnvironmentUrl,
            Description = request.Description
        };

        var created = await _environmentService.CreateEnvironmentAsync(environment);
        await _auditService.LogActionAsync(userId, "CreateEnvironment", "Environment", created.Id, request.Name, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return CreatedAtAction("GetEnvironment", new { id = created.Id }, created);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetEnvironment(int id)
    {
        var environment = await _environmentService.GetEnvironmentAsync(id);
        if (environment == null)
            return NotFound();

        return Ok(environment);
    }

    [HttpGet]
    public async Task<ActionResult<object>> GetUserEnvironments()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var environments = await _environmentService.GetUserEnvironmentsAsync(userId);
        return Ok(new { environments });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateEnvironment(int id, [FromBody] UpdateEnvironmentRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var environment = await _environmentService.GetEnvironmentAsync(id);
        if (environment == null || environment.UserId != userId)
            return Forbid();

        environment.Name = request.Name;
        environment.Description = request.Description;
        environment.EnvironmentUrl = request.EnvironmentUrl;

        var success = await _environmentService.UpdateEnvironmentAsync(environment);
        if (!success)
            return BadRequest();

        await _auditService.LogActionAsync(userId, "UpdateEnvironment", "Environment", id, request.Name, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteEnvironment(int id)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var success = await _environmentService.DeleteEnvironmentAsync(id, userId);
        if (!success)
            return NotFound();

        await _auditService.LogActionAsync(userId, "DeleteEnvironment", "Environment", id, "", HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }

    [HttpPost("{id}/variables")]
    public async Task<IActionResult> SetEnvironmentVariables(int id, [FromBody] Dictionary<string, string> variables)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var environment = await _environmentService.GetEnvironmentAsync(id);
        if (environment == null || environment.UserId != userId)
            return Forbid();

        var success = await _environmentService.UpdateEnvironmentVariablesAsync(id, variables);
        if (!success)
            return BadRequest();

        await _auditService.LogActionAsync(userId, "SetEnvironmentVariables", "Environment", id, "Variables updated", HttpContext.Connection.RemoteIpAddress?.ToString() ?? "");

        return NoContent();
    }

    [HttpGet("{id}/variables")]
    public async Task<ActionResult<object>> GetEnvironmentVariables(int id)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var environment = await _environmentService.GetEnvironmentAsync(id);
        if (environment == null || environment.UserId != userId)
            return Forbid();

        var variables = await _environmentService.GetEnvironmentVariablesAsync(id);
        return Ok(new { variables });
    }

    [HttpGet("{id}/access-logs")]
    public async Task<ActionResult<object>> GetAccessLogs(int id, [FromQuery] DateTime? fromDate, [FromQuery] DateTime? toDate)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var environment = await _environmentService.GetEnvironmentAsync(id);
        if (environment == null || environment.UserId != userId)
            return Forbid();

        var logs = await _environmentService.GetAccessLogsAsync(id, fromDate, toDate);
        return Ok(new { logs });
    }

    [HttpPost("{id}/log-access")]
    public async Task<IActionResult> LogAccess(int id, [FromBody] LogAccessRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var log = new EnvironmentAccessLog
        {
            EnvironmentId = id,
            UserId = userId,
            Action = request.Action,
            ResourceAccessed = request.ResourceAccessed,
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "",
            Success = request.Success
        };

        var success = await _environmentService.LogAccessAsync(log);
        if (!success)
            return BadRequest();

        return Ok(new { message = "Access logged" });
    }
}

public class CreateEnvironmentRequest
{
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string EnvironmentUrl { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}

public class UpdateEnvironmentRequest
{
    public string Name { get; set; } = string.Empty;
    public string EnvironmentUrl { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}

public class LogAccessRequest
{
    public string Action { get; set; } = string.Empty;
    public string ResourceAccessed { get; set; } = string.Empty;
    public bool Success { get; set; }
}
