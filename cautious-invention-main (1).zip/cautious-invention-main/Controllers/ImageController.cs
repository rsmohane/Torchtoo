using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ImageController : ControllerBase
{
    private readonly IImageService _imageService;
    private readonly ILogger<ImageController> _logger;

    public ImageController(
        IImageService imageService,
        ILogger<ImageController> logger)
    {
        _imageService = imageService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpPost("generate")]
    public async Task<ActionResult> GenerateImage([FromBody] GenerateImageRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (string.IsNullOrEmpty(request.Prompt))
            return BadRequest("Prompt is required");

        var (success, imageUrl, error) = await _imageService.GenerateImageAsync(request.Prompt, request.Style, userId);
        
        if (!success)
            return BadRequest(error);

        return Ok(new { success = true, imageUrl });
    }

    [HttpPost("analyze")]
    public async Task<ActionResult> AnalyzeImage([FromForm] IFormFile imageFile)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (imageFile == null || imageFile.Length == 0)
            return BadRequest("No image file provided");

        using (var stream = imageFile.OpenReadStream())
        {
            var (success, description, error) = await _imageService.AnalyzeImageAsync(stream, userId);
            
            if (!success)
                return BadRequest(error);

            return Ok(new { success = true, description });
        }
    }

    [HttpPost("process")]
    public async Task<ActionResult> ProcessImage([FromForm] IFormFile imageFile, [FromForm] string operation)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (imageFile == null || imageFile.Length == 0)
            return BadRequest("No image file provided");

        using (var stream = imageFile.OpenReadStream())
        {
            var (success, processedImage, error) = await _imageService.ProcessImageAsync(stream, operation, userId);
            
            if (!success)
                return BadRequest(error);

            return File(processedImage, "image/jpeg", "processed.jpg");
        }
    }

    [HttpPost("video/generate")]
    public async Task<ActionResult> GenerateVideo([FromBody] GenerateVideoRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (string.IsNullOrEmpty(request.Prompt))
            return BadRequest("Prompt is required");

        var (success, videoStream, error) = await _imageService.GenerateVideoAsync(request.Prompt, request.DurationSeconds, userId);
        
        if (!success)
            return BadRequest(error);

        return File(videoStream, "video/mp4", "generated.mp4");
    }

    [HttpPost("extract-text")]
    public async Task<ActionResult> ExtractTextFromImage([FromForm] IFormFile imageFile)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        if (imageFile == null || imageFile.Length == 0)
            return BadRequest("No image file provided");

        using (var stream = imageFile.OpenReadStream())
        {
            var (success, results, error) = await _imageService.ExtractTextFromImageAsync(stream, userId);
            
            if (!success)
                return BadRequest(error);

            return Ok(new { success = true, extractedText = results });
        }
    }
}

public class GenerateImageRequest
{
    public string Prompt { get; set; } = string.Empty;
    public string Style { get; set; } = "natural";
}

public class GenerateVideoRequest
{
    public string Prompt { get; set; } = string.Empty;
    public int DurationSeconds { get; set; } = 5;
}
