using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HumanAssist.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ApiKeyMonitoringController : ControllerBase
{
    private readonly IApiKeyMonitoringService _monitoringService;
    private readonly IApiKeyService _apiKeyService;
    private readonly ILogger<ApiKeyMonitoringController> _logger;

    public ApiKeyMonitoringController(
        IApiKeyMonitoringService monitoringService,
        IApiKeyService apiKeyService,
        ILogger<ApiKeyMonitoringController> logger)
    {
        _monitoringService = monitoringService;
        _apiKeyService = apiKeyService;
        _logger = logger;
    }

    private int GetUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
        return int.TryParse(userIdClaim?.Value, out int userId) ? userId : 0;
    }

    [HttpGet("{keyId}/health")]
    public async Task<ActionResult<object>> CheckApiKeyHealth(int keyId)
    {
        var (healthy, message) = await _monitoringService.CheckApiKeyHealthAsync(keyId);
        return Ok(new { healthy, message });
    }

    [HttpGet("{keyId}/metrics")]
    public async Task<ActionResult<object>> GetApiKeyMetrics(int keyId)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var metrics = await _monitoringService.GetApiKeyMetricsAsync(keyId);
        return Ok(metrics);
    }

    [HttpGet("statistics")]
    public async Task<ActionResult<object>> GetApiKeyStatistics()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var stats = await _monitoringService.GetUserApiKeyStatisticsAsync(userId);
        return Ok(new { statistics = stats });
    }

    [HttpGet("{keyId}/statistics")]
    public async Task<ActionResult<object>> GetApiKeyStatisticsByDateRange(
        int keyId,
        [FromQuery] DateTime? fromDate,
        [FromQuery] DateTime? toDate)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var from = fromDate ?? DateTime.UtcNow.AddDays(-30);
        var to = toDate ?? DateTime.UtcNow;

        var stats = await _monitoringService.GetApiKeyStatisticsAsync(keyId, from, to);
        return Ok(stats);
    }

    [HttpPost("{keyId}/record-usage")]
    public async Task<IActionResult> RecordApiKeyUsage(int keyId, [FromBody] RecordUsageRequest request)
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        await _monitoringService.RecordApiKeyUsageAsync(keyId, request.Success, request.ResponseTimeMs);
        return Ok(new { message = "Usage recorded" });
    }

    [HttpGet("dashboard")]
    public async Task<ActionResult<object>> GetApiKeyDashboard()
    {
        var userId = GetUserId();
        if (userId == 0)
            return Unauthorized();

        var stats = await _monitoringService.GetUserApiKeyStatisticsAsync(userId);
        var keys = await _apiKeyService.GetUserApiKeysAsync(userId);

        var dashboard = new
        {
            totalApiKeys = keys.Count,
            activeApiKeys = keys.Count(k => k.IsActive),
            totalRequests = stats.Sum(s => s.RequestsCount),
            successfulRequests = stats.Sum(s => s.SuccessfulRequests),
            failedRequests = stats.Sum(s => s.FailedRequests),
            avgResponseTime = stats.Any() ? stats.Average(s => s.AverageResponseTimeMs) : 0,
            statistics = stats
        };

        return Ok(dashboard);
    }
}

public class RecordUsageRequest
{
    public bool Success { get; set; }
    public int ResponseTimeMs { get; set; }
}
