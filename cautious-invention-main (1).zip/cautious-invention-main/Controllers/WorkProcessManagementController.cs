using HumanAssist.Controllers;
using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HumanAssist.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class WorkProcessManagementController : ControllerBase
    {
        private readonly IWorkProcessManagementService _workProcessService;

        public WorkProcessManagementController(IWorkProcessManagementService workProcessService)
        {
            _workProcessService = workProcessService;
        }

        /// <summary>
        /// Create a new work process
        /// </summary>
        [HttpPost("processes")]
        public async Task<IActionResult> CreateWorkProcess([FromBody] WorkProcess process)
        {
            try
            {
                var result = await _workProcessService.CreateWorkProcessAsync(process, GetCurrentUserId());
                return CreatedAtAction(nameof(GetWorkProcess), new { processId = result.Id }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error creating work process", error = ex.Message });
            }
        }

        /// <summary>
        /// Get a work process by ID
        /// </summary>
        [HttpGet("processes/{processId}")]
        public async Task<IActionResult> GetWorkProcess(int processId)
        {
            try
            {
                var process = await _workProcessService.GetWorkProcessAsync(processId, GetCurrentUserId());
                if (process == null)
                    return NotFound(new { message = $"Work process {processId} not found" });

                return Ok(process);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving work process", error = ex.Message });
            }
        }

        /// <summary>
        /// Get all work processes for the current user
        /// </summary>
        [HttpGet("processes")]
        public async Task<IActionResult> GetUserWorkProcesses()
        {
            try
            {
                var processes = await _workProcessService.GetUserWorkProcessesAsync(GetCurrentUserId());
                return Ok(processes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving work processes", error = ex.Message });
            }
        }

        /// <summary>
        /// Update a work process
        /// </summary>
        [HttpPut("processes/{processId}")]
        public async Task<IActionResult> UpdateWorkProcess(int processId, [FromBody] WorkProcess process)
        {
            try
            {
                process.Id = processId;
                var result = await _workProcessService.UpdateWorkProcessAsync(process, GetCurrentUserId());
                if (result == null)
                    return NotFound(new { message = $"Work process {processId} not found" });

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error updating work process", error = ex.Message });
            }
        }

        /// <summary>
        /// Delete a work process
        /// </summary>
        [HttpDelete("processes/{processId}")]
        public async Task<IActionResult> DeleteWorkProcess(int processId)
        {
            try
            {
                var result = await _workProcessService.DeleteWorkProcessAsync(processId, GetCurrentUserId());
                if (!result)
                    return NotFound(new { message = $"Work process {processId} not found" });

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error deleting work process", error = ex.Message });
            }
        }

        /// <summary>
        /// Handle a situation automatically
        /// </summary>
        [HttpPost("situations/handle")]
        public async Task<IActionResult> HandleSituation([FromBody] Situation situation)
        {
            try
            {
                var result = await _workProcessService.HandleSituationAsync(situation, GetCurrentUserId());
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error handling situation", error = ex.Message });
            }
        }

        /// <summary>
        /// Get all situations for the current user
        /// </summary>
        [HttpGet("situations")]
        public async Task<IActionResult> GetUserSituations()
        {
            try
            {
                var situations = await _workProcessService.GetUserSituationsAsync(GetCurrentUserId());
                return Ok(situations);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving situations", error = ex.Message });
            }
        }

        /// <summary>
        /// Get a specific situation
        /// </summary>
        [HttpGet("situations/{situationId}")]
        public async Task<IActionResult> GetSituation(int situationId)
        {
            try
            {
                var situation = await _workProcessService.GetSituationAsync(situationId, GetCurrentUserId());
                if (situation == null)
                    return NotFound(new { message = $"Situation {situationId} not found" });

                return Ok(situation);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving situation", error = ex.Message });
            }
        }

        /// <summary>
        /// Create an automation rule
        /// </summary>
        [HttpPost("automation-rules")]
        public async Task<IActionResult> CreateAutomationRule([FromBody] AutomationRule rule)
        {
            try
            {
                var result = await _workProcessService.CreateAutomationRuleAsync(rule, GetCurrentUserId());
                return CreatedAtAction(nameof(GetAutomationRule), new { ruleId = result.Id }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error creating automation rule", error = ex.Message });
            }
        }

        /// <summary>
        /// Get an automation rule by ID
        /// </summary>
        [HttpGet("automation-rules/{ruleId}")]
        public async Task<IActionResult> GetAutomationRule(int ruleId)
        {
            try
            {
                var rule = await _workProcessService.GetAutomationRuleAsync(ruleId, GetCurrentUserId());
                if (rule == null)
                    return NotFound(new { message = $"Automation rule {ruleId} not found" });

                return Ok(rule);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving automation rule", error = ex.Message });
            }
        }

        /// <summary>
        /// Get all automation rules for the current user
        /// </summary>
        [HttpGet("automation-rules")]
        public async Task<IActionResult> GetUserAutomationRules()
        {
            try
            {
                var rules = await _workProcessService.GetUserAutomationRulesAsync(GetCurrentUserId());
                return Ok(rules);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving automation rules", error = ex.Message });
            }
        }

        /// <summary>
        /// Execute an automation rule
        /// </summary>
        [HttpPost("automation-rules/{ruleId}/execute")]
        public async Task<IActionResult> ExecuteAutomationRule(int ruleId, [FromBody] Dictionary<string, object> context)
        {
            try
            {
                var result = await _workProcessService.ExecuteAutomationRuleAsync(ruleId, context, GetCurrentUserId());
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error executing automation rule", error = ex.Message });
            }
        }

        /// <summary>
        /// Update an automation rule
        /// </summary>
        [HttpPut("automation-rules/{ruleId}")]
        public async Task<IActionResult> UpdateAutomationRule(int ruleId, [FromBody] AutomationRule rule)
        {
            try
            {
                rule.Id = ruleId;
                var result = await _workProcessService.UpdateAutomationRuleAsync(rule, GetCurrentUserId());
                if (result == null)
                    return NotFound(new { message = $"Automation rule {ruleId} not found" });

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error updating automation rule", error = ex.Message });
            }
        }

        /// <summary>
        /// Delete an automation rule
        /// </summary>
        [HttpDelete("automation-rules/{ruleId}")]
        public async Task<IActionResult> DeleteAutomationRule(int ruleId)
        {
            try
            {
                var result = await _workProcessService.DeleteAutomationRuleAsync(ruleId, GetCurrentUserId());
                if (!result)
                    return NotFound(new { message = $"Automation rule {ruleId} not found" });

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error deleting automation rule", error = ex.Message });
            }
        }

        /// <summary>
        /// Optimize a work process
        /// </summary>
        [HttpPost("processes/{processId}/optimize")]
        public async Task<IActionResult> OptimizeWorkProcess(int processId)
        {
            try
            {
                var result = await _workProcessService.OptimizeWorkProcessAsync(processId, GetCurrentUserId());
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error optimizing work process", error = ex.Message });
            }
        }

        /// <summary>
        /// Get process metrics
        /// </summary>
        [HttpGet("processes/{processId}/metrics")]
        public async Task<IActionResult> GetProcessMetrics(int processId)
        {
            try
            {
                var metrics = await _workProcessService.GetProcessMetricsAsync(processId, GetCurrentUserId());
                return Ok(metrics);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving process metrics", error = ex.Message });
            }
        }

        /// <summary>
        /// Get work process statistics
        /// </summary>
        [HttpGet("statistics")]
        public async Task<IActionResult> GetWorkProcessStatistics()
        {
            try
            {
                var stats = await _workProcessService.GetWorkProcessStatisticsAsync();
                return Ok(stats);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving work process statistics", error = ex.Message });
            }
        }

        /// <summary>
        /// Get automation execution history
        /// </summary>
        [HttpGet("automation-executions")]
        public async Task<IActionResult> GetAutomationExecutionHistory()
        {
            try
            {
                var history = await _workProcessService.GetAutomationExecutionHistoryAsync(GetCurrentUserId());
                return Ok(history);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving automation execution history", error = ex.Message });
            }
        }

        private int GetCurrentUserId()
        {
            // Extract user ID from JWT token claims
            var userIdClaim = User.FindFirst("userId") ?? User.FindFirst("sub");
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
            {
                return userId;
            }
            throw new UnauthorizedAccessException("Unable to determine current user ID");
        }
    }
}