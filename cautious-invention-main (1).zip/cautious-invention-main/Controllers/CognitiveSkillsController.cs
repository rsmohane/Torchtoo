using HumanAssist.Controllers;
using HumanAssist.Models;
using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HumanAssist.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CognitiveSkillsController : ControllerBase
    {
        private readonly ICognitiveSkillsService _cognitiveSkillsService;

        public CognitiveSkillsController(ICognitiveSkillsService cognitiveSkillsService)
        {
            _cognitiveSkillsService = cognitiveSkillsService;
        }

        /// <summary>
        /// Assess mind activity for a user
        /// </summary>
        [HttpPost("users/{userId}/mind-activity")]
        public async Task<IActionResult> AssessMindActivity(int userId, [FromBody] MindActivityData activityData)
        {
            try
            {
                var result = await _cognitiveSkillsService.AssessMindActivityAsync(userId, activityData);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error assessing mind activity", error = ex.Message });
            }
        }

        /// <summary>
        /// Evaluate work capacity for a user
        /// </summary>
        [HttpPost("users/{userId}/work-capacity")]
        public async Task<IActionResult> EvaluateWorkCapacity(int userId, [FromBody] WorkCapacityData workData)
        {
            try
            {
                var result = await _cognitiveSkillsService.EvaluateWorkCapacityAsync(userId, workData);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error evaluating work capacity", error = ex.Message });
            }
        }

        /// <summary>
        /// Analyze learning skills for a user
        /// </summary>
        [HttpPost("users/{userId}/learning-skills")]
        public async Task<IActionResult> AnalyzeLearningSkills(int userId, [FromBody] LearningActivityData activities)
        {
            try
            {
                var result = await _cognitiveSkillsService.AnalyzeLearningSkillsAsync(userId, activities);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error analyzing learning skills", error = ex.Message });
            }
        }

        /// <summary>
        /// Build experience skills profile for a user
        /// </summary>
        [HttpPost("users/{userId}/experience-skills")]
        public async Task<IActionResult> BuildExperienceSkills(int userId, [FromBody] ExperienceData experiences)
        {
            try
            {
                var result = await _cognitiveSkillsService.BuildExperienceSkillsAsync(userId, experiences);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error building experience skills", error = ex.Message });
            }
        }

        /// <summary>
        /// Get cognitive profile for a user
        /// </summary>
        [HttpGet("users/{userId}/cognitive-profile")]
        public async Task<IActionResult> GetCognitiveProfile(int userId)
        {
            try
            {
                var profile = await _cognitiveSkillsService.GetCognitiveProfileAsync(userId);
                if (profile == null)
                    return NotFound(new { message = $"Cognitive profile for user {userId} not found" });

                return Ok(profile);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving cognitive profile", error = ex.Message });
            }
        }

        /// <summary>
        /// Get work capacity evaluation for a user
        /// </summary>
        [HttpGet("users/{userId}/work-capacity")]
        public async Task<IActionResult> GetWorkCapacity(int userId)
        {
            try
            {
                var capacity = await _cognitiveSkillsService.GetWorkCapacityAsync(userId);
                if (capacity == null)
                    return NotFound(new { message = $"Work capacity for user {userId} not found" });

                return Ok(capacity);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving work capacity", error = ex.Message });
            }
        }

        /// <summary>
        /// Get learning profile for a user
        /// </summary>
        [HttpGet("users/{userId}/learning-profile")]
        public async Task<IActionResult> GetLearningProfile(int userId)
        {
            try
            {
                var profile = await _cognitiveSkillsService.GetLearningProfileAsync(userId);
                if (profile == null)
                    return NotFound(new { message = $"Learning profile for user {userId} not found" });

                return Ok(profile);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving learning profile", error = ex.Message });
            }
        }

        /// <summary>
        /// Get experience profile for a user
        /// </summary>
        [HttpGet("users/{userId}/experience-profile")]
        public async Task<IActionResult> GetExperienceProfile(int userId)
        {
            try
            {
                var profile = await _cognitiveSkillsService.GetExperienceProfileAsync(userId);
                if (profile == null)
                    return NotFound(new { message = $"Experience profile for user {userId} not found" });

                return Ok(profile);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving experience profile", error = ex.Message });
            }
        }

        /// <summary>
        /// Train nanotechnology expertise for a user
        /// </summary>
        [HttpPost("users/{userId}/expertise/nanotech")]
        public async Task<IActionResult> TrainNanoTechExpertise(int userId, [FromBody] TrainingData trainingData)
        {
            try
            {
                var result = await _cognitiveSkillsService.TrainNanoTechExpertiseAsync(userId, trainingData);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error training nanotechnology expertise", error = ex.Message });
            }
        }

        /// <summary>
        /// Train robotics expertise for a user
        /// </summary>
        [HttpPost("users/{userId}/expertise/robotics")]
        public async Task<IActionResult> TrainRoboticsExpertise(int userId, [FromBody] TrainingData trainingData)
        {
            try
            {
                var result = await _cognitiveSkillsService.TrainRoboticsExpertiseAsync(userId, trainingData);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error training robotics expertise", error = ex.Message });
            }
        }

        /// <summary>
        /// Train automation expertise for a user
        /// </summary>
        [HttpPost("users/{userId}/expertise/automation")]
        public async Task<IActionResult> TrainAutomationExpertise(int userId, [FromBody] TrainingData trainingData)
        {
            try
            {
                var result = await _cognitiveSkillsService.TrainAutomationExpertiseAsync(userId, trainingData);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error training automation expertise", error = ex.Message });
            }
        }

        /// <summary>
        /// Get nanotechnology expertise for a user
        /// </summary>
        [HttpGet("users/{userId}/expertise/nanotech")]
        public async Task<IActionResult> GetNanoTechExpertise(int userId)
        {
            try
            {
                var expertise = await _cognitiveSkillsService.GetNanoTechExpertiseAsync(userId);
                if (expertise == null)
                    return NotFound(new { message = $"Nanotechnology expertise for user {userId} not found" });

                return Ok(expertise);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving nanotechnology expertise", error = ex.Message });
            }
        }

        /// <summary>
        /// Get robotics expertise for a user
        /// </summary>
        [HttpGet("users/{userId}/expertise/robotics")]
        public async Task<IActionResult> GetRoboticsExpertise(int userId)
        {
            try
            {
                var expertise = await _cognitiveSkillsService.GetRoboticsExpertiseAsync(userId);
                if (expertise == null)
                    return NotFound(new { message = $"Robotics expertise for user {userId} not found" });

                return Ok(expertise);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving robotics expertise", error = ex.Message });
            }
        }

        /// <summary>
        /// Get automation expertise for a user
        /// </summary>
        [HttpGet("users/{userId}/expertise/automation")]
        public async Task<IActionResult> GetAutomationExpertise(int userId)
        {
            try
            {
                var expertise = await _cognitiveSkillsService.GetAutomationExpertiseAsync(userId);
                if (expertise == null)
                    return NotFound(new { message = $"Automation expertise for user {userId} not found" });

                return Ok(expertise);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving automation expertise", error = ex.Message });
            }
        }

        /// <summary>
        /// Get all cognitive skills for a user
        /// </summary>
        [HttpGet("users/{userId}/skills")]
        public async Task<IActionResult> GetCognitiveSkills(int userId)
        {
            try
            {
                var skills = await _cognitiveSkillsService.GetCognitiveSkillsAsync(userId);
                return Ok(skills);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving cognitive skills", error = ex.Message });
            }
        }

        /// <summary>
        /// Get cognitive skills by category
        /// </summary>
        [HttpGet("users/{userId}/skills/category/{category}")]
        public async Task<IActionResult> GetCognitiveSkillsByCategory(int userId, string category)
        {
            try
            {
                var skills = await _cognitiveSkillsService.GetCognitiveSkillsByCategoryAsync(userId, category);
                return Ok(skills);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving cognitive skills by category", error = ex.Message });
            }
        }

        /// <summary>
        /// Get cognitive assessment statistics
        /// </summary>
        [HttpGet("statistics")]
        public async Task<IActionResult> GetCognitiveAssessmentStatistics()
        {
            try
            {
                var stats = await _cognitiveSkillsService.GetCognitiveAssessmentStatisticsAsync();
                return Ok(stats);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving cognitive assessment statistics", error = ex.Message });
            }
        }
    }
}