namespace HumanAssist.Controllers;

using HumanAssist.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class DependencyManagementController : ControllerBase
{
    private readonly IDependencyManagementService _dependencyService;
    private readonly ILogger<DependencyManagementController> _logger;

    public DependencyManagementController(
        IDependencyManagementService dependencyService,
        ILogger<DependencyManagementController> logger)
    {
        _dependencyService = dependencyService;
        _logger = logger;
    }

    [HttpPost("install/npm")]
    public async Task<IActionResult> InstallNpmDependencies([FromBody] string projectPath)
    {
        var (success, output, error) = await _dependencyService.InstallNpmDependenciesAsync(projectPath);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Installed npm dependencies for: {ProjectPath}", projectPath);
        return Ok(new { message = "Dependencies installed successfully", output });
    }

    [HttpPost("install/nuget")]
    public async Task<IActionResult> InstallNuGetDependencies([FromBody] string projectPath)
    {
        var (success, output, error) = await _dependencyService.InstallNuGetDependenciesAsync(projectPath);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Installed NuGet dependencies for: {ProjectPath}", projectPath);
        return Ok(new { message = "Dependencies restored successfully", output });
    }

    [HttpPost("install/python")]
    public async Task<IActionResult> InstallPythonDependencies([FromBody] string projectPath)
    {
        var (success, output, error) = await _dependencyService.InstallPythonDependenciesAsync(projectPath);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Installed Python dependencies for: {ProjectPath}", projectPath);
        return Ok(new { message = "Dependencies installed successfully", output });
    }

    [HttpGet("list")]
    public async Task<IActionResult> ListInstalledDependencies([FromQuery] string projectPath, [FromQuery] string packageManager = "npm")
    {
        var (success, packages, error) = await _dependencyService.ListInstalledDependenciesAsync(projectPath, packageManager);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Listed {Count} dependencies from {PackageManager}", packages.Count, packageManager);
        return Ok(new { packages, count = packages.Count });
    }

    [HttpGet("version")]
    public async Task<IActionResult> CheckDependencyVersion([FromQuery] string packageName, [FromQuery] string packageManager = "npm")
    {
        var (success, package, error) = await _dependencyService.CheckDependencyVersionAsync(packageName, packageManager);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Checked version for: {PackageName}", packageName);
        return Ok(package);
    }

    [HttpPost("update")]
    public async Task<IActionResult> UpdatePackages([FromBody] UpdatePackagesRequest request)
    {
        var (success, output, error) = await _dependencyService.UpdatePackagesAsync(request.ProjectPath, request.PackageManager);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Updated packages for: {ProjectPath}", request.ProjectPath);
        return Ok(new { message = "Packages updated successfully", output });
    }

    [HttpPost("audit")]
    public async Task<IActionResult> AuditSecurityVulnerabilities([FromBody] string projectPath)
    {
        var (success, report, error) = await _dependencyService.AuditSecurityVulnerabilitiesAsync(projectPath);
        if (!success)
            return BadRequest(new { error });

        _logger.LogInformation("Security audit completed for: {ProjectPath}", projectPath);
        return Ok(new { message = "Security audit completed", report });
    }
}

public class UpdatePackagesRequest
{
    public string ProjectPath { get; set; } = string.Empty;
    public string PackageManager { get; set; } = "npm";
}
