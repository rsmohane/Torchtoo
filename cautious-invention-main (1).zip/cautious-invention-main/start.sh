#!/bin/bash

# HumanAssist Platform - Linux/macOS Startup Script
# This script starts the HumanAssist API with all necessary services

set -e

echo "🚀 HumanAssist Platform - Starting Services..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if SQL Server is running
echo -e"${YELLOW}⏳ Checking SQL Server...${NC}"
if ! nc -z localhost 1433 2>/dev/null; then
    echo -e "${YELLOW}📦 SQL Server not running. Starting Docker container...${NC}"
    docker run -d \
        -e "ACCEPT_EULA=Y" \
        -e "SA_PASSWORD=YourPassword123!" \
        -p 1433:1433 \
        --name humanassist-db \
        -d mcr.microsoft.com/mssql/server:2022-latest > /dev/null 2>&1 || true
    echo -e "${GREEN}✅ SQL Server started${NC}"
    sleep 5
else
    echo -e "${GREEN}✅ SQL Server is running${NC}"
fi

# Navigate to application directory
cd /tmp/HumanAssist-Release || cd /workspaces/cautious-invention

echo -e "${YELLOW}⏳ Loading application configuration...${NC}"

# Check if appsettings.json exists
if [ ! -f "appsettings.json" ]; then
    echo -e "${RED}❌ appsettings.json not found!${NC}"
    echo "Please copy appsettings.json to the application directory"
    exit 1
fi

echo -e "${YELLOW}📡 Starting HumanAssist API...${NC}"

# Start the application
if [ -f "HumanAssist.dll" ]; then
    dotnet HumanAssist.dll
elif [ -f "bin/Release/net8.0/HumanAssist.dll" ]; then
    dotnet bin/Release/net8.0/HumanAssist.dll
else
    echo -e "${RED}❌ HumanAssist.dll not found!${NC}"
    echo "Please build the application first with: dotnet publish -c Release"
    exit 1
fi
