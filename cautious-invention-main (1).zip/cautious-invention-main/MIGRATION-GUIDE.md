# Database Migration Guide

## Quick Start

```bash
cd /workspaces/cautious-invention

# Create migration
dotnet ef migrations add AddSupportAndEnvironmentFeatures

# Apply migration
dotnet ef database update
```

---

## Migration Steps

### Step 1: Create Migration

```bash
dotnet ef migrations add AddSupportAndEnvironmentFeatures
```

This creates a migration file in `Data/Migrations/` directory.

### Step 2: Review Migration (Optional)

```bash
# View migration file
cat Data/Migrations/*_AddSupportAndEnvironmentFeatures.cs
```

### Step 3: Apply Migration

```bash
# Apply to development database
dotnet ef database update

# Or apply to specific environment
dotnet ef database update --configuration Release
```

### Step 4: Verify Schema

```bash
# Check tables created
sqlcmd -S (localdb)\mssqllocaldb -d HumanAssistDb -Q "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES"
```

---

## Schema Created by Migration

### Tables Added

1. **SupportedLanguages**
   - LanguageId (PK)
   - LanguageCode (unique)
   - LanguageName
   - NativeName
   - IsActive
   - NativeSpeakerCount

2. **ProblemHandlingSkills**
   - SkillId (PK)
   - Name
   - Category
   - Description
   - SuccessRate
   - TimeEstimateMinutes
   - RequiredTools
   - IsActive
   - CreatedAt

3. **SupportTickets**
   - TicketId (PK)
   - UserId (FK)
   - AssignedToUserId (FK)
   - Title
   - Description
   - Category
   - Severity
   - Status
   - ResolutionNotes
   - SatisfactionScore
   - CreatedAt
   - UpdatedAt
   - ResolvedAt

4. **SupportConversations**
   - ConversationId (PK)
   - TicketId (FK)
   - UserId (FK)
   - Message
   - MessageType
   - IsSolution
   - CreatedAt

5. **Environments**
   - EnvironmentId (PK)
   - Name
   - EnvironmentType
   - EnvironmentUrl
   - Description
   - IsActive
   - CreatedAt
   - UpdatedAt

6. **EnvironmentVariables**
   - VariableId (PK)
   - EnvironmentId (FK)
   - VariableName
   - VariableValue (encrypted)
   - Usage
   - CreatedAt

7. **EnvironmentAccessLogs**
   - LogId (PK)
   - EnvironmentId (FK)
   - UserId (FK)
   - Action
   - Resource
   - IpAddress
   - Success
   - ErrorMessage
   - CreatedAt

8. **TranslationCaches**
   - CacheId (PK)
   - SourceLanguage
   - TargetLanguage
   - SourceText
   - TranslatedText
   - ConfidenceScore
   - Provider
   - AccessCount
   - LastAccessTime
   - CreatedAt

9. **UserLanguagePreferences**
   - PreferenceId (PK)
   - UserId (FK)
   - PreferredLanguage
   - SecondaryLanguage
   - AutoTranslate
   - CreatedAt
   - UpdatedAt

10. **ApiKeyUsageStatistics**
    - StatisticsId (PK)
    - ApiKeyId (FK)
    - DateRecorded
    - RequestCount
    - SuccessCount
    - FailureCount
    - AverageResponseTimeMs

---

## Indexes Created

```sql
-- Support Tickets
CREATE INDEX IX_SupportTickets_Status ON SupportTickets(Status)
CREATE INDEX IX_SupportTickets_CreatedAt ON SupportTickets(CreatedAt DESC)
CREATE INDEX IX_SupportTickets_AssignedToUserId ON SupportTickets(AssignedToUserId)

-- Conversations
CREATE INDEX IX_SupportConversations_TicketId ON SupportConversations(TicketId)

-- Environment Access Logs
CREATE INDEX IX_EnvironmentAccessLogs_EnvironmentId ON EnvironmentAccessLogs(EnvironmentId)
CREATE INDEX IX_EnvironmentAccessLogs_CreatedAt ON EnvironmentAccessLogs(CreatedAt DESC)

-- Translation Cache
CREATE INDEX IX_TranslationCaches_Languages ON TranslationCaches(SourceLanguage, TargetLanguage)

-- API Key Usage
CREATE INDEX IX_ApiKeyUsageStatistics_ApiKeyId ON ApiKeyUsageStatistics(ApiKeyId)
CREATE INDEX IX_ApiKeyUsageStatistics_DateRecorded ON ApiKeyUsageStatistics(DateRecorded DESC)
```

---

## Constraints & Relationships

### Foreign Keys

```
SupportTickets.UserId → Users.Id
SupportTickets.AssignedToUserId → Users.Id (nullable)
SupportConversations.TicketId → SupportTickets.TicketId
SupportConversations.UserId → Users.Id
EnvironmentVariables.EnvironmentId → Environments.EnvironmentId
EnvironmentAccessLogs.EnvironmentId → Environments.EnvironmentId
EnvironmentAccessLogs.UserId → Users.Id
UserLanguagePreferences.UserId → Users.Id
ApiKeyUsageStatistics.ApiKeyId → ApiKeys.Id
```

### Cascade Delete

- Deleting Environment → Delete all EnvironmentVariables, EnvironmentAccessLogs
- Deleting SupportTicket → Delete all SupportConversations
- Deleting SupportedLanguage → Delete all TranslationCaches with that language

---

## Reverting Migrations

If you need to rollback:

```bash
# Rollback last migration
dotnet ef database update [previous-migration-name]

# Remove migration file
dotnet ef migrations remove
```

---

## Checking Migration Status

```bash
# List all migrations
dotnet ef migrations list

# Show pending migrations
dotnet ef migrations list --no-build

# Check database status
dotnet ef database info
```

---

## Seed Data Script

After migration, seed initial data:

```csharp
// Create file: Data/DbInitializer.cs
public static class DbInitializer
{
    public static void Initialize(ApplicationDbContext context)
    {
        // Add languages
        if (!context.SupportedLanguages.Any())
        {
            var languages = new SupportedLanguage[]
            {
                new SupportedLanguage { LanguageCode = "en", LanguageName = "English", NativeName = "English", IsActive = true },
                new SupportedLanguage { LanguageCode = "es", LanguageName = "Spanish", NativeName = "Español", IsActive = true },
                new SupportedLanguage { LanguageCode = "fr", LanguageName = "French", NativeName = "Français", IsActive = true },
                new SupportedLanguage { LanguageCode = "de", LanguageName = "German", NativeName = "Deutsch", IsActive = true },
                new SupportedLanguage { LanguageCode = "pt", LanguageName = "Portuguese", NativeName = "Português", IsActive = true },
                new SupportedLanguage { LanguageCode = "ja", LanguageName = "Japanese", NativeName = "日本語", IsActive = true },
                new SupportedLanguage { LanguageCode = "zh", LanguageName = "Chinese", NativeName = "中文", IsActive = true }
            };
            context.SupportedLanguages.AddRange(languages);
        }

        // Add problem handling skills
        if (!context.ProblemHandlingSkills.Any())
        {
            var skills = new ProblemHandlingSkill[]
            {
                new ProblemHandlingSkill 
                { 
                    Name = "Database Connection Troubleshooting", 
                    Category = "Database",
                    Description = "Diagnose and resolve database connection issues",
                    SuccessRate = 95,
                    TimeEstimateMinutes = 15,
                    IsActive = true
                },
                new ProblemHandlingSkill 
                { 
                    Name = "API Authentication Issues", 
                    Category = "API",
                    Description = "Resolve API authentication and authorization problems",
                    SuccessRate = 92,
                    TimeEstimateMinutes = 20,
                    IsActive = true
                },
                new ProblemHandlingSkill 
                { 
                    Name = "Performance Optimization", 
                    Category = "Performance",
                    Description = "Analyze and optimize application performance",
                    SuccessRate = 85,
                    TimeEstimateMinutes = 45,
                    IsActive = true
                },
                new ProblemHandlingSkill 
                { 
                    Name = "Data Migration Support", 
                    Category = "Database",
                    Description = "Assist with data migration and schema changes",
                    SuccessRate = 88,
                    TimeEstimateMinutes = 60,
                    IsActive = true
                }
            };
            context.ProblemHandlingSkills.AddRange(skills);
        }

        context.SaveChanges();
    }
}
```

Call from Program.cs:

```csharp
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    DbInitializer.Initialize(context);
}
```

---

## Troubleshooting Migrations

### Issue: "The connection method is not installed"

```bash
# Install SQL Server LocalDB
choco install sql-server-localdb
```

### Issue: "Database does not exist"

```bash
# Create database
dotnet ef database create

# Then apply migrations
dotnet ef database update
```

### Issue: Migration conflicts

```bash
# Remove conflicting migration
dotnet ef migrations remove

# Recreate with different name
dotnet ef migrations add AddFeaturesV2
```

### Issue: Cannot apply migration (existing data issue)

```bash
# Create empty migration and add custom SQL
dotnet ef migrations add MigrationName --empty

# Edit the migration file with custom SQL, then:
dotnet ef database update
```

---

## Performance Tuning

### Query Optimization

```csharp
// Include related data to avoid N+1 queries
var tickets = context.SupportTickets
    .Include(t => t.User)
    .Include(t => t.AssignedToUser)
    .Include(t => t.Conversations)
    .Where(t => t.Status == "Open")
    .ToList();

// Use projections to select only needed columns
var ticketInfos = context.SupportTickets
    .Select(t => new { t.TicketId, t.Title, t.Status })
    .ToList();
```

### Index Hints

If queries are slow, add indices:

```csharp
modelBuilder.Entity<SupportTicket>()
    .HasIndex(t => new { t.Status, t.CreatedAt })
    .IsDescending(false, true)  // Status ASC, CreatedAt DESC
    .HasDatabaseName("IX_Tickets_StatusDate");
```

---

## Backup & Recovery

### Before Migration

```bash
# Backup database
sqlcmd -S (localdb)\mssqllocaldb -d HumanAssistDb -Q "BACKUP DATABASE HumanAssistDb TO DISK='backup.bak'"
```

### After Issues

```bash
# Restore database
sqlcmd -S (localdb)\mssqllocaldb -Q "RESTORE DATABASE HumanAssistDb FROM DISK='backup.bak'"
```

---

## Production Deployment

1. **Test in staging** - Run migrations on staging database first
2. **Create backup** - Always backup before production migration
3. **Apply migration** - Run `dotnet ef database update --configuration Release`
4. **Verify schema** - Confirm all tables/indices created correctly
5. **Run smoke tests** - Test critical functionality
6. **Monitor logs** - Watch application logs for issues

---

## Next Steps

1. Run migration: `dotnet ef database update`
2. Seed initial data using DbInitializer
3. Verify database creation
4. Test API endpoints
5. Configure API keys and credentials
