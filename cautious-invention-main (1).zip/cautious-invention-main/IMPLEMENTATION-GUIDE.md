# Implementation Guide - New Features

## Overview

This guide covers installation, configuration, and usage of the newly added features:
- API Key Management & Monitoring
- Support & Problem Handling
- Environment Management  
- Language Translation
- Security & Encryption

---

## 1. Database Setup

### Create Initial Migration

```bash
cd /workspaces/cautious-invention

# Create migration for new models
dotnet ef migrations add AddSupportAndEnvironmentFeatures

# Apply migration
dotnet ef database update
```

### Seed Initial Data

```csharp
// Add to Program.cs before app.Run()
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    
    // Add supported languages
    if (!context.SupportedLanguages.Any())
    {
        context.SupportedLanguages.AddRange(
            new SupportedLanguage { LanguageCode = "en", LanguageName = "English", NativeName = "English" },
            new SupportedLanguage { LanguageCode = "es", LanguageName = "Spanish", NativeName = "Español" },
            new SupportedLanguage { LanguageCode = "fr", LanguageName = "French", NativeName = "Français" },
            new SupportedLanguage { LanguageCode = "de", LanguageName = "German", NativeName = "Deutsch" },
            new SupportedLanguage { LanguageCode = "pt", LanguageName = "Portuguese", NativeName = "Português" }
        );
        context.SaveChanges();
    }
    
    // Add problem handling skills
    if (!context.ProblemHandlingSkills.Any())
    {
        context.ProblemHandlingSkills.AddRange(
            new ProblemHandlingSkill 
            { 
                Name = "Database Connection Issues", 
                Category = "Database",
                SuccessRate = 95,
                TimeEstimateMinutes = 15
            },
            new ProblemHandlingSkill 
            { 
                Name = "API Authentication Issues", 
                Category = "API",
                SuccessRate = 92,
                TimeEstimateMinutes = 20
            }
        );
        context.SaveChanges();
    }
}
```

---

## 2. Configuration

### Environment Variables

Create `.env` or update `appsettings.json`:

```json
{
  "Translation": {
    "Provider": "google",  // or "azure"
    "GoogleApiKey": "your-google-api-key",
    "AzureApiKey": "your-azure-key",
    "AzureRegion": "eastus"
  }
}
```

### Set Encryption Keys

Generate secure keys:

```bash
# Generate a random key for encryption
openssl rand -base64 64
```

Update `appsettings.json`:

```json
{
  "Security": {
    "EncryptionKey": "generated-base64-key-here"
  },
  "Jwt": {
    "SecretKey": "generated-long-secret-key-here"
  }
}
```

---

## 3. API Key Management

### Generate API Key

```bash
curl -X POST http://localhost:5000/api/apikeys/generate \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Mobile App",
    "permissions": "read,write"
  }'
```

### Monitor API Key Usage

```bash
# Check health
curl http://localhost:5000/api/apikeymonitoring/1/health \
  -H "Authorization: Bearer <token>"

# Get metrics
curl http://localhost:5000/api/apikeymonitoring/1/metrics \
  -H "Authorization: Bearer <token>"

# View dashboard
curl http://localhost:5000/api/apikeymonitoring/dashboard \
  -H "Authorization: Bearer <token>"
```

---

## 4. Support Ticket System

### Create Support Ticket

```bash
curl -X POST http://localhost:5000/api/support/tickets \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Database Connection Issue",
    "description": "Cannot connect to production database",
    "category": "Database",
    "severity": "High"
  }'
```

### Add Conversation

```bash
curl -X POST http://localhost:5000/api/support/tickets/1/conversation \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Try restarting the database service",
    "messageType": "Text",
    "isSolution": true
  }'
```

### Update Ticket Status

```bash
curl -X PUT http://localhost:5000/api/support/tickets/1 \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Resolved",
    "severity": "Medium",
    "resolutionNotes": "Restarted service, connection restored"
  }'
```

---

## 5. Environment Management

### Create Environment

```bash
curl -X POST http://localhost:5000/api/environments \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production",
    "type": "Production",
    "environmentUrl": "https://api.prod.example.com",
    "description": "Main production environment"
  }'
```

### Set Environment Variables

```bash
curl -X POST http://localhost:5000/api/environments/1/variables \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "DATABASE_CONNECTION": "Server=db.prod.example.com",
    "API_KEY": "secret-key-123",
    "LOG_LEVEL": "INFO"
  }'
```

### View Access Logs

```bash
curl http://localhost:5000/api/environments/1/access-logs \
  -H "Authorization: Bearer <token>"
```

---

## 6. Translation Service

### Single Translation

```bash
curl -X POST http://localhost:5000/api/translation/translate \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Hello, how can I help you?",
    "sourceLanguage": "en",
    "targetLanguage": "es"
  }'
```

### Batch Translation

```bash
curl -X POST http://localhost:5000/api/translation/batch-translate \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "texts": ["Hello", "Good morning", "How are you?"],
    "sourceLanguage": "en",
    "targetLanguage": "fr"
  }'
```

### Set User Language Preference

```bash
curl -X POST http://localhost:5000/api/translation/preferences \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "preferredLanguage": "es",
    "secondaryLanguage": "en"
  }'
```

---

## 7. Security Best Practices

### Encryption

All sensitive data is encrypted using AES-256:

```csharp
// Encrypt data
var encrypted = _encryptionService.Encrypt("sensitive-data");

// Decrypt data
var decrypted = _encryptionService.Decrypt(encrypted);
```

### Password Security

Passwords are hashed using BCrypt with 12 salt rounds:

```csharp
// Hash password during registration
var hash = _encryptionService.HashPassword(password);

// Verify password during login
bool isValid = _encryptionService.VerifyPassword(password, hash);
```

### API Key Security

- Keys are encrypted before storage
- Keys are masked in responses (showing only last 8 characters)
- Keys expire after 1 year by default
- Failed login attempts lock accounts after 5 consecutive failures

---

## 8. Audit Logging

All significant actions are logged:

```csharp
// Log action
await _auditService.LogActionAsync(
    userId: 1,
    action: "CreateSupportTicket",
    entityType: "SupportTicket",
    entityId: 5,
    changes: "New ticket created",
    ipAddress: "192.168.1.100"
);

// Retrieve logs
var logs = await _auditService.GetAuditLogsAsync(
    userId: 1,
    fromDate: DateTime.UtcNow.AddDays(-7)
);
```

---

## 9. Role-Based Access Control

### User Roles

- **User**: Basic access, create support tickets, manage own api keys
- **Assistant**: Can view open tickets, respond to users
- **Admin**: Full access, view audit logs, manage problem skills

### Authorization Example

```csharp
[Authorize]  // Requires authentication
public async Task<IActionResult> GetTicket(int id) { ... }

[Authorize(Roles = "Assistant,Admin")]  // Requires specific role
public async Task<IActionResult> GetOpenTickets() { ... }

[Authorize(Roles = "Admin")]  // Admin only
public async Task<IActionResult> GetAuditLogs() { ... }
```

---

## 10. Testing

### Integration Test Example

```csharp
[Test]
public async Task CreateSupportTicket_WithValidData_ReturnsCreated()
{
    // Arrange
    var request = new CreateTicketRequest
    {
        Title = "Test Issue",
        Category = "Database",
        Severity = "High"
    };

    // Act
    var response = await _httpClient.PostAsJsonAsync("/api/support/tickets", request);

    // Assert
    Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);
}
```

---

## 11. Performance Optimization

### Database Indexing

Key indices are automatically created:
- `Users.Email` (unique)
- `ApiKeys.Key` (unique)
- `SupportTickets.Status`
- `SupportTickets.CreatedAt`
- `EnvironmentAccessLogs.EnvironmentId`
- `EnvironmentAccessLogs.CreatedAt`

### Caching Strategy

Translation results are cached to reduce API calls:

```csharp
// Check cache first
var cached = await _translationService.GetTranslationFromCacheAsync(
    text, sourceLanguage, targetLanguage
);

// If not cached, translate and cache
if (cached == null)
{
    var (success, result) = await TranslateAsync(...);
    await _translationService.CacheTranslationAsync(
        text, sourceLanguage, targetLanguage, result, 0.95
    );
}
```

---

## 12. Troubleshooting

### Common Issues

**Issue**: API key validation fails
- **Solution**: Ensure keys are properly encrypted/decrypted before comparison

**Issue**: Environment variables showing as null
- **Solution**: Verify encryption key matches during encryption and decryption

**Issue**: Translation service returns 403 error
- **Solution**: Check API key is valid and credentials are properly configured

**Issue**: Support tickets not auto-assigning
- **Solution**: Verify ProblemHandlingSkills and Users with role "Assistant" exist

---

## 13. Deployment

### Docker Deployment

```bash
# Build image
docker build -t humanassist-api .

# Run with docker-compose
docker-compose up -d

# Check logs
docker-compose logs -f api
```

### Production Checklist

- [ ] Update all API keys in appsettings.json
- [ ] Set encryption keys to production values
- [ ] Enable HTTPS only
- [ ] Configure rate limiting
- [ ] Set up automated backups
- [ ] Configure audit log retention
- [ ] Enable logging to external service (ELK, etc.)
- [ ] Test all integrations (OpenAI, Translation APIs)

---

## 14. Monitoring & Metrics

Monitor these key metrics:

- API request success rate
- Average response time
- Support ticket resolution time
- Translation cache hit rate
- Environment access patterns
- Database query performance
- API key usage trends

---

## Next Steps

1. Configure external API keys (OpenAI, Translation APIs)
2. Seed initial problem handling skills
3. Set up monitoring and alerting
4. Create user documentation
5. Train support team on new features
6. Plan for scaling (caching, database optimization)

---

## Support

For implementation questions: support@humanassist.example.com
