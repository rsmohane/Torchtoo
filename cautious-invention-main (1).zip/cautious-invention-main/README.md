# Human Assist Platform

A comprehensive ASP.NET Core + SQL Server platform for human assistance and support services.

## Features

- **User Management**: Register and manage users (clients and assistants)
- **Assistance Requests**: Create, track, and manage support tickets
- **Conversations**: Real-time communication between clients and assistants
- **Request Tracking**: Monitor status, priority, and assignment of requests
- **Category Management**: Organize requests by category
- **Role-Based Access**: Support for User, Assistant, and Admin roles

## Tech Stack

- **Backend**: ASP.NET Core 8.0
- **Database**: SQL Server
- **ORM**: Entity Framework Core
- **API Documentation**: Swagger/OpenAPI
- **Containerization**: Docker

## Prerequisites

- .NET 8.0 SDK or Docker
- SQL Server (or Docker)
- VS Code or Visual Studio

## Project Structure

```
├── Models/              # Data models (User, AssistanceRequest, Conversation)
├── Data/                # DbContext and migrations
├── Controllers/         # API endpoints
├── Services/            # Business logic (extensible)
├── appsettings.json     # Configuration
├── Program.cs           # Startup configuration
├── docker-compose.yml   # Docker orchestration
└── Dockerfile           # Container image definition
```

## Setup & Installation

### Option 1: Using Docker (Recommended)

```bash
docker-compose up -d
```

This will:
- Start SQL Server on port 1433
- Build and run the API on port 5000
- Create the database automatically

### Option 2: Local Development

1. **Restore dependencies**:
   ```bash
   dotnet restore
   ```

2. **Update database connection string** in `appsettings.json`:
   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Server=your-server;Database=HumanAssistDB;User Id=sa;Password=YourPassword123!;..."
   }
   ```

3. **Create migrations**:
   ```bash
   dotnet ef migrations add InitialCreate
   ```

4. **Apply migrations**:
   ```bash
   dotnet ef database update
   ```

5. **Run the application**:
   ```bash
   dotnet run
   ```

## API Endpoints

### Users
- `GET /api/users` - List all users
- `GET /api/users/{id}` - Get user details
- `POST /api/users` - Create new user
- `PUT /api/users/{id}` - Update user
- `DELETE /api/users/{id}` - Deactivate user

### Assistance Requests
- `GET /api/assistancerequests` - List all requests
- `GET /api/assistancerequests/{id}` - Get request details
- `GET /api/assistancerequests?status=Open` - Filter by status
- `GET /api/assistancerequests/user/{userId}` - Get user's requests
- `POST /api/assistancerequests` - Create request
- `PUT /api/assistancerequests/{id}` - Update request

### Conversations
- `GET /api/conversations/request/{requestId}` - Get request conversations
- `POST /api/conversations` - Add message
- `PUT /api/conversations/{id}` - Update message
- `DELETE /api/conversations/{id}` - Delete message

## Database Schema

### Users Table
- Id, Email (unique), FirstName, LastName, PhoneNumber, Role, IsActive, CreatedAt, UpdatedAt

### AssistanceRequests Table
- Id, UserId (FK), Title, Description, Category, Status, AssignedToId (FK), CreatedAt, ResolvedAt, Priority

### Conversations Table
- Id, AssistanceRequestId (FK), SenderUserId (FK), AssistantUserId (FK), Message, MessageType, IsResolved, CreatedAt

## Configuration

### Environment Variables
The app supports configuration via environment variables or `appsettings.json`:

```json
{
  "Jwt": {"SecretKey": "...", "Issuer": "...", "Audience": "..."},
  "ConnectionStrings": {"DefaultConnection": "..."},
  "Google": {"ClientId": "...", "ClientSecret": "..."},
  "GitHub": {"ClientId": "...", "ClientSecret": "..."},
  "Admin": {"Email": "admin@yourdomain.com", "Password": "StrongP@ssw0rd!"}
}
```

Make sure to **never commit credentials** to source control. Use a secrets manager in production.

Additional configuration values such as API keys, SMTP settings, or third-party URLs should also be placed in environment variables or the configuration store.

See `SETUP-ADMIN.md` for admin initialization instructions.

```bash
ASPNETCORE_ENVIRONMENT=Development
ConnectionStrings__DefaultConnection="Server=...;Database=HumanAssistDB;..."
```

## Development

### Create a new migration
```bash
dotnet ef migrations add [MigrationName]
```

### Update database
```bash
dotnet ef database update
```

### View Swagger UI
Navigate to: `http://localhost:5000/swagger` (when running locally)

## Testing

Example creating a user:
```bash
curl -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "User"
  }'
```

## Mobile Integration (MOB)

This API is designed to be consumed by mobile applications:
- RESTful endpoints for easy integration
- JSON request/response format
- Support for CORS (cross-origin requests)
- Lightweight payload design

## Future Enhancements

- Authentication & JWT tokens
- File upload/attachment support
- Real-time notifications (SignalR)
- Advanced search and filtering
- Analytics and reporting
- Performance optimization with caching

## License

MIT

## Support

For issues or questions, please open an issue in the repository.