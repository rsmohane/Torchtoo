# HumanAssist Platform - Complete Build & Deployment Guide

## Overview
HumanAssist is a comprehensive AI-powered human assistance platform built with .NET 8. It includes:
- AI Analysis and Code Generation
- Geolocation Services with IP and coordinate-based lookup
- Audio/Sound Translation and Speech Synthesis
- Advanced Image Processing and Analysis
- Translation Services (Google/Azure)
- API Key Management and Monitoring
- Support Ticket System
- Environment Management
- Comprehensive Audit Logging

## Build 🔨

### Prerequisites
- .NET 8 SDK (or later)
- SQL Server 2019+ (or SQL Server Docker Image)
- Docker & Docker Compose (optional, for containerized deployment)

### Local Development Build
```bash
cd /workspaces/cautious-invention

# Clean previous builds
dotnet clean

# Restore NuGet packages
dotnet restore

# Build in Debug mode
dotnet build

# Build in Release mode
dotnet build -c Release
```

### Publish Release Build
```bash
# Publish to /tmp/HumanAssist-Release
dotnet publish -c Release -o /tmp/HumanAssist-Release

# The executable will be ready at: /tmp/HumanAssist-Release/HumanAssist.dll
```

## Configuration ⚙️

### appsettings.json Configuration

Update the `appsettings.json` file with your API keys and database connection:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER;Database=HumanAssistDB;User Id=sa;Password=YourPassword123!;Encrypt=false;TrustServerCertificate=true;"
  },
  "Jwt": {
    "SecretKey": "your-very-long-secret-key-minimum-32-characters-here",
    "Issuer": "HumanAssistPlatform",
    "Audience": "HumanAssistUsers",
    "ExpirationMinutes": 60
  },
  "Security": {
    "EncryptionKey": "your-64-character-encryption-key-here"
  },
  "OpenAI": {
    "ApiKey": "sk-your-openai-api-key-here",
    "Model": "gpt-4",
    "MaxTokens": 2000
  },
  "Translation": {
    "Provider": "google",
    "GoogleApiKey": "your-google-translate-api-key",
    "AzureApiKey": "your-azure-translator-key",
    "AzureRegion": "eastus"
  },
  "GoogleMaps": {
    "ApiKey": "your-google-maps-api-key"
  },
  "RateLimiting": {
    "DefaultRequestsPerMinute": 60,
    "ApiKeyRequestsPerDay": 1000
  }
}
```

## Running the Application 🚀

### Method 1: Direct Execution (Linux/macOS/Windows)
```bash
cd /tmp/HumanAssist-Release

# Start SQL Server (or ensure it's running)
# For Docker: docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=YourPassword123!' -p 1433:1433 -d mcr.microsoft.com/mssql/server

# Run the application
dotnet HumanAssist.dll

# Application will be available at: http://localhost:5000
# Swagger API documentation: http://localhost:5000/swagger
```

### Method 2: Docker Deployment (Recommended)
```bash
cd /workspaces/cautious-invention

# Build Docker image
docker build -t humanassist:latest .

# Run with Docker Compose (includes SQL Server)
docker-compose up --build

# Access the application at: http://localhost:5000
# API Docs: http://localhost:5000/swagger

# Stop the services
docker-compose down
```

### Method 3: Kubernetes Deployment
```bash
# Create namespace
kubectl create namespace humanassist

# Apply configurations
kubectl apply -f kubernetes-manifests/ -n humanassist

# Check status
kubectl get pods -n humanassist
kubectl get svc -n humanassist
```

## Database Setup 🗄️

### Automatic Migration
The application automatically runs migrations on startup. Ensure your database server is running and accessible.

### Manual Migration
```bash
# Create database
dotnet ef database update

# View migrations
dotnet ef migrations list

# Add new migration
dotnet ef migrations add MigrationName

# Remove last migration
dotnet ef migrations remove
```

## API Endpoints 📡

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh JWT token

### AI Services
- `POST /api/ai/analyze` - Analyze text with AI
- `POST /api/ai/generate` - Generate AI response
- `POST /api/codegen` - Generate code with AI

### Geolocation
- `GET /api/geolocation/ip/{ipAddress}` - Get location by IP
- `GET /api/geolocation/coordinates?latitude=X&longitude=Y` - Get location by coordinates
- `GET /api/geolocation/timezone` - Get timezone info
- `POST /api/geolocation/permission` - Set location tracking permission

### Audio/Sound
- `POST /api/audio/transcribe` - Transcribe audio to text
- `POST /api/audio/synthesize` - Text-to-speech conversion
- `POST /api/audio/translate-audio` - Translate audio
- `GET /api/audio/supported-languages` - Get supported languages

### Image Processing
- `POST /api/image/generate` - Generate image from text
- `POST /api/image/analyze` - Analyze image
- `POST /api/image/extract-text` - OCR text extraction
- `POST /api/image/process` - Process image
- `POST /api/image/video/generate` - Generate video

### Translation
- `GET /api/translation/languages` - Get supported languages
- `POST /api/translation/translate` - Translate text

### Full API Documentation
Visit `http://localhost:5000/swagger` for interactive API documentation

## System Services ✨

### Geolocation Service
- IP-based geolocation using ip-api.com
- Reverse geocoding with OpenStreetMap/Nominatim
- Timezone detection with Google Maps API
- User location history tracking
- Privacy-respecting location permissions

### Audio Service
- Speech-to-text transcription (Whisper API)
- Text-to-speech synthesis (TTS)
- Audio translation capabilities
- Multiple language support
- Usage tracking

### Image Service
- AI image generation (DALL-E 3)
- Image analysis and description
- OCR text extraction
- Video generation support
- Image processing operations

### Translation Service
- Multi-language support
- Google Translate integration
- Azure Translator integration
- Translation caching for performance
- User language preferences

### Security Features
- JWT authentication with role-based authorization
- AES-256 encryption for sensitive data
- API key management with monitoring
- Audit logging for all operations
- Rate limiting and DDoS protection
- SQL injection prevention with parameterized queries

## Monitoring & Logging 📊

### Logs Location
- Console output (real-time)
- File logs: `logs/app-{date}.txt`

### Key Metrics
- API request metrics
- Response times
- Error rates
- Authentication attempts
- API key usage statistics

### Health Check
```bash
curl http://localhost:5000/health
```

## Performance Optimization ⚡

- Async/await throughout for non-blocking I/O
- Database query optimization with Entity Framework Core
- Caching layer for translations and frequently accessed data
- Connection pooling for database connections
- HTTP/2 support for faster communication

## Environment Variables 🔐

Create `.env` file in the application directory:
```bash
ASPNETCORE_ENVIRONMENT=Production
CONNECTION_STRING=Server=sqlserver;Database=HumanAssistDB;User Id=sa;Password=YourPassword123!;
OPENAI_API_KEY=sk-your-key
JWT_SECRET_KEY=your-long-secret-key-here
```

## Troubleshooting 🔧

### Port Already in Use
```bash
# Linux/macOS
lsof -i :5000
kill -9 PID

# Windows
netstat -ano | findstr :5000
taskkill /PID PID /F
```

### Database Connection Issues
```bash
# Test SQL Server connectivity
sqlcmd -S localhost -U sa -P YourPassword123! -Q "SELECT @@VERSION"
```

### API Key Issues
- Ensure OpenAI API key is valid and has sufficient credits
- Check Google API quotas if using geolocation
- Verify Azure credentials for translation services

### Build Issues
```bash
# Clear all build artifacts
dotnet clean
rm -rf bin obj

# Rebuild from scratch
dotnet restore
dotnet build -c Release
```

## Production Deployment Checklist ✅

- [ ] Update all API keys in configuration
- [ ] Set strong JWT secret key (min. 32 characters)
- [ ] Configure encryption key (64 characters)
- [ ] Set ASPNETCORE_ENVIRONMENT=Production
- [ ] Enable HTTPS with valid SSL certificate
- [ ] Configure database backups
- [ ] Set up monitoring and alerting
- [ ] Enable audit logging
- [ ] Configure rate limiting
- [ ] Test all external API connections
- [ ] Load test the application
- [ ] Set up CI/CD pipeline
- [ ] Document custom API endpoints
- [ ] Create disaster recovery plan

## Support & Documentation 📚

- API Documentation: http://localhost:5000/swagger
- Project README: /workspaces/cautious-invention/README.md
- Comprehensive Guide: /workspaces/cautious-invention/README-COMPREHENSIVE.md
- Implementation Guide: /workspaces/cautious-invention/IMPLEMENTATION-GUIDE.md
- Testing Guide: /workspaces/cautious-invention/TESTING-GUIDE.md

## License 📄

This project is provided as-is for educational and commercial use.

---

**Build Date**: March 5, 2026
**Framework**: .NET 8.0
**Database**: SQL Server 2019+
**Status**: Production Ready ✅
