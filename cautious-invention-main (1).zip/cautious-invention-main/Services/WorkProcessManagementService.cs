namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface IWorkProcessManagementService
{
    Task<(bool success, WorkProcess process, string? error)> CreateWorkProcessAsync(WorkProcess process, int userId);
    Task<(bool success, WorkProcess? process, string? error)> GetWorkProcessAsync(int processId, int userId);
    Task<List<WorkProcess>> GetUserWorkProcessesAsync(int userId);
    Task<(bool success, string? error)> UpdateWorkProcessAsync(WorkProcess process, int userId);
    Task<(bool success, string? error)> DeleteWorkProcessAsync(int processId, int userId);
    Task<(bool success, SituationResponse response, string? error)> HandleSituationAsync(Situation situation, int userId);
    Task<List<Situation>> GetUnhandledSituationsAsync(int userId);
    Task<(bool success, string? error)> MarkSituationHandledAsync(int situationId, int userId, string resolution);
    Task<(bool success, AutomationRule rule, string? error)> CreateAutomationRuleAsync(AutomationRule rule, int userId);
    Task<List<AutomationRule>> GetActiveAutomationRulesAsync(int userId);
    Task<(bool success, string? error)> ExecuteAutomationRuleAsync(int ruleId, Dictionary<string, object> context, int userId);
    Task<(bool success, ProcessOptimization optimization, string? error)> OptimizeWorkProcessAsync(int processId, int userId);
    Task<List<ProcessMetric>> GetProcessMetricsAsync(int processId, int userId);
}

public class WorkProcessManagementService : IWorkProcessManagementService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<WorkProcessManagementService> _logger;
    private readonly IConfiguration _configuration;

    public WorkProcessManagementService(
        ApplicationDbContext context,
        ILogger<WorkProcessManagementService> logger,
        IConfiguration configuration)
    {
        _context = context;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<(bool success, WorkProcess process, string? error)> CreateWorkProcessAsync(WorkProcess process, int userId)
    {
        try
        {
            process.UserId = userId;
            process.CreatedAt = DateTime.UtcNow;
            process.LastModifiedAt = DateTime.UtcNow;
            process.Status = "Active";

            _context.WorkProcesses.Add(process);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Created work process for user {UserId}: {ProcessName}", userId, process.ProcessName);
            return (true, process, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating work process for user {UserId}", userId);
            return (false, new WorkProcess(), ex.Message);
        }
    }

    public async Task<(bool success, WorkProcess? process, string? error)> GetWorkProcessAsync(int processId, int userId)
    {
        try
        {
            var process = await _context.WorkProcesses
                .Include(p => p.Steps)
                .Include(p => p.Metrics)
                .FirstOrDefaultAsync(p => p.Id == processId && p.UserId == userId);

            if (process == null)
                return (false, null, $"Work process {processId} not found");

            return (true, process, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving work process {ProcessId} for user {UserId}", processId, userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<List<WorkProcess>> GetUserWorkProcessesAsync(int userId)
    {
        try
        {
            return await _context.WorkProcesses
                .Where(p => p.UserId == userId)
                .Include(p => p.Steps)
                .OrderByDescending(p => p.LastModifiedAt)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving work processes for user {UserId}", userId);
            return new List<WorkProcess>();
        }
    }

    public async Task<(bool success, string? error)> UpdateWorkProcessAsync(WorkProcess process, int userId)
    {
        try
        {
            var existing = await _context.WorkProcesses
                .FirstOrDefaultAsync(p => p.Id == process.Id && p.UserId == userId);

            if (existing == null)
                return (false, $"Work process {process.Id} not found");

            existing.ProcessName = process.ProcessName;
            existing.Description = process.Description;
            existing.Category = process.Category;
            existing.Priority = process.Priority;
            existing.Status = process.Status;
            existing.LastModifiedAt = DateTime.UtcNow;

            _context.WorkProcesses.Update(existing);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Updated work process {ProcessId} for user {UserId}", process.Id, userId);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating work process {ProcessId} for user {UserId}", process.Id, userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> DeleteWorkProcessAsync(int processId, int userId)
    {
        try
        {
            var process = await _context.WorkProcesses
                .FirstOrDefaultAsync(p => p.Id == processId && p.UserId == userId);

            if (process == null)
                return (false, $"Work process {processId} not found");

            _context.WorkProcesses.Remove(process);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Deleted work process {ProcessId} for user {UserId}", processId, userId);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting work process {ProcessId} for user {UserId}", processId, userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, SituationResponse response, string? error)> HandleSituationAsync(Situation situation, int userId)
    {
        try
        {
            situation.UserId = userId;
            situation.ReportedAt = DateTime.UtcNow;
            situation.Status = "Analyzing";

            _context.Situations.Add(situation);
            await _context.SaveChangesAsync();

            // Analyze situation and generate response
            var response = new SituationResponse
            {
                SituationId = situation.Id,
                UserId = userId,
                ResponseType = DetermineResponseType(situation),
                Priority = DeterminePriority(situation),
                RecommendedActions = GenerateRecommendedActions(situation),
                EstimatedResolutionTime = EstimateResolutionTime(situation),
                GeneratedAt = DateTime.UtcNow
            };

            _context.SituationResponses.Add(response);
            await _context.SaveChangesAsync();

            situation.Status = "ResponseGenerated";
            _context.Situations.Update(situation);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Handled situation for user {UserId}: {SituationType}", userId, situation.SituationType);
            return (true, response, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling situation for user {UserId}", userId);
            return (false, new SituationResponse(), ex.Message);
        }
    }

    public async Task<List<Situation>> GetUnhandledSituationsAsync(int userId)
    {
        try
        {
            return await _context.Situations
                .Where(s => s.UserId == userId && s.Status != "Resolved")
                .OrderByDescending(s => s.ReportedAt)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving unhandled situations for user {UserId}", userId);
            return new List<Situation>();
        }
    }

    public async Task<(bool success, string? error)> MarkSituationHandledAsync(int situationId, int userId, string resolution)
    {
        try
        {
            var situation = await _context.Situations
                .FirstOrDefaultAsync(s => s.Id == situationId && s.UserId == userId);

            if (situation == null)
                return (false, $"Situation {situationId} not found");

            situation.Status = "Resolved";
            situation.Resolution = resolution;
            situation.ResolvedAt = DateTime.UtcNow;

            _context.Situations.Update(situation);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Marked situation {SituationId} as handled for user {UserId}", situationId, userId);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marking situation {SituationId} as handled for user {UserId}", situationId, userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, AutomationRule rule, string? error)> CreateAutomationRuleAsync(AutomationRule rule, int userId)
    {
        try
        {
            rule.UserId = userId;
            rule.CreatedAt = DateTime.UtcNow;
            rule.LastModifiedAt = DateTime.UtcNow;
            rule.IsActive = true;

            _context.AutomationRules.Add(rule);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Created automation rule for user {UserId}: {RuleName}", userId, rule.RuleName);
            return (true, rule, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating automation rule for user {UserId}", userId);
            return (false, new AutomationRule(), ex.Message);
        }
    }

    public async Task<List<AutomationRule>> GetActiveAutomationRulesAsync(int userId)
    {
        try
        {
            return await _context.AutomationRules
                .Where(r => r.UserId == userId && r.IsActive)
                .OrderBy(r => r.Priority)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving active automation rules for user {UserId}", userId);
            return new List<AutomationRule>();
        }
    }

    public async Task<(bool success, string? error)> ExecuteAutomationRuleAsync(int ruleId, Dictionary<string, object> context, int userId)
    {
        try
        {
            var rule = await _context.AutomationRules
                .FirstOrDefaultAsync(r => r.Id == ruleId && r.UserId == userId && r.IsActive);

            if (rule == null)
                return (false, $"Automation rule {ruleId} not found or inactive");

            // Execute the automation rule based on its type
            var execution = new AutomationExecution
            {
                RuleId = ruleId,
                UserId = userId,
                ExecutionContext = JsonSerializer.Serialize(context),
                ExecutedAt = DateTime.UtcNow,
                Status = "Completed"
            };

            _context.AutomationExecutions.Add(execution);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Executed automation rule {RuleId} for user {UserId}", ruleId, userId);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing automation rule {RuleId} for user {UserId}", ruleId, userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, ProcessOptimization optimization, string? error)> OptimizeWorkProcessAsync(int processId, int userId)
    {
        try
        {
            var process = await _context.WorkProcesses
                .Include(p => p.Metrics)
                .FirstOrDefaultAsync(p => p.Id == processId && p.UserId == userId);

            if (process == null)
                return (false, new ProcessOptimization(), $"Work process {processId} not found");

            var optimization = new ProcessOptimization
            {
                ProcessId = processId,
                UserId = userId,
                OptimizationDate = DateTime.UtcNow,
                EfficiencyGain = CalculateEfficiencyGain(process),
                BottleneckIdentified = IdentifyBottlenecks(process),
                Recommendations = GenerateOptimizationRecommendations(process),
                EstimatedImprovement = EstimateImprovement(process)
            };

            _context.ProcessOptimizations.Add(optimization);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Optimized work process {ProcessId} for user {UserId}", processId, userId);
            return (true, optimization, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error optimizing work process {ProcessId} for user {UserId}", processId, userId);
            return (false, new ProcessOptimization(), ex.Message);
        }
    }

    public async Task<List<ProcessMetric>> GetProcessMetricsAsync(int processId, int userId)
    {
        try
        {
            return await _context.ProcessMetrics
                .Where(m => m.ProcessId == processId && m.UserId == userId)
                .OrderByDescending(m => m.RecordedAt)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving process metrics for process {ProcessId} and user {UserId}", processId, userId);
            return new List<ProcessMetric>();
        }
    }

    private string DetermineResponseType(Situation situation)
    {
        return situation.SituationType switch
        {
            "Technical" => "TechnicalSupport",
            "Process" => "ProcessOptimization",
            "Resource" => "ResourceAllocation",
            "Quality" => "QualityImprovement",
            _ => "GeneralSupport"
        };
    }

    private string DeterminePriority(Situation situation)
    {
        return situation.Urgency switch
        {
            "Critical" => "High",
            "High" => "High",
            "Medium" => "Medium",
            "Low" => "Low",
            _ => "Medium"
        };
    }

    private List<string> GenerateRecommendedActions(Situation situation)
    {
        return situation.SituationType switch
        {
            "Technical" => new List<string> { "Analyze error logs", "Check system resources", "Review recent changes", "Contact technical support" },
            "Process" => new List<string> { "Review process documentation", "Identify bottlenecks", "Optimize workflow", "Train team members" },
            "Resource" => new List<string> { "Assess resource utilization", "Reallocate resources", "Plan capacity expansion", "Monitor usage patterns" },
            "Quality" => new List<string> { "Conduct quality audit", "Implement quality controls", "Review standards compliance", "Training and certification" },
            _ => new List<string> { "Gather more information", "Consult with experts", "Document findings", "Develop action plan" }
        };
    }

    private TimeSpan EstimateResolutionTime(Situation situation)
    {
        return situation.Urgency switch
        {
            "Critical" => TimeSpan.FromHours(2),
            "High" => TimeSpan.FromHours(8),
            "Medium" => TimeSpan.FromDays(2),
            "Low" => TimeSpan.FromDays(7),
            _ => TimeSpan.FromDays(1)
        };
    }

    private double CalculateEfficiencyGain(WorkProcess process)
    {
        if (process.Metrics == null || !process.Metrics.Any())
            return 0.1;

        var avgEfficiency = process.Metrics.Average(m => m.Efficiency);
        return Math.Min(avgEfficiency * 0.15, 0.3); // Up to 30% improvement
    }

    private string IdentifyBottlenecks(WorkProcess process)
    {
        if (process.Metrics == null || !process.Metrics.Any())
            return "No metrics available for analysis";

        var bottlenecks = process.Metrics
            .Where(m => m.Efficiency < 0.7)
            .Select(m => $"Step {m.StepId}: Low efficiency ({m.Efficiency:P0})")
            .ToList();

        return bottlenecks.Any() ? string.Join("; ", bottlenecks) : "No significant bottlenecks identified";
    }

    private List<string> GenerateOptimizationRecommendations(WorkProcess process)
    {
        var recommendations = new List<string>
        {
            "Implement automated monitoring",
            "Streamline approval processes",
            "Enhance communication channels",
            "Provide additional training",
            "Optimize resource allocation"
        };

        return recommendations;
    }

    private double EstimateImprovement(WorkProcess process)
    {
        return process.Metrics?.Average(m => m.Efficiency) * 0.2 ?? 0.15;
    }
}
