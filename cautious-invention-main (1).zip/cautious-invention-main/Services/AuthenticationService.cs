namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.IdentityModel.Tokens;

public interface IAuthenticationService
{
    Task<(bool success, string token, string? refreshToken, string? error)> LoginAsync(string email, string password);
    Task<(bool success, User? user, string? error)> RegisterAsync(string email, string password, string firstName, string lastName);
    Task<(bool success, string? token, string? error)> RefreshTokenAsync(string refreshToken);
    Task LogoutAsync(int userId);
    Task<bool> ValidateTokenAsync(string token);
    Task<(bool success, string? token, string? error)> AuthenticateOrCreateSocialUserAsync(string email, string name, string provider, string providerId);
}

public class AuthenticationService : IAuthenticationService
{
    private readonly ApplicationDbContext _context;
    private readonly IEncryptionService _encryptionService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<AuthenticationService> _logger;

    public AuthenticationService(
        ApplicationDbContext context,
        IEncryptionService encryptionService,
        IConfiguration configuration,
        ILogger<AuthenticationService> logger)
    {
        _context = context;
        _encryptionService = encryptionService;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, string token, string? refreshToken, string? error)> LoginAsync(string email, string password)
    {
        try
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email && u.IsActive);
            if (user == null)
                return (false, string.Empty, null, "Invalid credentials");

            var authUser = await _context.AuthUsers.FirstOrDefaultAsync(au => au.UserId == user.Id);
            if (authUser == null)
                return (false, string.Empty, null, "Authentication record not found");

            if (!_encryptionService.VerifyPassword(password, authUser.PasswordHash))
            {
                authUser.FailedLoginAttempts++;
                if (authUser.FailedLoginAttempts >= 5)
                    authUser.IsLocked = true;
                _context.AuthUsers.Update(authUser);
                await _context.SaveChangesAsync();
                return (false, string.Empty, null, "Invalid credentials");
            }

            if (authUser.IsLocked)
                return (false, string.Empty, null, "Account is locked");

            // Reset failed attempts
            authUser.FailedLoginAttempts = 0;
            authUser.LastLogin = DateTime.UtcNow;

            var token = GenerateJwtToken(user);
            var refreshToken = GenerateRefreshToken();
            
            authUser.RefreshToken = refreshToken;
            authUser.RefreshTokenExpiry = DateTime.UtcNow.AddDays(7);
            _context.AuthUsers.Update(authUser);
            await _context.SaveChangesAsync();

            _logger.LogInformation("User {UserId} logged in successfully", user.Id);
            return (true, token, refreshToken, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Login error");
            return (false, string.Empty, null, "Internal server error");
        }
    }

    public async Task<(bool success, User? user, string? error)> RegisterAsync(string email, string password, string firstName, string lastName)
    {
        try
        {
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (existingUser != null)
                return (false, null, "Email already registered");

            var user = new User
            {
                Email = email,
                FirstName = firstName,
                LastName = lastName,
                Role = "User",
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            var authUser = new AuthUser
            {
                UserId = user.Id,
                PasswordHash = _encryptionService.HashPassword(password),
                IsLocked = false,
                FailedLoginAttempts = 0,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            authUser.UserId = user.Id;
            _context.AuthUsers.Add(authUser);
            await _context.SaveChangesAsync();

            _logger.LogInformation("User {UserId} registered successfully", user.Id);
            return (true, user, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Registration error");
            return (false, null, "Registration failed");
        }
    }

    public async Task<(bool success, string? token, string? error)> RefreshTokenAsync(string refreshToken)
    {
        try
        {
            var authUser = await _context.AuthUsers
                .Include(au => au.User)
                .FirstOrDefaultAsync(au => au.RefreshToken == refreshToken && au.RefreshTokenExpiry > DateTime.UtcNow);

            if (authUser?.User == null)
                return (false, null, "Invalid or expired refresh token");

            var newToken = GenerateJwtToken(authUser.User);
            return (true, newToken, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Token refresh error");
            return (false, null, "Token refresh failed");
        }
    }

    public async Task LogoutAsync(int userId)
    {
        var authUser = await _context.AuthUsers.FirstOrDefaultAsync(au => au.UserId == userId);
        if (authUser != null)
        {
            authUser.RefreshToken = null;
            authUser.RefreshTokenExpiry = null;
            _context.AuthUsers.Update(authUser);
            await _context.SaveChangesAsync();
        }
    }

    public async Task<bool> ValidateTokenAsync(string token)
    {
        try
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:SecretKey"] ?? "change-this-to-a-very-long-secret-key-minimum-32-characters");
            tokenHandler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = _configuration["Jwt:Issuer"],
                ValidateAudience = true,
                ValidAudience = _configuration["Jwt:Audience"],
                ValidateLifetime = true
            }, out SecurityToken validatedToken);

            return validatedToken is JwtSecurityToken;
        }
        catch
        {
            return false;
        }
    }

    public async Task<(bool success, string? token, string? error)> AuthenticateOrCreateSocialUserAsync(string email, string name, string provider, string providerId)
    {
        try
        {
            // Check if user already exists with this social provider
            var existingSocialUser = await _context.SocialAuthUsers
                .Include(su => su.User)
                .FirstOrDefaultAsync(su => su.Provider == provider && su.ProviderId == providerId);

            if (existingSocialUser?.User != null)
            {
                // User exists, generate token
                var token = GenerateJwtToken(existingSocialUser.User);
                _logger.LogInformation("Existing social user authenticated: {Provider} {Email}", provider, email);
                return (true, token, null);
            }

            // Check if user exists with same email
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            User user;

            if (existingUser != null)
            {
                // Link social account to existing user
                user = existingUser;
            }
            else
            {
                // Create new user
                var nameParts = name?.Split(' ') ?? new[] { "Social", "User" };
                user = new User
                {
                    Email = email,
                    FirstName = nameParts.Length > 0 ? nameParts[0] : "Social",
                    LastName = nameParts.Length > 1 ? string.Join(" ", nameParts.Skip(1)) : "User",
                    Role = "User",
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                };
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
            }

            // Create social auth record
            var socialAuthUser = new SocialAuthUser
            {
                UserId = user.Id,
                Provider = provider,
                ProviderId = providerId,
                Email = email,
                Name = name,
                CreatedAt = DateTime.UtcNow,
                LastLogin = DateTime.UtcNow
            };

            _context.SocialAuthUsers.Add(socialAuthUser);
            await _context.SaveChangesAsync();

            var token = GenerateJwtToken(user);
            _logger.LogInformation("New social user created and authenticated: {Provider} {Email}", provider, email);
            return (true, token, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Social authentication error for {Provider}", provider);
            return (false, null, "Social authentication failed");
        }
    }

    private string GenerateJwtToken(User user)
    {
        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(_configuration["Jwt:SecretKey"] ?? "change-this-to-a-very-long-secret-key-minimum-32-characters");

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
                new Claim("role", user.Role)
            }),
            Expires = DateTime.UtcNow.AddHours(1),
            Issuer = _configuration["Jwt:Issuer"],
            Audience = _configuration["Jwt:Audience"],
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }

    private string GenerateRefreshToken()
    {
        var randomNumber = new byte[32];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }
    }
}
