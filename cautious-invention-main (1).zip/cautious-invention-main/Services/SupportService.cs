namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;

public interface ISupportService
{
    Task<List<ProblemHandlingSkill>> GetAvailableSkillsAsync();
    Task<SupportTicket> CreateTicketAsync(SupportTicket ticket);
    Task<SupportTicket?> GetTicketAsync(int ticketId);
    Task<List<SupportTicket>> GetUserTicketsAsync(int userId);
    Task<bool> UpdateTicketAsync(SupportTicket ticket);
    Task<SupportConversation> AddConversationAsync(SupportConversation conversation);
    Task<List<SupportConversation>> GetTicketConversationsAsync(int ticketId);
    Task<List<SupportTicket>> GetOpenTicketsAsync();
    Task<(bool success, SupportTicket? ticket)> AutoAssignTicketAsync(SupportTicket ticket);
}

public class SupportService : ISupportService
{
    private readonly ApplicationDbContext _context;
    private readonly IAIService _aiService;
    private readonly ILogger<SupportService> _logger;

    public SupportService(
        ApplicationDbContext context,
        IAIService aiService,
        ILogger<SupportService> logger)
    {
        _context = context;
        _aiService = aiService;
        _logger = logger;
    }

    public async Task<List<ProblemHandlingSkill>> GetAvailableSkillsAsync()
    {
        return await _context.ProblemHandlingSkills
            .Where(s => s.IsActive)
            .OrderByDescending(s => s.SuccessRate)
            .ToListAsync();
    }

    public async Task<SupportTicket> CreateTicketAsync(SupportTicket ticket)
    {
        ticket.CreatedAt = DateTime.UtcNow;
        _context.SupportTickets.Add(ticket);
        await _context.SaveChangesAsync();
        _logger.LogInformation("Support ticket {TicketId} created by user {UserId}", ticket.Id, ticket.UserId);
        return ticket;
    }

    public async Task<SupportTicket?> GetTicketAsync(int ticketId)
    {
        return await _context.SupportTickets
            .Include(t => t.User)
            .Include(t => t.AssignedSkill)
            .Include(t => t.AssignedTo)
            .Include(t => t.Conversations)
            .FirstOrDefaultAsync(t => t.Id == ticketId);
    }

    public async Task<List<SupportTicket>> GetUserTicketsAsync(int userId)
    {
        return await _context.SupportTickets
            .Where(t => t.UserId == userId)
            .Include(t => t.AssignedSkill)
            .OrderByDescending(t => t.CreatedAt)
            .ToListAsync();
    }

    public async Task<bool> UpdateTicketAsync(SupportTicket ticket)
    {
        try
        {
            _context.SupportTickets.Update(ticket);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating support ticket {TicketId}", ticket.Id);
            return false;
        }
    }

    public async Task<SupportConversation> AddConversationAsync(SupportConversation conversation)
    {
        conversation.CreatedAt = DateTime.UtcNow;
        _context.SupportConversations.Add(conversation);
        await _context.SaveChangesAsync();
        return conversation;
    }

    public async Task<List<SupportConversation>> GetTicketConversationsAsync(int ticketId)
    {
        return await _context.SupportConversations
            .Where(c => c.SupportTicketId == ticketId)
            .Include(c => c.SenderUser)
            .OrderBy(c => c.CreatedAt)
            .ToListAsync();
    }

    public async Task<List<SupportTicket>> GetOpenTicketsAsync()
    {
        return await _context.SupportTickets
            .Where(t => t.Status == "Open" || t.Status == "In Progress")
            .Include(t => t.User)
            .Include(t => t.AssignedSkill)
            .OrderBy(t => t.Severity == "Critical" ? 0 : (t.Severity == "High" ? 1 : 2))
            .ThenBy(t => t.CreatedAt)
            .ToListAsync();
    }

    public async Task<(bool success, SupportTicket? ticket)> AutoAssignTicketAsync(SupportTicket ticket)
    {
        try
        {
            // Find best matching skill
            var skills = await _context.ProblemHandlingSkills
                .Where(s => s.IsActive && s.Category == ticket.Category)
                .OrderByDescending(s => s.SuccessRate)
                .FirstOrDefaultAsync();

            if (skills != null)
            {
                ticket.AssignedSkillId = skills.Id;
            }

            // Find available assistant
            var assistants = await _context.Users
                .Where(u => u.Role == "Assistant" && u.IsActive)
                .ToListAsync();

            if (assistants.Any())
            {
                // Simple round-robin assignment
                var randomAssistant = assistants[Random.Shared.Next(assistants.Count)];
                ticket.AssignedToUserId = randomAssistant.Id;
            }

            return (true, ticket);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error auto-assigning ticket");
            return (false, null);
        }
    }
}
