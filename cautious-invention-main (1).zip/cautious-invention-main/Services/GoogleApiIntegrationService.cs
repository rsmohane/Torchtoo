namespace HumanAssist.Services;

using System.Diagnostics;
using System.Text.Json;
using Microsoft.Extensions.Logging;

public interface IGoogleApiIntegrationService
{
    Task<(bool success, string result, string? error)> AuthenticateGoogleAsync(string accessToken);
    Task<(bool success, dynamic? data, string? error)> GetGoogleSheetsAsync(string spreadsheetId, string range);
    Task<(bool success, string? error)> WriteGoogleSheetsAsync(string spreadsheetId, string range, List<List<object>> values);
    Task<(bool success, List<dynamic>? files, string? error)> ListGoogleDriveFilesAsync();
    Task<(bool success, string content, string? error)> ReadGoogleDriveFileAsync(string fileId);
    Task<(bool success, string? error)> SendGoogleGmailAsync(string to, string subject, string body);
    Task<(bool success, List<dynamic>? emails, string? error)> GetGoogleGmailAsync(string query, int limit = 10);
}

public class GoogleApiIntegrationService : IGoogleApiIntegrationService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<GoogleApiIntegrationService> _logger;
    private readonly IConfiguration _configuration;

    public GoogleApiIntegrationService(
        IHttpClientFactory httpClientFactory,
        ILogger<GoogleApiIntegrationService> logger,
        IConfiguration configuration)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<(bool success, string result, string? error)> AuthenticateGoogleAsync(string accessToken)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync($"https://www.googleapis.com/oauth2/v1/userinfo?access_token={accessToken}");

            if (!response.IsSuccessStatusCode)
                return (false, "", $"Google authentication failed: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            _logger.LogInformation("Successfully authenticated with Google API");
            return (true, content, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error authenticating with Google API");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, dynamic? data, string? error)> GetGoogleSheetsAsync(string spreadsheetId, string range)
    {
        try
        {
            var apiKey = _configuration["GoogleApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var url = $"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheetId}/values/{Uri.EscapeDataString(range)}?key={apiKey}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to retrieve Google Sheets: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var data = JsonSerializer.Deserialize<dynamic>(content);

            _logger.LogInformation("Retrieved data from Google Sheets: {SpreadsheetId}", spreadsheetId);
            return (true, data, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving Google Sheets");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> WriteGoogleSheetsAsync(string spreadsheetId, string range, List<List<object>> values)
    {
        try
        {
            var apiKey = _configuration["GoogleApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var url = $"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheetId}/values/{Uri.EscapeDataString(range)}?valueInputOption=USER_ENTERED&key={apiKey}";
            
            var requestBody = new
            {
                values = values
            };

            var content = new StringContent(
                JsonSerializer.Serialize(requestBody),
                System.Text.Encoding.UTF8,
                "application/json");

            var response = await client.PutAsync(url, content);

            if (!response.IsSuccessStatusCode)
                return (false, $"Failed to write Google Sheets: {response.StatusCode}");

            _logger.LogInformation("Wrote data to Google Sheets: {SpreadsheetId}", spreadsheetId);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error writing to Google Sheets");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, List<dynamic>? files, string? error)> ListGoogleDriveFilesAsync()
    {
        try
        {
            var apiKey = _configuration["GoogleApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var url = $"https://www.googleapis.com/drive/v3/files?pageSize=10&fields=files(id,name,mimeType)&key={apiKey}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to list Google Drive files: {response.StatusCode}");

            var jsonContent = await response.Content.ReadAsStringAsync();
            var data = JsonSerializer.Deserialize<JsonElement>(jsonContent);
            var files = data.GetProperty("files").EnumerateArray().ToList();

            _logger.LogInformation("Listed {Count} files from Google Drive", files.Count);
            return (true, files.Cast<dynamic>().ToList(), null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing Google Drive files");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string content, string? error)> ReadGoogleDriveFileAsync(string fileId)
    {
        try
        {
            var apiKey = _configuration["GoogleApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var url = $"https://www.googleapis.com/drive/v3/files/{fileId}?alt=media&key={apiKey}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, "", $"Failed to read Google Drive file: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            _logger.LogInformation("Read file from Google Drive: {FileId}", fileId);
            return (true, content, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reading Google Drive file");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, string? error)> SendGoogleGmailAsync(string to, string subject, string body)
    {
        try
        {
            var apiKey = _configuration["GoogleApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var message = new
            {
                raw = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"To: {to}\r\nSubject: {subject}\r\n\r\n{body}"))
            };

            var url = $"https://gmail.googleapis.com/gmail/v1/users/me/messages/send?key={apiKey}";
            var content = new StringContent(
                JsonSerializer.Serialize(message),
                System.Text.Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync(url, content);

            if (!response.IsSuccessStatusCode)
                return (false, $"Failed to send Gmail: {response.StatusCode}");

            _logger.LogInformation("Sent Gmail to: {To}", to);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending Gmail");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, List<dynamic>? emails, string? error)> GetGoogleGmailAsync(string query, int limit = 10)
    {
        try
        {
            var apiKey = _configuration["GoogleApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var url = $"https://gmail.googleapis.com/gmail/v1/users/me/messages?q={Uri.EscapeDataString(query)}&maxResults={limit}&key={apiKey}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to retrieve Gmail messages: {response.StatusCode}");

            var jsonContent = await response.Content.ReadAsStringAsync();
            var data = JsonSerializer.Deserialize<JsonElement>(jsonContent);
            var messages = data.TryGetProperty("messages", out var msgs) 
                ? msgs.EnumerateArray().ToList() 
                : new List<JsonElement>();

            _logger.LogInformation("Retrieved {Count} Gmail messages", messages.Count);
            return (true, messages.Cast<dynamic>().ToList(), null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving Gmail messages");
            return (false, null, ex.Message);
        }
    }
}
