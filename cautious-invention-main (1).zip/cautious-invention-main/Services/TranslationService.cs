namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface ITranslationService
{
    Task<(bool success, string translatedText, string? error)> TranslateAsync(string text, string sourceLanguage, string targetLanguage, int userId);
    Task<List<SupportedLanguage>> GetSupportedLanguagesAsync();
    Task<bool> SetUserLanguagePreferenceAsync(int userId, string preferredLanguage, string? secondaryLanguage = null);
    Task<UserLanguagePreference?> GetUserLanguagePreferenceAsync(int userId);
    Task<string?> GetTranslationFromCacheAsync(string text, string sourceLanguage, string targetLanguage);
    Task<bool> CacheTranslationAsync(string text, string sourceLanguage, string targetLanguage, string translatedText, double confidenceScore);
}

public class TranslationService : ITranslationService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<TranslationService> _logger;

    public TranslationService(
        ApplicationDbContext context,
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<TranslationService> logger)
    {
        _context = context;
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, string translatedText, string? error)> TranslateAsync(string text, string sourceLanguage, string targetLanguage, int userId)
    {
        try
        {
            // Check cache first
            var cached = await GetTranslationFromCacheAsync(text, sourceLanguage, targetLanguage);
            if (!string.IsNullOrEmpty(cached))
            {
                _logger.LogInformation("Translation retrieved from cache for user {UserId}", userId);
                return (true, cached, null);
            }

            // Use Google Translate API or Azure Translator
            var translationProvider = _configuration["Translation:Provider"] ?? "google";
            
            var (success, result, error) = translationProvider.ToLower() switch
            {
                "google" => await TranslateWithGoogleAsync(text, sourceLanguage, targetLanguage),
                "azure" => await TranslateWithAzureAsync(text, sourceLanguage, targetLanguage),
                _ => (false, string.Empty, "Translation provider not configured")
            };

            if (success)
            {
                // Cache the translation
                await CacheTranslationAsync(text, sourceLanguage, targetLanguage, result, 0.95);
                _logger.LogInformation("Translation completed for user {UserId}", userId);
            }

            return (success, result, error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Translation error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<List<SupportedLanguage>> GetSupportedLanguagesAsync()
    {
        return await _context.SupportedLanguages
            .Where(l => l.IsActive)
            .OrderBy(l => l.LanguageName)
            .ToListAsync();
    }

    public async Task<bool> SetUserLanguagePreferenceAsync(int userId, string preferredLanguage, string? secondaryLanguage = null)
    {
        try
        {
            var preference = await _context.UserLanguagePreferences.FirstOrDefaultAsync(p => p.UserId == userId);
            
            if (preference == null)
            {
                preference = new UserLanguagePreference
                {
                    UserId = userId,
                    PreferredLanguageCode = preferredLanguage,
                    SecondaryLanguageCode = secondaryLanguage,
                    AutoTranslate = false,
                    ShowOriginalText = true,
                    CreatedAt = DateTime.UtcNow
                };
                _context.UserLanguagePreferences.Add(preference);
            }
            else
            {
                preference.PreferredLanguageCode = preferredLanguage;
                preference.SecondaryLanguageCode = secondaryLanguage;
                preference.UpdatedAt = DateTime.UtcNow;
                _context.UserLanguagePreferences.Update(preference);
            }

            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error setting language preference for user {UserId}", userId);
            return false;
        }
    }

    public async Task<UserLanguagePreference?> GetUserLanguagePreferenceAsync(int userId)
    {
        return await _context.UserLanguagePreferences.FirstOrDefaultAsync(p => p.UserId == userId);
    }

    public async Task<string?> GetTranslationFromCacheAsync(string text, string sourceLanguage, string targetLanguage)
    {
        var cached = await _context.TranslationCache
            .FirstOrDefaultAsync(tc =>
                tc.SourceText == text &&
                tc.SourceLanguage == sourceLanguage &&
                tc.TargetLanguage == targetLanguage);

        if (cached != null)
        {
            cached.AccessCount++;
            cached.LastAccessedAt = DateTime.UtcNow;
            _context.TranslationCache.Update(cached);
            await _context.SaveChangesAsync();
            return cached.TranslatedText;
        }

        return null;
    }

    public async Task<bool> CacheTranslationAsync(string text, string sourceLanguage, string targetLanguage, string translatedText, double confidenceScore)
    {
        try
        {
            var cache = new TranslationCache
            {
                SourceText = text,
                SourceLanguage = sourceLanguage,
                TargetLanguage = targetLanguage,
                TranslatedText = translatedText,
                TranslationProvider = _configuration["Translation:Provider"] ?? "google",
                ConfidenceScore = confidenceScore,
                CreatedAt = DateTime.UtcNow,
                AccessCount = 1
            };

            _context.TranslationCache.Add(cache);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error caching translation");
            return false;
        }
    }

    private async Task<(bool, string, string?)> TranslateWithGoogleAsync(string text, string sourceLanguage, string targetLanguage)
    {
        try
        {
            var apiKey = _configuration["Translation:GoogleApiKey"];
            if (string.IsNullOrEmpty(apiKey))
                return (false, string.Empty, "Google API key not configured");

            var client = _httpClientFactory.CreateClient();
            var url = $"https://translation.googleapis.com/language/translate/v2?key={apiKey}";
            
            var payload = new
            {
                q = text,
                source_language = sourceLanguage,
                target_language = targetLanguage
            };

            var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
            };

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(content);
                var translatedText = doc.RootElement
                    .GetProperty("data")
                    .GetProperty("translations")[0]
                    .GetProperty("translatedText")
                    .GetString();

                return (true, translatedText ?? string.Empty, null);
            }

            return (false, string.Empty, "Google Translate API error");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Google translation error");
            return (false, string.Empty, ex.Message);
        }
    }

    private async Task<(bool, string, string?)> TranslateWithAzureAsync(string text, string sourceLanguage, string targetLanguage)
    {
        try
        {
            var apiKey = _configuration["Translation:AzureApiKey"];
            var region = _configuration["Translation:AzureRegion"] ?? "global";

            if (string.IsNullOrEmpty(apiKey))
                return (false, string.Empty, "Azure Translator API key not configured");

            var client = _httpClientFactory.CreateClient();
            var url = $"https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&from={sourceLanguage}&to={targetLanguage}";

            var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = new StringContent($"[{{\"Text\":\"{text}\"}}]", System.Text.Encoding.UTF8, "application/json")
            };

            request.Headers.Add("Ocp-Apim-Subscription-Key", apiKey);
            request.Headers.Add("Ocp-Apim-Subscription-Region", region);

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(content);
                var translatedText = doc.RootElement[0]
                    .GetProperty("translations")[0]
                    .GetProperty("text")
                    .GetString();

                return (true, translatedText ?? string.Empty, null);
            }

            return (false, string.Empty, "Azure Translator API error");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Azure translation error");
            return (false, string.Empty, ex.Message);
        }
    }
}
