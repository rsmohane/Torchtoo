namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface IGeolocationService
{
    Task<(bool success, GeolocationData? data, string? error)> GetGeolocationByIpAsync(string ipAddress);
    Task<(bool success, GeolocationData? data, string? error)> GetGeolocationByCoordinatesAsync(double latitude, double longitude);
    Task<(bool success, string? timezone, string? error)> GetTimezoneAsync(double latitude, double longitude);
    Task<(bool success, bool isAllowed, string? error)> CheckGeolocationPermissionAsync(int userId);
    Task<bool> SetGeolocationPreferenceAsync(int userId, bool allowTracking, List<string>? allowedCountries = null);
    Task<List<UserLocation>> GetUserLocationHistoryAsync(int userId, int limit = 50);
    Task<bool> LogLocationAccessAsync(int userId, double latitude, double longitude, string action);
}

public class GeolocationService : IGeolocationService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<GeolocationService> _logger;

    public GeolocationService(
        ApplicationDbContext context,
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<GeolocationService> logger)
    {
        _context = context;
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, GeolocationData? data, string? error)> GetGeolocationByIpAsync(string ipAddress)
    {
        try
        {
            // Using IP Geolocation API (free tier available at ip-api.com)
            var client = _httpClientFactory.CreateClient();
            var url = $"http://ip-api.com/json/{ipAddress}?fields=status,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org";

            var response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var element = doc.RootElement;
                    if (element.GetProperty("status").GetString() == "success")
                    {
                        var geoData = new GeolocationData
                        {
                            IpAddress = ipAddress,
                            Country = element.GetProperty("country").GetString(),
                            CountryCode = element.GetProperty("countryCode").GetString(),
                            Region = element.GetProperty("regionName").GetString(),
                            City = element.GetProperty("city").GetString(),
                            Latitude = element.GetProperty("lat").GetDouble(),
                            Longitude = element.GetProperty("lon").GetDouble(),
                            Timezone = element.GetProperty("timezone").GetString(),
                            ISP = element.TryGetProperty("isp", out var isp) ? isp.GetString() : null,
                            Organization = element.TryGetProperty("org", out var org) ? org.GetString() : null,
                            RequestedAt = DateTime.UtcNow
                        };

                        _logger.LogInformation("Geolocation retrieved for IP {IpAddress}: {City}, {Country}", ipAddress, geoData.City, geoData.Country);
                        return (true, geoData, null);
                    }
                }
            }

            return (false, null, "Failed to retrieve geolocation data");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Geolocation lookup error for IP {IpAddress}", ipAddress);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, GeolocationData? data, string? error)> GetGeolocationByCoordinatesAsync(double latitude, double longitude)
    {
        try
        {
            // Reverse geocoding: convert coordinates to address
            var client = _httpClientFactory.CreateClient();
            var url = $"https://nominatim.openstreetmap.org/reverse?format=json&lat={latitude}&lon={longitude}";

            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("User-Agent", "HumanAssist");

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var element = doc.RootElement;
                    var address = element.TryGetProperty("address", out var addr) ? addr : element;

                    var geoData = new GeolocationData
                    {
                        Latitude = latitude,
                        Longitude = longitude,
                        Country = address.TryGetProperty("country", out var country) ? country.GetString() : null,
                        CountryCode = address.TryGetProperty("country_code", out var cc) ? cc.GetString()?.ToUpper() : null,
                        City = address.TryGetProperty("city", out var city) ? city.GetString() : address.TryGetProperty("town", out var town) ? town.GetString() : null,
                        Region = address.TryGetProperty("state", out var state) ? state.GetString() : null,
                        RequestedAt = DateTime.UtcNow
                    };

                    _logger.LogInformation("Reverse geolocation retrieved for coordinates {Lat},{Lon}: {City}", latitude, longitude, geoData.City);
                    return (true, geoData, null);
                }
            }

            return (false, null, "Failed to retrieve location from coordinates");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Reverse geolocation error for coordinates {Lat},{Lon}", latitude, longitude);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string? timezone, string? error)> GetTimezoneAsync(double latitude, double longitude)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            var url = $"https://maps.googleapis.com/maps/api/timezone/json?location={latitude},{longitude}&timestamp={(long)DateTime.UtcNow.Subtract(DateTime.UnixEpoch).TotalSeconds}&key={_configuration["GoogleMaps:ApiKey"]}";

            var response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    if (doc.RootElement.GetProperty("status").GetString() == "OK")
                    {
                        var timezone = doc.RootElement.GetProperty("timeZoneId").GetString();
                        _logger.LogInformation("Timezone retrieved: {Timezone}", timezone);
                        return (true, timezone, null);
                    }
                }
            }

            return (false, null, "Failed to retrieve timezone");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Timezone lookup error");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, bool isAllowed, string? error)> CheckGeolocationPermissionAsync(int userId)
    {
        try
        {
            var pref = await _context.UserGeolocationPreferences
                .FirstOrDefaultAsync(p => p.UserId == userId);

            if (pref == null)
            {
                return (true, false, null); // Default: no permission
            }

            return (true, pref.AllowTracking, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking geolocation permission for user {UserId}", userId);
            return (false, false, ex.Message);
        }
    }

    public async Task<bool> SetGeolocationPreferenceAsync(int userId, bool allowTracking, List<string>? allowedCountries = null)
    {
        try
        {
            var pref = await _context.UserGeolocationPreferences
                .FirstOrDefaultAsync(p => p.UserId == userId);

            if (pref == null)
            {
                pref = new UserGeolocationPreference
                {
                    UserId = userId,
                    AllowTracking = allowTracking,
                    AllowedCountries = allowedCountries != null ? string.Join(",", allowedCountries) : null,
                    SetAt = DateTime.UtcNow
                };
                _context.UserGeolocationPreferences.Add(pref);
            }
            else
            {
                pref.AllowTracking = allowTracking;
                pref.AllowedCountries = allowedCountries != null ? string.Join(",", allowedCountries) : null;
                pref.SetAt = DateTime.UtcNow;
                _context.UserGeolocationPreferences.Update(pref);
            }

            await _context.SaveChangesAsync();
            _logger.LogInformation("Geolocation preference saved for user {UserId}", userId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error setting geolocation preference for user {UserId}", userId);
            return false;
        }
    }

    public async Task<List<UserLocation>> GetUserLocationHistoryAsync(int userId, int limit = 50)
    {
        try
        {
            return await _context.UserLocations
                .Where(l => l.UserId == userId)
                .OrderByDescending(l => l.RecordedAt)
                .Take(limit)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving location history for user {UserId}", userId);
            return new List<UserLocation>();
        }
    }

    public async Task<bool> LogLocationAccessAsync(int userId, double latitude, double longitude, string action)
    {
        try
        {
            // Check permission first
            var (permSuccess, isAllowed, _) = await CheckGeolocationPermissionAsync(userId);
            if (!permSuccess || !isAllowed)
            {
                _logger.LogWarning("Location access denied for user {UserId}", userId);
                return false;
            }

            var location = new UserLocation
            {
                UserId = userId,
                Latitude = latitude,
                Longitude = longitude,
                Action = action,
                RecordedAt = DateTime.UtcNow
            };

            _context.UserLocations.Add(location);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Location logged for user {UserId}: {Action}", userId, action);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging location for user {UserId}", userId);
            return false;
        }
    }
}
