namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

public interface IInstructionService
{
    Task<List<Instruction>> GetPublicInstructionsAsync();
    Task<List<Instruction>> GetUserInstructionsAsync(int userId);
    Task<Instruction?> GetInstructionAsync(int instructionId);
    Task<Instruction> CreateInstructionAsync(Instruction instruction);
    Task<bool> UpdateInstructionAsync(Instruction instruction);
    Task<bool> DeleteInstructionAsync(int instructionId, int userId);
    Task<InstructionExecution> ExecuteInstructionAsync(int instructionId, string input, int userId);
    Task<List<InstructionExecution>> GetInstructionExecutionsAsync(int instructionId);
}

public class InstructionService : IInstructionService
{
    private readonly ApplicationDbContext _context;
    private readonly IAIService _aiService;
    private readonly ILogger<InstructionService> _logger;

    public InstructionService(
        ApplicationDbContext context,
        IAIService aiService,
        ILogger<InstructionService> logger)
    {
        _context = context;
        _aiService = aiService;
        _logger = logger;
    }

    public async Task<List<Instruction>> GetPublicInstructionsAsync()
    {
        return await _context.Instructions
            .Where(i => i.IsPublic)
            .Include(i => i.CreatedBy)
            .OrderByDescending(i => i.ExecutionCount)
            .ToListAsync();
    }

    public async Task<List<Instruction>> GetUserInstructionsAsync(int userId)
    {
        return await _context.Instructions
            .Where(i => i.CreatedByUserId == userId)
            .Include(i => i.Executions)
            .OrderByDescending(i => i.CreatedAt)
            .ToListAsync();
    }

    public async Task<Instruction?> GetInstructionAsync(int instructionId)
    {
        return await _context.Instructions
            .Include(i => i.CreatedBy)
            .Include(i => i.Executions)
            .FirstOrDefaultAsync(i => i.Id == instructionId);
    }

    public async Task<Instruction> CreateInstructionAsync(Instruction instruction)
    {
        instruction.CreatedAt = DateTime.UtcNow;
        _context.Instructions.Add(instruction);
        await _context.SaveChangesAsync();
        _logger.LogInformation("Instruction {InstructionId} created by user {UserId}", instruction.Id, instruction.CreatedByUserId);
        return instruction;
    }

    public async Task<bool> UpdateInstructionAsync(Instruction instruction)
    {
        try
        {
            instruction.UpdatedAt = DateTime.UtcNow;
            _context.Instructions.Update(instruction);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Instruction update error");
            return false;
        }
    }

    public async Task<bool> DeleteInstructionAsync(int instructionId, int userId)
    {
        try
        {
            var instruction = await _context.Instructions.FirstOrDefaultAsync(i => i.Id == instructionId && i.CreatedByUserId == userId);
            if (instruction == null)
                return false;

            _context.Instructions.Remove(instruction);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Instruction deletion error");
            return false;
        }
    }

    public async Task<InstructionExecution> ExecuteInstructionAsync(int instructionId, string input, int userId)
    {
        var execution = new InstructionExecution
        {
            InstructionId = instructionId,
            ExecutedByUserId = userId,
            Input = input,
            Status = "Processing",
            CreatedAt = DateTime.UtcNow
        };

        try
        {
            var instruction = await _context.Instructions.FirstOrDefaultAsync(i => i.Id == instructionId);
            if (instruction == null)
            {
                execution.Status = "Failed";
                execution.Log = "Instruction not found";
                return execution;
            }

            var startTime = DateTime.UtcNow;

            // Execute the instruction through AI
            var prompt = $"Execute instruction: {instruction.Content}\nInput: {input}";
            var (success, output, error) = await _aiService.GenerateResponseAsync(prompt, userId);

            execution.ExecutionTimeMs = (int)(DateTime.UtcNow - startTime).TotalMilliseconds;

            if (success)
            {
                execution.Output = output;
                execution.Status = "Completed";
                instruction.ExecutionCount++;
            }
            else
            {
                execution.Status = "Failed";
                execution.Log = error;
            }

            _context.InstructionExecutions.Add(execution);
            _context.Instructions.Update(instruction);
            await _context.SaveChangesAsync();

            return execution;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Instruction execution error");
            execution.Status = "Failed";
            execution.Log = ex.Message;
            _context.InstructionExecutions.Add(execution);
            await _context.SaveChangesAsync();
            return execution;
        }
    }

    public async Task<List<InstructionExecution>> GetInstructionExecutionsAsync(int instructionId)
    {
        return await _context.InstructionExecutions
            .Where(ie => ie.InstructionId == instructionId)
            .Include(ie => ie.ExecutedBy)
            .OrderByDescending(ie => ie.CreatedAt)
            .ToListAsync();
    }
}
