namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using EnvConfig = HumanAssist.Models.EnvironmentConfig;
using Microsoft.EntityFrameworkCore;

public interface IMultiEnvironmentConfigurationService
{
    Task<(bool success, EnvConfig? config, string? error)> GetEnvironmentConfigAsync(string environmentName, int userId);
    Task<(bool success, string? error)> CreateEnvironmentConfigAsync(EnvConfig config, int userId);
    Task<(bool success, string? error)> UpdateEnvironmentConfigAsync(EnvConfig config, int userId);
    Task<(bool success, string? error)> DeleteEnvironmentConfigAsync(string environmentName, int userId);
    Task<List<EnvConfig>> ListEnvironmentConfigsAsync(int userId);
    Task<(bool success, string? error)> SwitchEnvironmentAsync(int userId, string fromEnvironment, string toEnvironment);
    Task<(bool success, Dictionary<string, object> differences, string? error)> CompareEnvironmentsAsync(string env1, string env2, int userId);
    Task<(bool success, string? error)> CloneEnvironmentAsync(string sourceEnvironment, string targetEnvironment, int userId);
    Task<(bool success, EnvironmentStatus status, string? error)> GetEnvironmentStatusAsync(string environmentName, int userId);
    Task<List<EnvironmentAuditLog>> GetEnvironmentChangeHistoryAsync(string environmentName, int userId, int limit = 100);
}

public class MultiEnvironmentConfigurationService : IMultiEnvironmentConfigurationService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<MultiEnvironmentConfigurationService> _logger;
    private readonly IConfiguration _configuration;

    public MultiEnvironmentConfigurationService(
        ApplicationDbContext context,
        ILogger<MultiEnvironmentConfigurationService> logger,
        IConfiguration configuration)
    {
        _context = context;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<(bool success, EnvConfig? config, string? error)> GetEnvironmentConfigAsync(string environmentName, int userId)
    {
        try
        {
            var config = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == environmentName && e.UserId == userId);

            if (config == null)
                return (false, null, $"Environment '{environmentName}' not found");

            _logger.LogInformation("Retrieved environment config for user {UserId}: {Environment}", userId, environmentName);
            return (true, config, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving environment config for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> CreateEnvironmentConfigAsync(EnvConfig config, int userId)
    {
        try
        {
            if (string.IsNullOrEmpty(config.EnvironmentName))
                return (false, "Environment name is required");

            var exists = await _context.EnvironmentConfigs
                .AnyAsync(e => e.EnvironmentName == config.EnvironmentName && e.UserId == userId);

            if (exists)
                return (false, $"Environment '{config.EnvironmentName}' already exists");

            config.UserId = userId;
            config.CreatedAt = DateTime.UtcNow;
            config.LastModifiedAt = DateTime.UtcNow;

            _context.EnvironmentConfigs.Add(config);
            await _context.SaveChangesAsync();

            await LogEnvironmentChangeAsync(userId, config.EnvironmentName, "CREATE", $"Created new environment: {config.EnvironmentName}");

            _logger.LogInformation("Created environment config for user {UserId}: {Environment}", userId, config.EnvironmentName);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating environment config for user {UserId}", userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> UpdateEnvironmentConfigAsync(EnvConfig config, int userId)
    {
        try
        {
            var existing = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == config.EnvironmentName && e.UserId == userId);

            if (existing == null)
                return (false, $"Environment '{config.EnvironmentName}' not found");

            existing.DatabaseConnectionString = config.DatabaseConnectionString;
            existing.ApiBaseUrl = config.ApiBaseUrl;
            existing.LogLevel = config.LogLevel;
            existing.EnableDebugMode = config.EnableDebugMode;
            existing.MaxConnections = config.MaxConnections;
            existing.RequestTimeout = config.RequestTimeout;
            existing.CacheEnabled = config.CacheEnabled;
            existing.CacheDuration = config.CacheDuration;
            existing.Variables = config.Variables;
            existing.LastModifiedAt = DateTime.UtcNow;

            _context.EnvironmentConfigs.Update(existing);
            await _context.SaveChangesAsync();

            await LogEnvironmentChangeAsync(userId, config.EnvironmentName, "UPDATE", $"Updated environment configuration");

            _logger.LogInformation("Updated environment config for user {UserId}: {Environment}", userId, config.EnvironmentName);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating environment config for user {UserId}", userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> DeleteEnvironmentConfigAsync(string environmentName, int userId)
    {
        try
        {
            var config = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == environmentName && e.UserId == userId);

            if (config == null)
                return (false, $"Environment '{environmentName}' not found");

            _context.EnvironmentConfigs.Remove(config);
            await _context.SaveChangesAsync();

            await LogEnvironmentChangeAsync(userId, environmentName, "DELETE", $"Deleted environment: {environmentName}");

            _logger.LogInformation("Deleted environment config for user {UserId}: {Environment}", userId, environmentName);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting environment config for user {UserId}", userId);
            return (false, ex.Message);
        }
    }

    public async Task<List<EnvConfig>> ListEnvironmentConfigsAsync(int userId)
    {
        try
        {
            return await _context.EnvironmentConfigs
                .Where(e => e.UserId == userId)
                .OrderBy(e => e.EnvironmentName)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing environment configs for user {UserId}", userId);
            return new List<EnvConfig>();
        }
    }

    public async Task<(bool success, string? error)> SwitchEnvironmentAsync(int userId, string fromEnvironment, string toEnvironment)
    {
        try
        {
            var fromEnv = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == fromEnvironment && e.UserId == userId);
            
            var toEnv = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == toEnvironment && e.UserId == userId);

            if (fromEnv == null || toEnv == null)
                return (false, "Source or destination environment not found");

            await LogEnvironmentChangeAsync(userId, toEnvironment, "SWITCH", $"Switched from {fromEnvironment} to {toEnvironment}");

            _logger.LogInformation("Switched environment for user {UserId}: {From} -> {To}", userId, fromEnvironment, toEnvironment);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error switching environments for user {UserId}", userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, Dictionary<string, object> differences, string? error)> CompareEnvironmentsAsync(string env1, string env2, int userId)
    {
        try
        {
            var config1 = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == env1 && e.UserId == userId);
            
            var config2 = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == env2 && e.UserId == userId);

            if (config1 == null || config2 == null)
                return (false, new Dictionary<string, object>(), "One or both environments not found");

            var differences = new Dictionary<string, object>
            {
                { "DatabaseConnection", new { env1 = config1.DatabaseConnectionString, env2 = config2.DatabaseConnectionString } },
                { "ApiBaseUrl", new { env1 = config1.ApiBaseUrl, env2 = config2.ApiBaseUrl } },
                { "LogLevel", new { env1 = config1.LogLevel, env2 = config2.LogLevel } },
                { "DebugMode", new { env1 = config1.EnableDebugMode, env2 = config2.EnableDebugMode } },
                { "MaxConnections", new { env1 = config1.MaxConnections, env2 = config2.MaxConnections } },
                { "RequestTimeout", new { env1 = config1.RequestTimeout, env2 = config2.RequestTimeout } },
                { "CacheEnabled", new { env1 = config1.CacheEnabled, env2 = config2.CacheEnabled } },
                { "CacheDuration", new { env1 = config1.CacheDuration, env2 = config2.CacheDuration } }
            };

            _logger.LogInformation("Compared environments for user {UserId}: {Env1} vs {Env2}", userId, env1, env2);
            return (true, differences, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error comparing environments for user {UserId}", userId);
            return (false, new Dictionary<string, object>(), ex.Message);
        }
    }

    public async Task<(bool success, string? error)> CloneEnvironmentAsync(string sourceEnvironment, string targetEnvironment, int userId)
    {
        try
        {
            var source = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == sourceEnvironment && e.UserId == userId);

            if (source == null)
                return (false, "Source environment not found");

            var clone = new EnvConfig
            {
                UserId = userId,
                EnvironmentName = targetEnvironment,
                EnvironmentType = source.EnvironmentType,
                DatabaseConnectionString = source.DatabaseConnectionString,
                ApiBaseUrl = source.ApiBaseUrl,
                LogLevel = source.LogLevel,
                EnableDebugMode = source.EnableDebugMode,
                MaxConnections = source.MaxConnections,
                RequestTimeout = source.RequestTimeout,
                CacheEnabled = source.CacheEnabled,
                CacheDuration = source.CacheDuration,
                Variables = source.Variables,
                CreatedAt = DateTime.UtcNow,
                LastModifiedAt = DateTime.UtcNow
            };

            _context.EnvironmentConfigs.Add(clone);
            await _context.SaveChangesAsync();

            await LogEnvironmentChangeAsync(userId, targetEnvironment, "CLONE", $"Cloned from {sourceEnvironment}");

            _logger.LogInformation("Cloned environment for user {UserId}: {Source} -> {Target}", userId, sourceEnvironment, targetEnvironment);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error cloning environment for user {UserId}", userId);
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, EnvironmentStatus status, string? error)> GetEnvironmentStatusAsync(string environmentName, int userId)
    {
        try
        {
            var config = await _context.EnvironmentConfigs
                .FirstOrDefaultAsync(e => e.EnvironmentName == environmentName && e.UserId == userId);

            if (config == null)
                return (false, null, "Environment not found");

            var status = new EnvironmentStatus
            {
                EnvironmentName = environmentName,
                IsActive = true,
                LastHealthCheck = DateTime.UtcNow,
                DatabaseSecure = !string.IsNullOrEmpty(config.DatabaseConnectionString),
                ConfigurationValid = ValidateConfiguration(config),
                MetricsAvailable = true,
                CreatedAt = config.CreatedAt,
                LastModified = config.LastModifiedAt,
                UpTime = DateTime.UtcNow - config.CreatedAt
            };

            _logger.LogInformation("Retrieved status for environment {Environment}", environmentName);
            return (true, status, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting environment status for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<List<EnvironmentAuditLog>> GetEnvironmentChangeHistoryAsync(string environmentName, int userId, int limit = 100)
    {
        try
        {
            return await _context.EnvironmentAuditLogs
                .Where(l => l.EnvironmentName == environmentName && l.UserId == userId)
                .OrderByDescending(l => l.ChangedAt)
                .Take(limit)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving change history for user {UserId}", userId);
            return new List<EnvironmentAuditLog>();
        }
    }

    private bool ValidateConfiguration(EnvConfig config)
    {
        return !string.IsNullOrEmpty(config.EnvironmentName) &&
               !string.IsNullOrEmpty(config.DatabaseConnectionString) &&
               !string.IsNullOrEmpty(config.ApiBaseUrl);
    }

    private async Task<bool> LogEnvironmentChangeAsync(int userId, string environmentName, string action, string details)
    {
        try
        {
            var log = new EnvironmentAuditLog
            {
                UserId = userId,
                EnvironmentName = environmentName,
                Action = action,
                Details = details,
                ChangedAt = DateTime.UtcNow
            };

            _context.EnvironmentAuditLogs.Add(log);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging environment change for user {UserId}", userId);
            return false;
        }
    }
}

public class EnvironmentStatus
{
    public string EnvironmentName { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateTime LastHealthCheck { get; set; }
    public bool DatabaseSecure { get; set; }
    public bool ConfigurationValid { get; set; }
    public bool MetricsAvailable { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime LastModified { get; set; }
    public TimeSpan UpTime { get; set; }
}
