namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Net.Http;

public interface IAIService
{
    Task<(bool success, string response, string? error)> AnalyzeTextAsync(string text, string analysisType);
    Task<(bool success, string response, string? error)> GenerateResponseAsync(string prompt, int userId);
    Task<(bool success, string response, string? error)> ExecuteToolAsync(int toolId, string input, int userId);
    Task<List<string>> GetAvailableToolsAsync();
    Task<bool> RegisterToolAsync(AITool tool);
}

public class AIService : IAIService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IEncryptionService _encryptionService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<AIService> _logger;

    public AIService(
        ApplicationDbContext context,
        IHttpClientFactory httpClientFactory,
        IEncryptionService encryptionService,
        IConfiguration configuration,
        ILogger<AIService> logger)
    {
        _context = context;
        _httpClientFactory = httpClientFactory;
        _encryptionService = encryptionService;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, string response, string? error)> AnalyzeTextAsync(string text, string analysisType)
    {
        try
        {
            // This would integrate with OpenAI or your chosen AI provider
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, string.Empty, "OpenAI API key not configured");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var payload = new
            {
                model = "gpt-4",
                messages = new[]
                {
                    new { role = "system", content = $"You are an expert assistant analyzing text for {analysisType}." },
                    new { role = "user", content = text }
                },
                max_tokens = 2000,
                temperature = 0.7
            };

            request.Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json");

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var result = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                    return (true, result ?? string.Empty, null);
                }
            }

            return (false, string.Empty, "AI request failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "AI analysis error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string response, string? error)> GenerateResponseAsync(string prompt, int userId)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, string.Empty, "OpenAI API key not configured");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var payload = new
            {
                model = "gpt-4",
                messages = new[]
                {
                    new { role = "system", content = "You are a helpful AI assistant providing detailed, professional responses." },
                    new { role = "user", content = prompt }
                },
                max_tokens = 3000,
                temperature = 0.8
            };

            request.Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json");

            var startTime = DateTime.UtcNow;
            var response = await client.SendAsync(request);
            var elapsed = (int)(DateTime.UtcNow - startTime).TotalMilliseconds;

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var result = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                    
                    // Log the usage
                    var tool = await _context.AITools.FirstOrDefaultAsync(t => t.Name == "OpenAI");
                    if (tool != null)
                    {
                        var usageLog = new ToolUsageLog
                        {
                            UserId = userId,
                            ToolId = tool.Id,
                            InputData = prompt,
                            OutputData = result ?? string.Empty,
                            ResponseTimeMs = elapsed,
                            Success = true,
                            CreatedAt = DateTime.UtcNow
                        };
                        _context.ToolUsageLogs.Add(usageLog);
                        await _context.SaveChangesAsync();
                    }

                    return (true, result ?? string.Empty, null);
                }
            }

            return (false, string.Empty, "AI request failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "AI generation error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string response, string? error)> ExecuteToolAsync(int toolId, string input, int userId)
    {
        try
        {
            var tool = await _context.AITools.FirstOrDefaultAsync(t => t.Id == toolId && t.IsEnabled);
            if (tool == null)
                return (false, string.Empty, "Tool not found or disabled");

            // Check rate limit
            var today = DateTime.UtcNow.Date;
            var usageToday = await _context.ToolUsageLogs
                .Where(t => t.ToolId == toolId && t.CreatedAt.Date == today && t.UserId == userId)
                .CountAsync();

            if (usageToday >= tool.RateLimitPerDay)
                return (false, string.Empty, "Rate limit exceeded");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, tool.ApiEndpoint);

            // Decrypt API key
            var apiKey = _encryptionService.Decrypt(tool.ApiKeyEncrypted);
            request.Headers.Add("Authorization", $"Bearer {apiKey}");

            request.Content = new StringContent(JsonSerializer.Serialize(new { input }), System.Text.Encoding.UTF8, "application/json");

            var startTime = DateTime.UtcNow;
            var response = await client.SendAsync(request);
            var elapsed = (int)(DateTime.UtcNow - startTime).TotalMilliseconds;

            var usageLog = new ToolUsageLog
            {
                UserId = userId,
                ToolId = toolId,
                InputData = input,
                ResponseTimeMs = elapsed,
                Success = response.IsSuccessStatusCode,
                CreatedAt = DateTime.UtcNow
            };

            if (response.IsSuccessStatusCode)
            {
                usageLog.OutputData = await response.Content.ReadAsStringAsync();
                _context.ToolUsageLogs.Add(usageLog);
                await _context.SaveChangesAsync();
                return (true, usageLog.OutputData, null);
            }

            usageLog.ErrorMessage = "Tool execution failed";
            _context.ToolUsageLogs.Add(usageLog);
            await _context.SaveChangesAsync();
            return (false, string.Empty, "Tool execution failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Tool execution error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<List<string>> GetAvailableToolsAsync()
    {
        return await _context.AITools
            .Where(t => t.IsEnabled)
            .Select(t => t.Name)
            .ToListAsync();
    }

    public async Task<bool> RegisterToolAsync(AITool tool)
    {
        try
        {
            tool.CreatedAt = DateTime.UtcNow;
            _context.AITools.Add(tool);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Tool {ToolName} registered", tool.Name);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Tool registration error");
            return false;
        }
    }
}
