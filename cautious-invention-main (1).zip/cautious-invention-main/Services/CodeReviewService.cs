namespace HumanAssist.Services;

using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;

public interface ICodeReviewService
{
    Task<(bool success, CodeAnalysisResult? analysis, string? error)> AnalyzeCodeAsync(string code, string language);
    Task<(bool success, CodeReviewFeedback? feedback, string? error)> ReviewCodeAsync(string code, string language, string description);
    Task<(bool success, CodeQualityMetrics? metrics, string? error)> CalculateCodeMetricsAsync(string code, string language);
    Task<(bool success, List<SecurityIssue>? issues, string? error)> DetectSecurityIssuesAsync(string code, string language);
    Task<(bool success, List<string> suggestions, string? error)> SuggestImprovementsAsync(string code, string language);
}

public class CodeReviewService : ICodeReviewService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<CodeReviewService> _logger;
    private readonly IConfiguration _configuration;

    public CodeReviewService(
        IHttpClientFactory httpClientFactory,
        ILogger<CodeReviewService> logger,
        IConfiguration configuration)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<(bool success, CodeAnalysisResult? analysis, string? error)> AnalyzeCodeAsync(string code, string language)
    {
        try
        {
            var apiKey = _configuration["OpenAi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var prompt = $@"Analyze this {language} code and provide a detailed analysis:

{code}

Please provide:
1. Code quality score (0-100)
2. Complexity level
3. Maintainability assessment
4. Performance considerations
5. Best practices compliance

Format as JSON.";

            var request = new
            {
                model = "gpt-4",
                messages = new[] { new { role = "user", content = prompt } },
                temperature = 0.7,
                max_tokens = 1000
            };

            var content = new StringContent(
                JsonSerializer.Serialize(request),
                Encoding.UTF8,
                "application/json");

            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");

            var response = await client.PostAsync("https://api.openai.com/v1/chat/completions", content);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"OpenAI API error: {response.StatusCode}");

            var responseContent = await response.Content.ReadAsStringAsync();
            var jsonResponse = JsonSerializer.Deserialize<JsonElement>(responseContent);
            var analysisText = jsonResponse.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();

            var analysis = new CodeAnalysisResult
            {
                Language = language,
                Analysis = analysisText ?? "",
                AnalyzedAt = DateTime.UtcNow,
                CodeLength = code.Length
            };

            _logger.LogInformation("Analyzed {Language} code, length: {Length}", language, code.Length);
            return (true, analysis, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error analyzing code");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, CodeReviewFeedback? feedback, string? error)> ReviewCodeAsync(string code, string language, string description)
    {
        try
        {
            var apiKey = _configuration["OpenAi:ApiKey"];
            var client = _httpClientFactory.CreateClient();

            var prompt = $@"Review this {language} code for a {description}:

{code}

Provide a comprehensive code review including:
1. Issues found
2. Suggestions for improvement
3. Security concerns
4. Performance optimization opportunities
5. Code style and best practices

Format as JSON with sections for issues, suggestions, and improvements.";

            var request = new
            {
                model = "gpt-4",
                messages = new[] { new { role = "user", content = prompt } },
                temperature = 0.7,
                max_tokens = 2000
            };

            var content = new StringContent(
                JsonSerializer.Serialize(request),
                Encoding.UTF8,
                "application/json");

            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");

            var response = await client.PostAsync("https://api.openai.com/v1/chat/completions", content);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"OpenAI API error: {response.StatusCode}");

            var responseContent = await response.Content.ReadAsStringAsync();
            var jsonResponse = JsonSerializer.Deserialize<JsonElement>(responseContent);
            var reviewText = jsonResponse.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();

            var feedback = new CodeReviewFeedback
            {
                Language = language,
                ReviewNotes = reviewText ?? "",
                ReviewedAt = DateTime.UtcNow,
                Reviewer = "AI Expert System"
            };

            _logger.LogInformation("Reviewed {Language} code: {Description}", language, description);
            return (true, feedback, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reviewing code");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, CodeQualityMetrics? metrics, string? error)> CalculateCodeMetricsAsync(string code, string language)
    {
        try
        {
            var lines = code.Split('\n');
            var codeLines = lines.Where(l => !string.IsNullOrWhiteSpace(l) && !l.TrimStart().StartsWith("//")).Count();
            var commentLines = lines.Where(l => l.TrimStart().StartsWith("//") || l.TrimStart().StartsWith("*")).Count();
            var complexity = CalculateCyclomaticComplexity(code);

            var metrics = new CodeQualityMetrics
            {
                Language = language,
                TotalLines = lines.Length,
                CodeLines = codeLines,
                CommentLines = commentLines,
                BlankLines = lines.Count(l => string.IsNullOrWhiteSpace(l)),
                CyclomaticComplexity = complexity,
                CommentRatio = commentLines > 0 ? (double)commentLines / codeLines : 0,
                CalculatedAt = DateTime.UtcNow
            };

            _logger.LogInformation("Calculated metrics for {Language} code", language);
            return (true, metrics, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calculating code metrics");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<SecurityIssue>? issues, string? error)> DetectSecurityIssuesAsync(string code, string language)
    {
        try
        {
            var issues = new List<SecurityIssue>();

            // Basic pattern detection for common security issues
            if (code.Contains("eval(") || code.Contains("exec("))
                issues.Add(new SecurityIssue { Severity = "Critical", Type = "Code Injection", Description = "Use of eval() or exec() detected" });

            if (code.Contains("hardcoded password") || code.Contains("api_key =") || code.Contains("secret ="))
                issues.Add(new SecurityIssue { Severity = "Critical", Type = "Credential Exposure", Description = "Hardcoded credentials detected" });

            if (code.Contains("sql ") && !code.Contains("parameterized"))
                issues.Add(new SecurityIssue { Severity = "High", Type = "SQL Injection", Description = "Potential SQL injection vulnerability" });

            if (code.Contains("os.system") || code.Contains("subprocess") && !code.Contains("shlex.quote"))
                issues.Add(new SecurityIssue { Severity = "High", Type = "Command Injection", Description = "Unsafe system command execution" });

            if (!code.Contains("try") || !code.Contains("catch") && !code.Contains("except"))
                issues.Add(new SecurityIssue { Severity = "Medium", Type = "Error Handling", Description = "Inadequate error handling" });

            _logger.LogInformation("Detected {Count} security issues in {Language} code", issues.Count, language);
            return (true, issues, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error detecting security issues");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<string> suggestions, string? error)> SuggestImprovementsAsync(string code, string language)
    {
        try
        {
            var suggestions = new List<string>();

            // Length-based suggestions
            var lines = code.Split('\n');
            if (lines.Any(l => l.Length > 120))
                suggestions.Add("Consider breaking long lines (>120 chars) for better readability");

            if (code.Length > 1000)
                suggestions.Add("Large functions detected - consider breaking into smaller, focused functions");

            // Pattern-based suggestions
            if (!code.Contains("using ") && !code.Contains("import "))
                suggestions.Add("Ensure all required namespaces/imports are included");

            if (!code.Contains("///") && !code.Contains("\"\"\""))
                suggestions.Add("Add documentation comments to improve code clarity");

            if (code.Contains("var ") && language.Contains("C#"))
                suggestions.Add("Use explicit type declarations instead of 'var' for clarity");

            suggestions.Add("Apply consistent naming conventions (camelCase for variables, PascalCase for classes)");
            suggestions.Add("Extract magic numbers and strings to named constants");

            _logger.LogInformation("Generated {Count} improvement suggestions for {Language}", suggestions.Count, language);
            return (true, suggestions, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error suggesting improvements");
            return (false, null, ex.Message);
        }
    }

    private int CalculateCyclomaticComplexity(string code)
    {
        int complexity = 1;
        var keywords = new[] { "if", "else if", "for", "foreach", "while", "do", "case", "catch", "?", "&&", "||" };

        foreach (var keyword in keywords)
        {
            complexity += code.Split(keyword).Length - 1;
        }

        return complexity;
    }
}

public class CodeAnalysisResult
{
    public string Language { get; set; } = string.Empty;
    public string Analysis { get; set; } = string.Empty;
    public int CodeLength { get; set; }
    public DateTime AnalyzedAt { get; set; }
}

public class CodeReviewFeedback
{
    public string Language { get; set; } = string.Empty;
    public string ReviewNotes { get; set; } = string.Empty;
    public string Reviewer { get; set; } = string.Empty;
    public DateTime ReviewedAt { get; set; }
}

public class CodeQualityMetrics
{
    public string Language { get; set; } = string.Empty;
    public int TotalLines { get; set; }
    public int CodeLines { get; set; }
    public int CommentLines { get; set; }
    public int BlankLines { get; set; }
    public int CyclomaticComplexity { get; set; }
    public double CommentRatio { get; set; }
    public DateTime CalculatedAt { get; set; }
}

public class SecurityIssue
{
    public string Severity { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}
