namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

public interface IApiKeyService
{
    Task<(bool success, string key, string? error)> GenerateApiKeyAsync(int userId, string name, string permissions);
    Task<(bool success, bool valid, string? error)> ValidateApiKeyAsync(string key);
    Task<int?> GetUserIdFromApiKeyAsync(string key);
    Task<bool> RevokeApiKeyAsync(int keyId, int userId);
    Task<List<ApiKey>> GetUserApiKeysAsync(int userId);
}

public class ApiKeyService : IApiKeyService
{
    private readonly ApplicationDbContext _context;
    private readonly IEncryptionService _encryptionService;
    private readonly ILogger<ApiKeyService> _logger;

    public ApiKeyService(
        ApplicationDbContext context,
        IEncryptionService encryptionService,
        ILogger<ApiKeyService> logger)
    {
        _context = context;
        _encryptionService = encryptionService;
        _logger = logger;
    }

    public async Task<(bool success, string key, string? error)> GenerateApiKeyAsync(int userId, string name, string permissions)
    {
        try
        {
            // Verify user exists
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                return (false, string.Empty, "User not found");

            var key = GenerateSecureKey();
            var apiKey = new ApiKey
            {
                UserId = userId,
                Key = _encryptionService.Encrypt(key),
                Name = name,
                Permissions = permissions,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddYears(1)
            };

            _context.ApiKeys.Add(apiKey);
            await _context.SaveChangesAsync();

            _logger.LogInformation("API key {KeyName} generated for user {UserId}", name, userId);
            return (true, key, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API key generation error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, bool valid, string? error)> ValidateApiKeyAsync(string key)
    {
        try
        {
            var apiKeys = await _context.ApiKeys
                .Where(k => k.IsActive && (k.ExpiresAt == null || k.ExpiresAt > DateTime.UtcNow))
                .ToListAsync();

            foreach (var dbKey in apiKeys)
            {
                try
                {
                    var decrypted = _encryptionService.Decrypt(dbKey.Key);
                    if (decrypted == key)
                    {
                        dbKey.LastUsedAt = DateTime.UtcNow;
                        _context.ApiKeys.Update(dbKey);
                        await _context.SaveChangesAsync();
                        return (true, true, null);
                    }
                }
                catch
                {
                    // Continue to next key if decryption fails
                    continue;
                }
            }

            return (true, false, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API key validation error");
            return (false, false, ex.Message);
        }
    }

    public async Task<int?> GetUserIdFromApiKeyAsync(string key)
    {
        try
        {
            var apiKeys = await _context.ApiKeys
                .Where(k => k.IsActive && (k.ExpiresAt == null || k.ExpiresAt > DateTime.UtcNow))
                .ToListAsync();

            foreach (var dbKey in apiKeys)
            {
                try
                {
                    var decrypted = _encryptionService.Decrypt(dbKey.Key);
                    if (decrypted == key)
                        return dbKey.UserId;
                }
                catch
                {
                    continue;
                }
            }

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API key user lookup error");
            return null;
        }
    }

    public async Task<bool> RevokeApiKeyAsync(int keyId, int userId)
    {
        try
        {
            var apiKey = await _context.ApiKeys.FindAsync(keyId);
            if (apiKey == null || apiKey.UserId != userId)
                return false;

            apiKey.IsActive = false;
            _context.ApiKeys.Update(apiKey);
            await _context.SaveChangesAsync();

            _logger.LogInformation("API key {KeyId} revoked by user {UserId}", keyId, userId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API key revocation error");
            return false;
        }
    }

    public async Task<List<ApiKey>> GetUserApiKeysAsync(int userId)
    {
        return await _context.ApiKeys
            .Where(k => k.UserId == userId)
            .Select(k => new ApiKey
            {
                Id = k.Id,
                UserId = k.UserId,
                Key = "***" + (k.Key.Length >= 8 ? k.Key.Substring(k.Key.Length - 8) : k.Key),
                Name = k.Name,
                Permissions = k.Permissions,
                IsActive = k.IsActive,
                CreatedAt = k.CreatedAt,
                ExpiresAt = k.ExpiresAt,
                LastUsedAt = k.LastUsedAt
            })
            .ToListAsync();
    }

    private string GenerateSecureKey()
    {
        const string validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
        var key = new StringBuilder();
        using (var rng = RandomNumberGenerator.Create())
        {
            var _bytes = new byte[64];
            rng.GetBytes(_bytes);
            foreach (byte b in _bytes)
                key.Append(validChars[b % validChars.Length]);
        }
        return key.ToString();
    }
}
