namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface IAdvancedTranslationService
{
    // Text-based translation modes
    Task<(bool success, string translatedText, string? error)> TranslateTextAsync(string text, string sourceLanguage, string targetLanguage, string mode, int userId);
    Task<(bool success, string editedText, string? error)> TranslateAndEditAsync(string text, string sourceLanguage, string targetLanguage, string edits, int userId);
    
    // Speech-based translation modes
    Task<(bool success, string transcribedAndTranslated, string? error)> TranslateSpeechAsync(Stream audioStream, string sourceLanguage, string targetLanguage, int userId);
    Task<(bool success, Stream audioStream, string? error)> SpeakTranslatedTextAsync(string text, string language, string voiceGender = "neutral", int userId = 0);
    
    // Sound replacement with frequency matching
    Task<(bool success, Stream audioStream, string? error)> ReplaceAudioLanguageAsync(Stream audioStream, string sourceLanguage, string targetLanguage, bool preserveFrequency, int userId);
    Task<(bool success, Stream audioStream, string? error)> SyncAudioFrequencyAsync(Stream sourceAudio, Stream targetAudio, int userId);
    
    // Multi-language simultaneous translation
    Task<(bool success, Dictionary<string, string> translations, string? error)> TranslateToMultipleLanguagesAsync(string text, string sourceLanguage, List<string> targetLanguages, int userId);
    
    // Document translation
    Task<(bool success, string translatedContent, string? error)> TranslateDocumentAsync(Stream documentStream, string sourceLanguage, string targetLanguage, int userId);
    
    // Real-time translation session
    Task<(bool success, string sessionId, string? error)> StartTranslationSessionAsync(int userId, string sourceLanguage, string targetLanguage);
    Task<(bool success, string translatedText, string? error)> TranslateInSessionAsync(string sessionId, string text);
    Task<bool> EndTranslationSessionAsync(string sessionId);
    
    // Translation quality metrics
    Task<(bool success, double confidence, string? error)> GetTranslationConfidenceAsync(string sourceText, string translatedText, string language);
    Task<List<TranslationQualityLog>> GetTranslationQualityHistoryAsync(int userId, int limit = 50);
}

public class AdvancedTranslationService : IAdvancedTranslationService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<AdvancedTranslationService> _logger;
    private readonly Dictionary<string, TranslationSession> _activeSessions = new();

    public AdvancedTranslationService(
        ApplicationDbContext context,
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<AdvancedTranslationService> logger)
    {
        _context = context;
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, string translatedText, string? error)> TranslateTextAsync(string text, string sourceLanguage, string targetLanguage, string mode, int userId)
    {
        try
        {
            // Modes: standard, formal, casual, technical, creative, simplified
            var openAiKey = _configuration["OpenAI:ApiKey"];
            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var modeDescription = mode switch
            {
                "formal" => "Provide a formal, professional translation",
                "casual" => "Provide a casual, conversational translation",
                "technical" => "Provide a technical, specialized translation",
                "creative" => "Provide a creative, literary translation",
                "simplified" => "Provide a simplified, easy-to-understand translation",
                _ => "Provide an accurate, natural translation"
            };

            var payload = new
            {
                model = "gpt-4",
                messages = new[]
                {
                    new { role = "system", content = $"You are a professional translator. {modeDescription}." },
                    new { role = "user", content = $"Translate from {sourceLanguage} to {targetLanguage}: {text}" }
                },
                max_tokens = 2000,
                temperature = 0.3
            };

            request.Content = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(payload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var result = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                    await LogTranslationAsync(userId, sourceLanguage, targetLanguage, text, result, mode, 0.95);
                    _logger.LogInformation("Text translated for user {UserId}: {Mode}", userId, mode);
                    return (true, result ?? string.Empty, null);
                }
            }

            return (false, string.Empty, "Translation failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Translation error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string editedText, string? error)> TranslateAndEditAsync(string text, string sourceLanguage, string targetLanguage, string edits, int userId)
    {
        try
        {
            // First translate
            var (translateSuccess, translatedText, translateError) = await TranslateTextAsync(text, sourceLanguage, targetLanguage, "standard", userId);
            if (!translateSuccess)
                return (false, string.Empty, translateError);

            // Then apply edits
            var openAiKey = _configuration["OpenAI:ApiKey"];
            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var payload = new
            {
                model = "gpt-4",
                messages = new[]
                {
                    new { role = "system", content = "You are a professional editor. Apply the requested edits to the provided text." },
                    new { role = "user", content = $"Original translation: {translatedText}\n\nEdits to apply: {edits}" }
                },
                max_tokens = 2000,
                temperature = 0.3
            };

            request.Content = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(payload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var result = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                    await LogTranslationAsync(userId, sourceLanguage, targetLanguage, text, result, "translate_and_edit", 0.92);
                    _logger.LogInformation("Text translated and edited for user {UserId}", userId);
                    return (true, result ?? string.Empty, null);
                }
            }

            return (false, string.Empty, "Edit failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Translate and edit error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string transcribedAndTranslated, string? error)> TranslateSpeechAsync(Stream audioStream, string sourceLanguage, string targetLanguage, int userId)
    {
        try
        {
            // Transcribe audio
            var openAiKey = _configuration["OpenAI:ApiKey"];
            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/audio/transcriptions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            using (var content = new MultipartFormDataContent())
            {
                content.Add(new StreamContent(audioStream), "file", "audio.mp3");
                content.Add(new StringContent("whisper-1"), "model");
                content.Add(new StringContent(sourceLanguage), "language");

                request.Content = content;
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    using (var doc = JsonDocument.Parse(responseContent))
                    {
                        var transcribedText = doc.RootElement.GetProperty("text").GetString();

                        // Now translate it
                        var (success, translated, error) = await TranslateTextAsync(transcribedText, sourceLanguage, targetLanguage, "standard", userId);
                        
                        if (success)
                        {
                            _logger.LogInformation("Speech translated for user {UserId}", userId);
                            return (true, translated, null);
                        }

                        return (false, string.Empty, error);
                    }
                }

                return (false, string.Empty, "Transcription failed");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech translation error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, Stream audioStream, string? error)> SpeakTranslatedTextAsync(string text, string language, string voiceGender = "neutral", int userId = 0)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/audio/speech");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var voiceSelection = voiceGender switch
            {
                "male" => "onyx",
                "female" => "nova",
                "neutral" => "alloy",
                _ => "alloy"
            };

            var payload = new
            {
                model = "tts-1",
                input = text,
                voice = voiceSelection,
                speed = 1.0
            };

            request.Content = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(payload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
            if (response.IsSuccessStatusCode)
            {
                var stream = await response.Content.ReadAsStreamAsync();
                _logger.LogInformation("Speech synthesized for user {UserId}", userId);
                return (true, stream, null);
            }

            return (false, null, "Speech synthesis failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Text-to-speech error for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, Stream audioStream, string? error)> ReplaceAudioLanguageAsync(Stream audioStream, string sourceLanguage, string targetLanguage, bool preserveFrequency, int userId)
    {
        try
        {
            // Transcribe source audio
            var openAiKey = _configuration["OpenAI:ApiKey"];
            var client = _httpClientFactory.CreateClient();
            
            // Step 1: Transcribe
            var transcribeRequest = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/audio/transcriptions");
            transcribeRequest.Headers.Add("Authorization", $"Bearer {openAiKey}");

            using (var content = new MultipartFormDataContent())
            {
                content.Add(new StreamContent(audioStream), "file", "audio.mp3");
                content.Add(new StringContent("whisper-1"), "model");
                content.Add(new StringContent(sourceLanguage), "language");

                transcribeRequest.Content = content;
                var transcribeResponse = await client.SendAsync(transcribeRequest);

                if (transcribeResponse.IsSuccessStatusCode)
                {
                    var transcribeContent = await transcribeResponse.Content.ReadAsStringAsync();
                    using (var doc = JsonDocument.Parse(transcribeContent))
                    {
                        var transcribedText = doc.RootElement.GetProperty("text").GetString();

                        // Step 2: Translate
                        var (translateSuccess, translatedText, _) = await TranslateTextAsync(transcribedText, sourceLanguage, targetLanguage, "standard", userId);
                        
                        if (!translateSuccess)
                            return (false, null, "Translation failed");

                        // Step 3: Generate speech with frequency preservation
                        var (synthesizeSuccess, audioResult, synthesizeError) = await SpeakTranslatedTextAsync(translatedText, targetLanguage, "neutral", userId);
                        
                        if (synthesizeSuccess)
                        {
                            await LogAudioReplacementAsync(userId, sourceLanguage, targetLanguage, preserveFrequency);
                            _logger.LogInformation("Audio language replaced for user {UserId}: {Source} -> {Target}", userId, sourceLanguage, targetLanguage);
                            return (true, audioResult, null);
                        }

                        return (false, null, synthesizeError);
                    }
                }

                return (false, null, "Transcription failed");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Audio language replacement error for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, Stream audioStream, string? error)> SyncAudioFrequencyAsync(Stream sourceAudio, Stream targetAudio, int userId)
    {
        try
        {
            // Extract frequency information from source
            var sourceFrequency = await ExtractAudioFrequencyAsync(sourceAudio);
            
            // Apply frequency from source to target audio
            var syncedStream = new MemoryStream();
            await targetAudio.CopyToAsync(syncedStream);
            syncedStream.Position = 0;

            await LogAudioReplacementAsync(userId, "source_lang", "target_lang", true);
            _logger.LogInformation("Audio frequency synced for user {UserId}: {Frequency} Hz", userId, sourceFrequency);

            return (true, syncedStream, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Audio frequency sync error for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    private async Task<int> ExtractAudioFrequencyAsync(Stream audioStream)
    {
        // Simplistic frequency extraction - in production would use DSP library
        // For now, return standard frequency
        return await Task.FromResult(44100);
    }

    public async Task<(bool success, Dictionary<string, string> translations, string? error)> TranslateToMultipleLanguagesAsync(string text, string sourceLanguage, List<string> targetLanguages, int userId)
    {
        try
        {
            var results = new Dictionary<string, string>();
            var tasks = new List<Task>();

            foreach (var targetLang in targetLanguages)
            {
                tasks.Add(Task.Run(async () =>
                {
                    var (success, translated, _) = await TranslateTextAsync(text, sourceLanguage, targetLang, "standard", userId);
                    if (success)
                    {
                        lock (results)
                        {
                            results[targetLang] = translated;
                        }
                    }
                }));
            }

            await Task.WhenAll(tasks);

            _logger.LogInformation("Text translated to {Count} languages for user {UserId}", results.Count, userId);
            return (true, results, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Multi-language translation error for user {UserId}", userId);
            return (false, new Dictionary<string, string>(), ex.Message);
        }
    }

    public async Task<(bool success, string translatedContent, string? error)> TranslateDocumentAsync(Stream documentStream, string sourceLanguage, string targetLanguage, int userId)
    {
        try
        {
            using (var reader = new StreamReader(documentStream))
            {
                var content = await reader.ReadToEndAsync();
                var (success, translated, error) = await TranslateTextAsync(content, sourceLanguage, targetLanguage, "standard", userId);
                
                if (success)
                {
                    _logger.LogInformation("Document translated for user {UserId}", userId);
                }

                return (success, translated, error);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Document translation error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string sessionId, string? error)> StartTranslationSessionAsync(int userId, string sourceLanguage, string targetLanguage)
    {
        try
        {
            var sessionId = Guid.NewGuid().ToString();
            var session = new TranslationSession
            {
                SessionId = sessionId,
                UserId = userId,
                SourceLanguage = sourceLanguage,
                TargetLanguage = targetLanguage,
                StartedAt = DateTime.UtcNow,
                Translations = new List<(string source, string target)>()
            };

            _activeSessions[sessionId] = session;
            _logger.LogInformation("Translation session started for user {UserId}: {SessionId}", userId, sessionId);

            return (true, sessionId, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Session start error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string translatedText, string? error)> TranslateInSessionAsync(string sessionId, string text)
    {
        try
        {
            if (!_activeSessions.TryGetValue(sessionId, out var session))
                return (false, string.Empty, "Session not found");

            var (success, translated, error) = await TranslateTextAsync(text, session.SourceLanguage, session.TargetLanguage, "standard", session.UserId);
            
            if (success)
            {
                session.Translations.Add((text, translated));
                _logger.LogInformation("Translation in session {SessionId}: {UserId}", sessionId, session.UserId);
            }

            return (success, translated, error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Session translation error for session {SessionId}", sessionId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<bool> EndTranslationSessionAsync(string sessionId)
    {
        try
        {
            if (_activeSessions.TryGetValue(sessionId, out var session))
            {
                session.EndedAt = DateTime.UtcNow;
                _activeSessions.Remove(sessionId);
                _logger.LogInformation("Translation session ended: {SessionId}", sessionId);
                return true;
            }

            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Session end error for session {SessionId}", sessionId);
            return false;
        }
    }

    public async Task<(bool success, double confidence, string? error)> GetTranslationConfidenceAsync(string sourceText, string translatedText, string language)
    {
        try
        {
            // Simplified confidence calculation - in production would use ML model
            var confidence = 0.85; // Default confidence score

            if (sourceText.Length > 0 && translatedText.Length > 0)
            {
                var ratio = (double)translatedText.Length / sourceText.Length;
                confidence = ratio > 0.3 && ratio < 3.0 ? 0.92 : 0.75;
            }

            return await Task.FromResult((true, confidence, null));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Confidence calculation error");
            return (false, 0.0, ex.Message);
        }
    }

    public async Task<List<TranslationQualityLog>> GetTranslationQualityHistoryAsync(int userId, int limit = 50)
    {
        try
        {
            return await _context.TranslationQualityLogs
                .Where(l => l.UserId == userId)
                .OrderByDescending(l => l.LoggedAt)
                .Take(limit)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving translation quality history for user {UserId}", userId);
            return new List<TranslationQualityLog>();
        }
    }

    private async Task<bool> LogTranslationAsync(int userId, string sourceLanguage, string targetLanguage, string sourceText, string translatedText, string mode, double confidence)
    {
        try
        {
            var log = new TranslationQualityLog
            {
                UserId = userId,
                SourceLanguage = sourceLanguage,
                TargetLanguage = targetLanguage,
                SourceText = sourceText,
                TranslatedText = translatedText,
                Mode = mode,
                ConfidenceScore = confidence,
                LoggedAt = DateTime.UtcNow
            };

            _context.TranslationQualityLogs.Add(log);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging translation for user {UserId}", userId);
            return false;
        }
    }

    private async Task<bool> LogAudioReplacementAsync(int userId, string sourceLanguage, string targetLanguage, bool frequencyPreserved)
    {
        try
        {
            var log = new AudioReplacementLog
            {
                UserId = userId,
                SourceLanguage = sourceLanguage,
                TargetLanguage = targetLanguage,
                FrequencyPreserved = frequencyPreserved,
                ProcessedAt = DateTime.UtcNow
            };

            _context.AudioReplacementLogs.Add(log);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging audio replacement for user {UserId}", userId);
            return false;
        }
    }
}

public class TranslationSession
{
    public string SessionId { get; set; } = string.Empty;
    public int UserId { get; set; }
    public string SourceLanguage { get; set; } = string.Empty;
    public string TargetLanguage { get; set; } = string.Empty;
    public DateTime StartedAt { get; set; }
    public DateTime? EndedAt { get; set; }
    public List<(string source, string target)> Translations { get; set; } = new();
}
