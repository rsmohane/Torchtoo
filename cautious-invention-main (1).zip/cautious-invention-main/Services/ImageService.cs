namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface IImageService
{
    Task<(bool success, string imageUrl, string? error)> GenerateImageAsync(string prompt, string style = "natural", int userId = 0);
    Task<(bool success, string description, string? error)> AnalyzeImageAsync(Stream imageStream, int userId);
    Task<(bool success, Stream processedImage, string? error)> ProcessImageAsync(Stream imageStream, string operation, int userId);
    Task<(bool success, Stream generatedVideo, string? error)> GenerateVideoAsync(string prompt, int durationSeconds = 5, int userId = 0);
    Task<(bool success, List<string> results, string? error)> ExtractTextFromImageAsync(Stream imageStream, int userId);
    Task<bool> LogImageUsageAsync(int userId, string action, string details);
}

public class ImageService : IImageService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<ImageService> _logger;

    public ImageService(
        ApplicationDbContext context,
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<ImageService> logger)
    {
        _context = context;
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, string imageUrl, string? error)> GenerateImageAsync(string prompt, string style = "natural", int userId = 0)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, string.Empty, "OpenAI API key not configured");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/images/generations");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var fulledPrompt = $"{prompt} - Style: {style}";

            var payload = new
            {
                model = "dall-e-3",
                prompt = fulledPrompt,
                n = 1,
                size = "1024x1024",
                quality = "standard",
                response_format = "url"
            };

            request.Content = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(payload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var imageUrl = doc.RootElement.GetProperty("data")[0].GetProperty("url").GetString();
                    await LogImageUsageAsync(userId, "generation", $"Style: {style}, Prompt: {prompt}");
                    _logger.LogInformation("Image generated for user {UserId}", userId);
                    return (true, imageUrl ?? string.Empty, null);
                }
            }

            return (false, string.Empty, "Image generation failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Image generation error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string description, string? error)> AnalyzeImageAsync(Stream imageStream, int userId)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, string.Empty, "OpenAI API key not configured");

            // Convert stream to base64
            using (var ms = new MemoryStream())
            {
                await imageStream.CopyToAsync(ms);
                var imageBytes = ms.ToArray();
                var base64Image = Convert.ToBase64String(imageBytes);

                var client = _httpClientFactory.CreateClient();
                var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
                request.Headers.Add("Authorization", $"Bearer {openAiKey}");

                var payload = new
                {
                    model = "gpt-4-vision",
                    messages = new object[]
                    {
                        new
                        {
                            role = "user",
                            content = new object[]
                            {
                                new { type = "text", text = "Analyze this image in detail and provide a comprehensive description." },
                                new
                                {
                                    type = "image_url",
                                    image_url = new { url = $"data:image/jpeg;base64,{base64Image}" }
                                }
                            }
                        }
                    },
                    max_tokens = 1000
                };

                request.Content = new StringContent(
                    System.Text.Json.JsonSerializer.Serialize(payload),
                    System.Text.Encoding.UTF8,
                    "application/json"
                );

                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    using (var doc = JsonDocument.Parse(content))
                    {
                        var description = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                        await LogImageUsageAsync(userId, "analysis", "Image analyzed");
                        _logger.LogInformation("Image analyzed for user {UserId}", userId);
                        return (true, description ?? string.Empty, null);
                    }
                }

                return (false, string.Empty, "Image analysis failed");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Image analysis error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, Stream processedImage, string? error)> ProcessImageAsync(Stream imageStream, string operation, int userId)
    {
        try
        {
            // Placeholder for image processing operations
            // Operations: resize, crop, filter, enhance, convert
            
            var processedStream = new MemoryStream();
            await imageStream.CopyToAsync(processedStream);
            processedStream.Position = 0;

            await LogImageUsageAsync(userId, "processing", $"Operation: {operation}");
            _logger.LogInformation("Image processed for user {UserId}: {Operation}", userId, operation);
            return (true, processedStream, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Image processing error for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, Stream generatedVideo, string? error)> GenerateVideoAsync(string prompt, int durationSeconds = 5, int userId = 0)
    {
        try
        {
            // Note: Video generation requires Runway ML API or similar
            // This is a placeholder implementation
            var client = _httpClientFactory.CreateClient();
            
            // Simulate video generation by creating a placeholder
            var videoData = System.Text.Encoding.UTF8.GetBytes("Video generation placeholder - requires Runway ML API key");
            var stream = new MemoryStream(videoData);
            
            await LogImageUsageAsync(userId, "video_generation", $"Duration: {durationSeconds}s, Prompt: {prompt}");
            _logger.LogInformation("Video generated for user {UserId}", userId);
            
            return await Task.FromResult((true, (Stream)stream, (string?)null));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Video generation error for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<string> results, string? error)> ExtractTextFromImageAsync(Stream imageStream, int userId)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, new List<string>(), "OpenAI API key not configured");

            // Convert stream to base64
            using (var ms = new MemoryStream())
            {
                await imageStream.CopyToAsync(ms);
                var imageBytes = ms.ToArray();
                var base64Image = Convert.ToBase64String(imageBytes);

                var client = _httpClientFactory.CreateClient();
                var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
                request.Headers.Add("Authorization", $"Bearer {openAiKey}");

                var payload = new
                {
                    model = "gpt-4-vision",
                    messages = new object[]
                    {
                        new
                        {
                            role = "user",
                            content = new object[]
                            {
                                new { type = "text", text = "Extract all text from this image and return it as a JSON array of strings." },
                                new
                                {
                                    type = "image_url",
                                    image_url = new { url = $"data:image/jpeg;base64,{base64Image}" }
                                }
                            }
                        }
                    },
                    max_tokens = 1000
                };

                request.Content = new StringContent(
                    System.Text.Json.JsonSerializer.Serialize(payload),
                    System.Text.Encoding.UTF8,
                    "application/json"
                );

                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    using (var doc = JsonDocument.Parse(content))
                    {
                        var textContent = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                        var textLines = textContent?.Split('\n').Where(l => !string.IsNullOrWhiteSpace(l)).ToList() ?? new List<string>();
                        
                        await LogImageUsageAsync(userId, "text_extraction", $"Extracted {textLines.Count} lines");
                        _logger.LogInformation("Text extracted from image for user {UserId}", userId);
                        return (true, textLines, null);
                    }
                }

                return (false, new List<string>(), "Text extraction failed");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Text extraction error for user {UserId}", userId);
            return (false, new List<string>(), ex.Message);
        }
    }

    public async Task<bool> LogImageUsageAsync(int userId, string action, string details)
    {
        try
        {
            var usage = new ImageUsageLog
            {
                UserId = userId,
                Action = action,
                Details = details,
                LoggedAt = DateTime.UtcNow
            };

            _context.ImageUsageLogs.Add(usage);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Image usage logged for user {UserId}: {Action}", userId, action);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging image usage for user {UserId}", userId);
            return false;
        }
    }
}
