namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface IAudioService
{
    Task<(bool success, string transcribedText, string? error)> TranscribeAudioAsync(Stream audioStream, string language, int userId);
    Task<(bool success, Stream audioStream, string? error)> SynthesizeSpeechAsync(string text, string language, string voice = "default", int userId = 0);
    Task<(bool success, string translatedText, string? error)> TranslateAudioAsync(Stream audioStream, string sourceLanguage, string targetLanguage, int userId);
    Task<List<string>> GetSupportedLanguagesAsync();
    Task<List<string>> GetAvailableVoicesAsync(string language);
    Task<bool> LogAudioUsageAsync(int userId, string action, int durationSeconds, string language);
}

public class AudioService : IAudioService
{
    private readonly ApplicationDbContext _context;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<AudioService> _logger;

    public AudioService(
        ApplicationDbContext context,
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<AudioService> logger)
    {
        _context = context;
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<(bool success, string transcribedText, string? error)> TranscribeAudioAsync(Stream audioStream, string language, int userId)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, string.Empty, "OpenAI API key not configured");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/audio/transcriptions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            using (var content = new MultipartFormDataContent())
            {
                content.Add(new StreamContent(audioStream), "file", "audio.mp3");
                content.Add(new StringContent("whisper-1"), "model");
                content.Add(new StringContent(language), "language");

                request.Content = content;
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    using (var doc = JsonDocument.Parse(responseContent))
                    {
                        var text = doc.RootElement.GetProperty("text").GetString();
                        await LogAudioUsageAsync(userId, "transcription", (int)(audioStream.Length / 16000), language);
                        _logger.LogInformation("Audio transcribed for user {UserId}", userId);
                        return (true, text ?? string.Empty, null);
                    }
                }

                return (false, string.Empty, "Transcription failed");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Audio transcription error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, Stream audioStream, string? error)> SynthesizeSpeechAsync(string text, string language, string voice = "default", int userId = 0)
    {
        try
        {
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, null, "OpenAI API key not configured");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/audio/speech");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var payload = new
            {
                model = "tts-1",
                input = text,
                voice = voice == "default" ? "alloy" : voice,
                speed = 1.0
            };

            request.Content = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(payload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
            if (response.IsSuccessStatusCode)
            {
                var stream = await response.Content.ReadAsStreamAsync();
                _logger.LogInformation("Speech synthesized for user {UserId}", userId);
                return (true, stream, null);
            }

            return (false, null, "Speech synthesis failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech synthesis error for user {UserId}", userId);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string translatedText, string? error)> TranslateAudioAsync(Stream audioStream, string sourceLanguage, string targetLanguage, int userId)
    {
        try
        {
            // First transcribe the audio
            var (transcribeSuccess, transcribedText, transcribeError) = await TranscribeAudioAsync(audioStream, sourceLanguage, userId);
            if (!transcribeSuccess)
                return (false, string.Empty, transcribeError);

            // Then translate the text
            var openAiKey = _configuration["OpenAI:ApiKey"];
            if (string.IsNullOrEmpty(openAiKey))
                return (false, string.Empty, "OpenAI API key not configured");

            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
            request.Headers.Add("Authorization", $"Bearer {openAiKey}");

            var payload = new
            {
                model = "gpt-4",
                messages = new[]
                {
                    new { role = "system", content = $"Translate the following text from {sourceLanguage} to {targetLanguage}. Respond with only the translated text." },
                    new { role = "user", content = transcribedText }
                },
                max_tokens = 2000,
                temperature = 0.3
            };

            request.Content = new StringContent(
                System.Text.Json.JsonSerializer.Serialize(payload),
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                using (var doc = JsonDocument.Parse(content))
                {
                    var result = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                    await LogAudioUsageAsync(userId, "audio_translation", (int)(audioStream.Length / 16000), targetLanguage);
                    _logger.LogInformation("Audio translated for user {UserId}", userId);
                    return (true, result ?? string.Empty, null);
                }
            }

            return (false, string.Empty, "Translation failed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Audio translation error for user {UserId}", userId);
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<List<string>> GetSupportedLanguagesAsync()
    {
        return await Task.FromResult(new List<string>
        {
            "en", "es", "fr", "de", "it", "pt", "ru", "ja", "ko", "zh", "ar", "hi"
        });
    }

    public async Task<List<string>> GetAvailableVoicesAsync(string language)
    {
        var voices = new Dictionary<string, List<string>>
        {
            { "en", new List<string> { "alloy", "echo", "fable", "onyx", "nova", "shimmer" } },
            { "es", new List<string> { "alloy", "echo" } },
            { "fr", new List<string> { "alloy", "echo" } },
            { "de", new List<string> { "alloy", "echo" } },
            { "it", new List<string> { "alloy" } }
        };

        return await Task.FromResult(
            voices.ContainsKey(language) ? voices[language] : new List<string> { "alloy" }
        );
    }

    public async Task<bool> LogAudioUsageAsync(int userId, string action, int durationSeconds, string language)
    {
        try
        {
            var usage = new AudioUsageLog
            {
                UserId = userId,
                Action = action,
                DurationSeconds = durationSeconds,
                Language = language,
                LoggedAt = DateTime.UtcNow
            };

            _context.AudioUsageLogs.Add(usage);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Audio usage logged for user {UserId}: {Action}", userId, action);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging audio usage for user {UserId}", userId);
            return false;
        }
    }
}
