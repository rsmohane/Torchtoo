namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;

public interface IApiKeyMonitoringService
{
    Task RecordApiKeyUsageAsync(int apiKeyId, bool success, int responseTimeMs);
    Task<ApiKeyUsageStatistics?> GetApiKeyStatisticsAsync(int apiKeyId, DateTime fromDate, DateTime toDate);
    Task<List<ApiKeyUsageStatistics>> GetUserApiKeyStatisticsAsync(int userId);
    Task<(bool healthy, string message)> CheckApiKeyHealthAsync(int apiKeyId);
    Task<Dictionary<string, object>> GetApiKeyMetricsAsync(int apiKeyId);
}

public class ApiKeyMonitoringService : IApiKeyMonitoringService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<ApiKeyMonitoringService> _logger;

    public ApiKeyMonitoringService(
        ApplicationDbContext context,
        ILogger<ApiKeyMonitoringService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task RecordApiKeyUsageAsync(int apiKeyId, bool success, int responseTimeMs)
    {
        try
        {
            var today = DateTime.UtcNow.Date;
            var stats = await _context.ApiKeyUsageStatistics
                .FirstOrDefaultAsync(s => s.ApiKeyId == apiKeyId && s.DateFrom.Date == today);

            if (stats == null)
            {
                stats = new ApiKeyUsageStatistics
                {
                    ApiKeyId = apiKeyId,
                    DateFrom = today,
                    DateTo = today,
                    CreatedAt = DateTime.UtcNow
                };
                _context.ApiKeyUsageStatistics.Add(stats);
            }

            stats.RequestsCount++;
            if (success)
                stats.SuccessfulRequests++;
            else
                stats.FailedRequests++;

            // Update average response time
            var totalTime = (stats.AverageResponseTimeMs * (stats.RequestsCount - 1)) + responseTimeMs;
            stats.AverageResponseTimeMs = totalTime / stats.RequestsCount;
            stats.DateTo = DateTime.UtcNow.Date;

            _context.ApiKeyUsageStatistics.Update(stats);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error recording API key usage");
        }
    }

    public async Task<ApiKeyUsageStatistics?> GetApiKeyStatisticsAsync(int apiKeyId, DateTime fromDate, DateTime toDate)
    {
        return await _context.ApiKeyUsageStatistics
            .FirstOrDefaultAsync(s =>
                s.ApiKeyId == apiKeyId &&
                s.DateFrom >= fromDate &&
                s.DateTo <= toDate);
    }

    public async Task<List<ApiKeyUsageStatistics>> GetUserApiKeyStatisticsAsync(int userId)
    {
        return await _context.ApiKeyUsageStatistics
            .Where(s => s.ApiKey != null && s.ApiKey.UserId == userId)
            .OrderByDescending(s => s.DateFrom)
            .ToListAsync();
    }

    public async Task<(bool healthy, string message)> CheckApiKeyHealthAsync(int apiKeyId)
    {
        try
        {
            var stats = await _context.ApiKeyUsageStatistics
                .Where(s => s.ApiKeyId == apiKeyId && s.DateFrom.Date == DateTime.UtcNow.Date)
                .FirstOrDefaultAsync();

            if (stats == null)
                return (true, "No usage recorded today");

            var successRate = stats.RequestsCount > 0 ? (double)stats.SuccessfulRequests / stats.RequestsCount : 0;
            var avgResponseTime = stats.AverageResponseTimeMs;

            if (successRate < 0.8)
                return (false, $"Low success rate: {successRate:P}");

            if (avgResponseTime > 5000)
                return (false, $"High response time: {avgResponseTime}ms");

            if (stats.FailedRequests > 100)
                return (false, $"High failure count: {stats.FailedRequests}");

            return (true, $"Healthy - {successRate:P} success rate, {avgResponseTime:F0}ms avg response time");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking API key health");
            return (false, "Error checking health");
        }
    }

    public async Task<Dictionary<string, object>> GetApiKeyMetricsAsync(int apiKeyId)
    {
        var today = DateTime.UtcNow.Date;
        var stats = await _context.ApiKeyUsageStatistics
            .Where(s => s.ApiKeyId == apiKeyId && s.DateFrom.Date == today)
            .FirstOrDefaultAsync();

        var apiKey = await _context.ApiKeys.FindAsync(apiKeyId);
        var daysActive = apiKey != null ? (DateTime.UtcNow - apiKey.CreatedAt).Days : 0;

        return new Dictionary<string, object>
        {
            { "apiKeyId", apiKeyId },
            { "requestsToday", stats?.RequestsCount ?? 0 },
            { "successfulRequests", stats?.SuccessfulRequests ?? 0 },
            { "failedRequests", stats?.FailedRequests ?? 0 },
            { "successRate", stats != null && stats.RequestsCount > 0 ? ((double)stats.SuccessfulRequests / stats.RequestsCount) : 0 },
            { "averageResponseTimeMs", stats?.AverageResponseTimeMs ?? 0 },
            { "daysActive", daysActive },
            { "lastUsedAt", apiKey?.LastUsedAt },
            { "isActive", apiKey?.IsActive },
            { "expiresAt", apiKey?.ExpiresAt }
        };
    }
}
