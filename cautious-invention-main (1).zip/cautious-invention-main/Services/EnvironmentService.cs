namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;

public interface IEnvironmentService
{
    Task<Environment> CreateEnvironmentAsync(Environment environment);
    Task<Environment?> GetEnvironmentAsync(int environmentId);
    Task<List<Environment>> GetUserEnvironmentsAsync(int userId);
    Task<bool> UpdateEnvironmentAsync(Environment environment);
    Task<bool> DeleteEnvironmentAsync(int environmentId, int userId);
    Task<bool> LogAccessAsync(EnvironmentAccessLog log);
    Task<List<EnvironmentAccessLog>> GetAccessLogsAsync(int environmentId, DateTime? fromDate = null, DateTime? toDate = null);
    Task<Dictionary<string, object>> GetEnvironmentVariablesAsync(int environmentId);
    Task<bool> UpdateEnvironmentVariablesAsync(int environmentId, Dictionary<string, string> variables);
}

public class EnvironmentService : IEnvironmentService
{
    private readonly ApplicationDbContext _context;
    private readonly IEncryptionService _encryptionService;
    private readonly ILogger<EnvironmentService> _logger;

    public EnvironmentService(
        ApplicationDbContext context,
        IEncryptionService encryptionService,
        ILogger<EnvironmentService> logger)
    {
        _context = context;
        _encryptionService = encryptionService;
        _logger = logger;
    }

    public async Task<Environment> CreateEnvironmentAsync(Environment environment)
    {
        try
        {
            environment.CreatedAt = DateTime.UtcNow;
            _context.Environments.Add(environment);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Environment {EnvironmentId} created for user {UserId}", environment.Id, environment.UserId);
            return environment;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating environment");
            throw;
        }
    }

    public async Task<Environment?> GetEnvironmentAsync(int environmentId)
    {
        return await _context.Environments
            .Include(e => e.AccessLogs)
            .FirstOrDefaultAsync(e => e.Id == environmentId && e.IsActive);
    }

    public async Task<List<Environment>> GetUserEnvironmentsAsync(int userId)
    {
        return await _context.Environments
            .Where(e => e.UserId == userId && e.IsActive)
            .OrderByDescending(e => e.CreatedAt)
            .ToListAsync();
    }

    public async Task<bool> UpdateEnvironmentAsync(Environment environment)
    {
        try
        {
            _context.Environments.Update(environment);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating environment {EnvironmentId}", environment.Id);
            return false;
        }
    }

    public async Task<bool> DeleteEnvironmentAsync(int environmentId, int userId)
    {
        try
        {
            var environment = await _context.Environments.FirstOrDefaultAsync(e => e.Id == environmentId && e.UserId == userId);
            if (environment == null)
                return false;

            environment.IsActive = false;
            _context.Environments.Update(environment);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Environment {EnvironmentId} deactivated", environmentId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting environment {EnvironmentId}", environmentId);
            return false;
        }
    }

    public async Task<bool> LogAccessAsync(EnvironmentAccessLog log)
    {
        try
        {
            log.CreatedAt = DateTime.UtcNow;
            _context.EnvironmentAccessLogs.Add(log);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging environment access");
            return false;
        }
    }

    public async Task<List<EnvironmentAccessLog>> GetAccessLogsAsync(int environmentId, DateTime? fromDate = null, DateTime? toDate = null)
    {
        var query = _context.EnvironmentAccessLogs
            .Where(l => l.EnvironmentId == environmentId)
            .AsQueryable();

        if (fromDate.HasValue)
            query = query.Where(l => l.CreatedAt >= fromDate.Value);

        if (toDate.HasValue)
            query = query.Where(l => l.CreatedAt <= toDate.Value);

        return await query
            .Include(l => l.User)
            .OrderByDescending(l => l.CreatedAt)
            .ToListAsync();
    }

    public async Task<Dictionary<string, object>> GetEnvironmentVariablesAsync(int environmentId)
    {
        var environment = await _context.Environments.FirstOrDefaultAsync(e => e.Id == environmentId);
        if (environment == null)
            return new Dictionary<string, object>();

        try
        {
            var decrypted = _encryptionService.Decrypt(environment.EnvironmentVariablesEncrypted);
            var vars = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(decrypted);
            return vars ?? new Dictionary<string, object>();
        }
        catch
        {
            return new Dictionary<string, object>();
        }
    }

    public async Task<bool> UpdateEnvironmentVariablesAsync(int environmentId, Dictionary<string, string> variables)
    {
        try
        {
            var environment = await _context.Environments.FirstOrDefaultAsync(e => e.Id == environmentId);
            if (environment == null)
                return false;

            var json = System.Text.Json.JsonSerializer.Serialize(variables);
            environment.EnvironmentVariablesEncrypted = _encryptionService.Encrypt(json);
            _context.Environments.Update(environment);
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating environment variables");
            return false;
        }
    }
}
