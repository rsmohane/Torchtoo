namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

public interface IAuditService
{
    Task LogActionAsync(int? userId, string action, string entityType, int? entityId, string changes, string ipAddress);
    Task<List<AuditLog>> GetAuditLogsAsync(int? userId = null, DateTime? fromDate = null, DateTime? toDate = null);
    Task<AuditLog?> GetAuditLogAsync(int logId);
}

public class AuditService : IAuditService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<AuditService> _logger;

    public AuditService(ApplicationDbContext context, ILogger<AuditService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task LogActionAsync(int? userId, string action, string entityType, int? entityId, string changes, string ipAddress)
    {
        try
        {
            var log = new AuditLog
            {
                UserId = userId,
                Action = action,
                EntityType = entityType,
                EntityId = entityId,
                Changes = changes,
                IpAddress = ipAddress,
                CreatedAt = DateTime.UtcNow
            };

            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Audit log created: {Action} on {EntityType} by user {UserId}", action, entityType, userId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error logging audit action");
        }
    }

    public async Task<List<AuditLog>> GetAuditLogsAsync(int? userId = null, DateTime? fromDate = null, DateTime? toDate = null)
    {
        var query = _context.AuditLogs.AsQueryable();

        if (userId.HasValue)
            query = query.Where(a => a.UserId == userId.Value);

        if (fromDate.HasValue)
            query = query.Where(a => a.CreatedAt >= fromDate.Value);

        if (toDate.HasValue)
            query = query.Where(a => a.CreatedAt <= toDate.Value);

        return await query
            .Include(a => a.User)
            .OrderByDescending(a => a.CreatedAt)
            .ToListAsync();
    }

    public async Task<AuditLog?> GetAuditLogAsync(int logId)
    {
        return await _context.AuditLogs
            .Include(a => a.User)
            .FirstOrDefaultAsync(a => a.Id == logId);
    }
}
