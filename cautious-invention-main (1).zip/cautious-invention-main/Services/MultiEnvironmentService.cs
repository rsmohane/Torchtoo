namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;

public interface IMultiEnvironmentService
{
    Task<(bool success, EnvironmentConfig? config, string? error)> GetEnvironmentConfigAsync(string environmentName);
    Task<(bool success, List<EnvironmentConfig> configs, string? error)> GetAllEnvironmentsAsync();
    Task<(bool success, string? error)> CreateEnvironmentAsync(CreateEnvironmentRequest request);
    Task<(bool success, string? error)> UpdateEnvironmentAsync(string name, UpdateEnvironmentRequest request);
    Task<(bool success, string? error)> DeleteEnvironmentAsync(string name);
    Task<(bool success, string? error)> SwitchEnvironmentAsync(string environmentName);
    
    // Environment-specific configurations
    Task<(bool success, DatabaseConfig? config, string? error)> GetDatabaseConfigAsync(string environmentName);
    Task<(bool success, LoggingConfig? config, string? error)> GetLoggingConfigAsync(string environmentName);
    Task<(bool success, APIConfig? config, string? error)> GetAPIConfigAsync(string environmentName);
    Task<(bool success, SecurityConfig? config, string? error)> GetSecurityConfigAsync(string environmentName);
    
    // Environment validation
    Task<(bool success, EnvironmentHealth health, string? error)> HealthCheckAsync(string environmentName);
    Task<bool> ValidateEnvironmentAsync(string environmentName);
}

public class MultiEnvironmentService : IMultiEnvironmentService
{
    private readonly ApplicationDbContext _context;
    private readonly IConfiguration _configuration;
    private readonly ILogger<MultiEnvironmentService> _logger;
    private static ConcurrentDictionary<string, EnvironmentConfig> _environmentCache = new();
    private string _currentEnvironment = "Development";

    public MultiEnvironmentService(
        ApplicationDbContext context,
        IConfiguration configuration,
        ILogger<MultiEnvironmentService> logger)
    {
        _context = context;
        _configuration = configuration;
        _logger = logger;
        
        // Load default environments
        InitializeDefaultEnvironments();
    }

    private void InitializeDefaultEnvironments()
    {
        var environments = new[]
        {
            new EnvironmentConfig
            {
                Name = "Development",
                DisplayName = "Development Environment",
                IsActive = true,
                Tier = "Development",
                Region = "local",
                CreatedAt = DateTime.UtcNow,
                DatabaseConfig = new DatabaseConfig
                {
                    ConnectionString = "Server=localhost;Database=HumanAssistDB_Dev;User Id=sa;Password=YourPassword123!;",
                    Provider = "SqlServer",
                    MaxConnections = 10
                },
                LoggingConfig = new LoggingConfig
                {
                    Level = "Debug",
                    Format = "JSON",
                    RetentionDays = 7,
                    EnableConsoleLogging = true
                },
                APIConfig = new APIConfig
                {
                    BaseUrl = "http://localhost:5000",
                    Port = 5000,
                    Timeout = 30000
                },
                SecurityConfig = new SecurityConfig
                {
                    EncryptionEnabled = false,
                    SSLRequired = false,
                    RateLimitPerMinute = 1000
                }
            },
            new EnvironmentConfig
            {
                Name = "Staging",
                DisplayName = "Staging Environment",
                IsActive = true,
                Tier = "Staging",
                Region = "us-east-1",
                CreatedAt = DateTime.UtcNow,
                DatabaseConfig = new DatabaseConfig
                {
                    ConnectionString = "Server=staging-db.example.com;Database=HumanAssistDB_Staging;User Id=admin;Password=SecurePassword!;",
                    Provider = "SqlServer",
                    MaxConnections = 50
                },
                LoggingConfig = new LoggingConfig
                {
                    Level = "Information",
                    Format = "JSON",
                    RetentionDays = 30,
                    EnableConsoleLogging = true
                },
                APIConfig = new APIConfig
                {
                    BaseUrl = "https://staging-api.example.com",
                    Port = 443,
                    Timeout = 30000
                },
                SecurityConfig = new SecurityConfig
                {
                    EncryptionEnabled = true,
                    SSLRequired = true,
                    RateLimitPerMinute = 100
                }
            },
            new EnvironmentConfig
            {
                Name = "Production",
                DisplayName = "Production Environment",
                IsActive = true,
                Tier = "Production",
                Region = "us-west-2",
                CreatedAt = DateTime.UtcNow,
                DatabaseConfig = new DatabaseConfig
                {
                    ConnectionString = "Server=prod-db.example.com;Database=HumanAssistDB_Prod;User Id=prodadmin;Password=ProductionSecurePassword!;",
                    Provider = "SqlServer",
                    MaxConnections = 200
                },
                LoggingConfig = new LoggingConfig
                {
                    Level = "Warning",
                    Format = "JSON",
                    RetentionDays = 90,
                    EnableConsoleLogging = false
                },
                APIConfig = new APIConfig
                {
                    BaseUrl = "https://api.example.com",
                    Port = 443,
                    Timeout = 30000
                },
                SecurityConfig = new SecurityConfig
                {
                    EncryptionEnabled = true,
                    SSLRequired = true,
                    RateLimitPerMinute = 50
                }
            }
        };

        foreach (var env in environments)
        {
            _environmentCache.TryAdd(env.Name, env);
        }
        
        _logger.LogInformation("Initialized {Count} default environments", environments.Length);
    }

    public async Task<(bool success, EnvironmentConfig? config, string? error)> GetEnvironmentConfigAsync(string environmentName)
    {
        try
        {
            if (_environmentCache.TryGetValue(environmentName, out var config))
            {
                return (true, config, null);
            }

            _logger.LogWarning("Environment {EnvironmentName} not found", environmentName);
            return (false, null, $"Environment '{environmentName}' not found");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting environment config");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<EnvironmentConfig> configs, string? error)> GetAllEnvironmentsAsync()
    {
        try
        {
            var configs = _environmentCache.Values.ToList();
            return (true, configs, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting all environments");
            return (false, new List<EnvironmentConfig>(), ex.Message);
        }
    }

    public async Task<(bool success, string? error)> CreateEnvironmentAsync(CreateEnvironmentRequest request)
    {
        try
        {
            var config = new EnvironmentConfig
            {
                Name = request.Name,
                DisplayName = request.DisplayName,
                IsActive = request.IsActive,
                Tier = request.Tier,
                Region = request.Region,
                CreatedAt = DateTime.UtcNow,
                DatabaseConfig = request.DatabaseConfig,
                LoggingConfig = request.LoggingConfig,
                APIConfig = request.APIConfig,
                SecurityConfig = request.SecurityConfig
            };

            if (_environmentCache.TryAdd(request.Name, config))
            {
                _logger.LogInformation("Environment {EnvironmentName} created", request.Name);
                return (true, null);
            }

            return (false, $"Environment '{request.Name}' already exists");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating environment");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> UpdateEnvironmentAsync(string name, UpdateEnvironmentRequest request)
    {
        try
        {
            if (_environmentCache.TryGetValue(name, out var config))
            {
                if (!string.IsNullOrEmpty(request.DisplayName))
                    config.DisplayName = request.DisplayName;
                
                if (request.IsActive.HasValue)
                    config.IsActive = request.IsActive.Value;
                
                if (!string.IsNullOrEmpty(request.Region))
                    config.Region = request.Region;
                
                if (request.DatabaseConfig != null)
                    config.DatabaseConfig = request.DatabaseConfig;
                
                if (request.LoggingConfig != null)
                    config.LoggingConfig = request.LoggingConfig;
                
                if (request.APIConfig != null)
                    config.APIConfig = request.APIConfig;
                
                if (request.SecurityConfig != null)
                    config.SecurityConfig = request.SecurityConfig;

                config.UpdatedAt = DateTime.UtcNow;
                
                _logger.LogInformation("Environment {EnvironmentName} updated", name);
                return (true, null);
            }

            return (false, $"Environment '{name}' not found");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating environment");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> DeleteEnvironmentAsync(string name)
    {
        try
        {
            // Prevent deletion of core environments
            if (name == "Development" || name == "Production")
            {
                return (false, $"Cannot delete core environment '{name}'");
            }

            if (_environmentCache.TryRemove(name, out _))
            {
                _logger.LogInformation("Environment {EnvironmentName} deleted", name);
                return (true, null);
            }

            return (false, $"Environment '{name}' not found");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting environment");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> SwitchEnvironmentAsync(string environmentName)
    {
        try
        {
            if (!_environmentCache.ContainsKey(environmentName))
            {
                return (false, $"Environment '{environmentName}' not found");
            }

            _currentEnvironment = environmentName;
            _logger.LogInformation("Switched to environment {EnvironmentName}", environmentName);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error switching environment");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, DatabaseConfig? config, string? error)> GetDatabaseConfigAsync(string environmentName)
    {
        var (success, config, error) = await GetEnvironmentConfigAsync(environmentName);
        return (success, config?.DatabaseConfig, error);
    }

    public async Task<(bool success, LoggingConfig? config, string? error)> GetLoggingConfigAsync(string environmentName)
    {
        var (success, config, error) = await GetEnvironmentConfigAsync(environmentName);
        return (success, config?.LoggingConfig, error);
    }

    public async Task<(bool success, APIConfig? config, string? error)> GetAPIConfigAsync(string environmentName)
    {
        var (success, config, error) = await GetEnvironmentConfigAsync(environmentName);
        return (success, config?.APIConfig, error);
    }

    public async Task<(bool success, SecurityConfig? config, string? error)> GetSecurityConfigAsync(string environmentName)
    {
        var (success, config, error) = await GetEnvironmentConfigAsync(environmentName);
        return (success, config?.SecurityConfig, error);
    }

    public async Task<(bool success, EnvironmentHealth health, string? error)> HealthCheckAsync(string environmentName)
    {
        try
        {
            var (success, config, error) = await GetEnvironmentConfigAsync(environmentName);
            if (!success)
                return (false, null, error);

            var health = new EnvironmentHealth
            {
                EnvironmentName = environmentName,
                Status = "Healthy",
                Timestamp = DateTime.UtcNow,
                Services = new Dictionary<string, string>
                {
                    { "API", "Running" },
                    { "Database", "Connected" },
                    { "Cache", "Active" },
                    { "Logging", "Operational" }
                }
            };

            return (true, health, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error performing health check");
            return (false, null, ex.Message);
        }
    }

    public async Task<bool> ValidateEnvironmentAsync(string environmentName)
    {
        try
        {
            var (success, config, _) = await GetEnvironmentConfigAsync(environmentName);
            
            if (!success || config == null)
                return false;
            
            // Validate configuration
            if (string.IsNullOrEmpty(config.DatabaseConfig?.ConnectionString))
                return false;
            
            if (string.IsNullOrEmpty(config.APIConfig?.BaseUrl))
                return false;

            _logger.LogInformation("Environment {EnvironmentName} validation passed", environmentName);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validating environment");
            return false;
        }
    }
}

// DTOs and Models
public class EnvironmentConfig
{
    public string Name { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public string Tier { get; set; } = string.Empty; // Development, Staging, Production
    public string Region { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    
    public DatabaseConfig? DatabaseConfig { get; set; }
    public LoggingConfig? LoggingConfig { get; set; }
    public APIConfig? APIConfig { get; set; }
    public SecurityConfig? SecurityConfig { get; set; }
}

public class DatabaseConfig
{
    public string ConnectionString { get; set; } = string.Empty;
    public string Provider { get; set; } = "SqlServer";
    public int MaxConnections { get; set; } = 100;
    public int CommandTimeout { get; set; } = 30;
}

public class LoggingConfig
{
    public string Level { get; set; } = "Information";
    public string Format { get; set; } = "JSON";
    public int RetentionDays { get; set; } = 30;
    public bool EnableConsoleLogging { get; set; } = true;
}

public class APIConfig
{
    public string BaseUrl { get; set; } = string.Empty;
    public int Port { get; set; } = 5000;
    public int Timeout { get; set; } = 30000;
    public string? Version { get; set; }
}

public class SecurityConfig
{
    public bool EncryptionEnabled { get; set; }
    public bool SSLRequired { get; set; }
    public int RateLimitPerMinute { get; set; } = 60;
    public bool EnableCORS { get; set; } = true;
}

public class EnvironmentHealth
{
    public string EnvironmentName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
    public Dictionary<string, string> Services { get; set; } = new();
}

public class CreateEnvironmentRequest
{
    public string Name { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public string Tier { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    
    public DatabaseConfig? DatabaseConfig { get; set; }
    public LoggingConfig? LoggingConfig { get; set; }
    public APIConfig? APIConfig { get; set; }
    public SecurityConfig? SecurityConfig { get; set; }
}

public class UpdateEnvironmentRequest
{
    public string? DisplayName { get; set; }
    public bool? IsActive { get; set; }
    public string? Region { get; set; }
    
    public DatabaseConfig? DatabaseConfig { get; set; }
    public LoggingConfig? LoggingConfig { get; set; }
    public APIConfig? APIConfig { get; set; }
    public SecurityConfig? SecurityConfig { get; set; }
}
