namespace HumanAssist.Services;

using System.Text.Json;
using Microsoft.Extensions.Logging;

public interface IGitHubIntegrationService
{
    Task<(bool success, dynamic? repo, string? error)> GetRepositoryAsync(string owner, string repo);
    Task<(bool success, List<dynamic>? repos, string? error)> ListUserRepositoriesAsync(string username);
    Task<(bool success, List<dynamic>? issues, string? error)> ListRepositoryIssuesAsync(string owner, string repo);
    Task<(bool success, dynamic? pr, string? error)> GetPullRequestAsync(string owner, string repo, int prNumber);
    Task<(bool success, List<dynamic>? commits, string? error)> GetRepositoryCommitsAsync(string owner, string repo, int limit = 10);
    Task<(bool success, string content, string? error)> GetFileContentAsync(string owner, string repo, string filePath);
    Task<(bool success, List<dynamic>? releases, string? error)> GetRepositoryReleasesAsync(string owner, string repo);
    Task<(bool success, dynamic? user, string? error)> GetUserInfoAsync(string username);
}

public class GitHubIntegrationService : IGitHubIntegrationService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<GitHubIntegrationService> _logger;
    private readonly IConfiguration _configuration;
    private const string GitHubApiUrl = "https://api.github.com";

    public GitHubIntegrationService(
        IHttpClientFactory httpClientFactory,
        ILogger<GitHubIntegrationService> logger,
        IConfiguration configuration)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<(bool success, dynamic? repo, string? error)> GetRepositoryAsync(string owner, string repo)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/repos/{owner}/{repo}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to get repository: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var data = JsonSerializer.Deserialize<dynamic>(content);

            _logger.LogInformation("Retrieved GitHub repository: {Owner}/{Repo}", owner, repo);
            return (true, data, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving GitHub repository");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<dynamic>? repos, string? error)> ListUserRepositoriesAsync(string username)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/users/{username}/repos?per_page=30&sort=updated";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to list repositories: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var repos = JsonSerializer.Deserialize<List<dynamic>>(content);

            _logger.LogInformation("Retrieved {Count} repositories for user: {Username}", repos?.Count ?? 0, username);
            return (true, repos, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing repositories");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<dynamic>? issues, string? error)> ListRepositoryIssuesAsync(string owner, string repo)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/repos/{owner}/{repo}/issues?state=open&per_page=30";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to list issues: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var issues = JsonSerializer.Deserialize<List<dynamic>>(content);

            _logger.LogInformation("Retrieved {Count} issues from {Owner}/{Repo}", issues?.Count ?? 0, owner, repo);
            return (true, issues, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing issues");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, dynamic? pr, string? error)> GetPullRequestAsync(string owner, string repo, int prNumber)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/repos/{owner}/{repo}/pulls/{prNumber}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to get pull request: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var pr = JsonSerializer.Deserialize<dynamic>(content);

            _logger.LogInformation("Retrieved PR #{Number} from {Owner}/{Repo}", prNumber, owner, repo);
            return (true, pr, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving pull request");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, List<dynamic>? commits, string? error)> GetRepositoryCommitsAsync(string owner, string repo, int limit = 10)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/repos/{owner}/{repo}/commits?per_page={limit}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to get commits: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var commits = JsonSerializer.Deserialize<List<dynamic>>(content);

            _logger.LogInformation("Retrieved {Count} commits from {Owner}/{Repo}", commits?.Count ?? 0, owner, repo);
            return (true, commits, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving commits");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string content, string? error)> GetFileContentAsync(string owner, string repo, string filePath)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/repos/{owner}/{repo}/contents/{filePath}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, "", $"Failed to get file: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var json = JsonSerializer.Deserialize<JsonElement>(content);
            
            if (json.TryGetProperty("content", out var encodedContent))
            {
                var decodedContent = System.Text.Encoding.UTF8.GetString(
                    Convert.FromBase64String(encodedContent.GetString() ?? ""));
                
                _logger.LogInformation("Retrieved file from {Owner}/{Repo}: {FilePath}", owner, repo, filePath);
                return (true, decodedContent, null);
            }

            return (false, "", "File content not found");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving file content");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, List<dynamic>? releases, string? error)> GetRepositoryReleasesAsync(string owner, string repo)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/repos/{owner}/{repo}/releases";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to get releases: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var releases = JsonSerializer.Deserialize<List<dynamic>>(content);

            _logger.LogInformation("Retrieved {Count} releases from {Owner}/{Repo}", releases?.Count ?? 0, owner, repo);
            return (true, releases, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving releases");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, dynamic? user, string? error)> GetUserInfoAsync(string username)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            SetGitHubHeaders(client);

            var url = $"{GitHubApiUrl}/users/{username}";
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return (false, null, $"Failed to get user info: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var user = JsonSerializer.Deserialize<dynamic>(content);

            _logger.LogInformation("Retrieved user info: {Username}", username);
            return (true, user, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving user info");
            return (false, null, ex.Message);
        }
    }

    private void SetGitHubHeaders(HttpClient client)
    {
        var token = _configuration["GitHubApi:Token"];
        if (!string.IsNullOrEmpty(token))
        {
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
        }
        client.DefaultRequestHeaders.Add("User-Agent", "GRT-HumanAssist");
        client.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");
    }
}
