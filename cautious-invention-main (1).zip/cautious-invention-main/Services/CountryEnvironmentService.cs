namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

public interface ICountryEnvironmentService
{
    Task<List<CountryEnvironment>> GetAllCountriesAsync();
    Task<(bool success, CountryEnvironment? country, string? error)> GetCountryEnvironmentAsync(string countryCode);
    Task<(bool success, string? error)> CreateCountryEnvironmentAsync(CountryEnvironment country);
    Task<(bool success, string? error)> UpdateCountryEnvironmentAsync(CountryEnvironment country);
    Task<(bool success, string? error)> DeleteCountryEnvironmentAsync(string countryCode);
    Task<List<CountryEnvironment>> GetCountriesByRegionAsync(string region);
    Task<(bool success, Dictionary<string, object> config, string? error)> GetCountrySpecificConfigAsync(string countryCode, string configType);
    Task<List<CountryWorkProcess>> GetCountryWorkProcessesAsync(string countryCode);
    Task<(bool success, string? error)> UpdateCountryWorkProcessAsync(string countryCode, CountryWorkProcess process);
}

public class CountryEnvironmentService : ICountryEnvironmentService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<CountryEnvironmentService> _logger;
    private readonly IHttpClientFactory _httpClientFactory;

    public CountryEnvironmentService(
        ApplicationDbContext context,
        ILogger<CountryEnvironmentService> logger,
        IHttpClientFactory httpClientFactory)
    {
        _context = context;
        _logger = logger;
        _httpClientFactory = httpClientFactory;
    }

    public async Task<List<CountryEnvironment>> GetAllCountriesAsync()
    {
        try
        {
            return await _context.CountryEnvironments
                .Include(c => c.WorkProcesses)
                .OrderBy(c => c.CountryName)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all countries");
            return new List<CountryEnvironment>();
        }
    }

    public async Task<(bool success, CountryEnvironment? country, string? error)> GetCountryEnvironmentAsync(string countryCode)
    {
        try
        {
            var country = await _context.CountryEnvironments
                .Include(c => c.WorkProcesses)
                .FirstOrDefaultAsync(c => c.CountryCode == countryCode.ToUpper());

            if (country == null)
                return (false, null, $"Country '{countryCode}' not found");

            return (true, country, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving country environment for {CountryCode}", countryCode);
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> CreateCountryEnvironmentAsync(CountryEnvironment country)
    {
        try
        {
            if (string.IsNullOrEmpty(country.CountryCode))
                return (false, "Country code is required");

            var exists = await _context.CountryEnvironments
                .AnyAsync(c => c.CountryCode == country.CountryCode.ToUpper());

            if (exists)
                return (false, $"Country '{country.CountryCode}' already exists");

            country.CountryCode = country.CountryCode.ToUpper();
            country.CreatedAt = DateTime.UtcNow;
            country.LastModifiedAt = DateTime.UtcNow;

            _context.CountryEnvironments.Add(country);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Created country environment for {Country}", country.CountryName);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating country environment");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> UpdateCountryEnvironmentAsync(CountryEnvironment country)
    {
        try
        {
            var existing = await _context.CountryEnvironments
                .FirstOrDefaultAsync(c => c.CountryCode == country.CountryCode.ToUpper());

            if (existing == null)
                return (false, $"Country '{country.CountryCode}' not found");

            existing.CountryName = country.CountryName;
            existing.Region = country.Region;
            existing.TimeZone = country.TimeZone;
            existing.Currency = country.Currency;
            existing.LanguageCode = country.LanguageCode;
            existing.LegalRequirements = country.LegalRequirements;
            existing.TaxRegulations = country.TaxRegulations;
            existing.WorkCulture = country.WorkCulture;
            existing.AutomationLevel = country.AutomationLevel;
            existing.LastModifiedAt = DateTime.UtcNow;

            _context.CountryEnvironments.Update(existing);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Updated country environment for {Country}", country.CountryName);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating country environment");
            return (false, ex.Message);
        }
    }

    public async Task<(bool success, string? error)> DeleteCountryEnvironmentAsync(string countryCode)
    {
        try
        {
            var country = await _context.CountryEnvironments
                .FirstOrDefaultAsync(c => c.CountryCode == countryCode.ToUpper());

            if (country == null)
                return (false, $"Country '{countryCode}' not found");

            _context.CountryEnvironments.Remove(country);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Deleted country environment for {CountryCode}", countryCode);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting country environment");
            return (false, ex.Message);
        }
    }

    public async Task<List<CountryEnvironment>> GetCountriesByRegionAsync(string region)
    {
        try
        {
            return await _context.CountryEnvironments
                .Where(c => c.Region == region)
                .Include(c => c.WorkProcesses)
                .OrderBy(c => c.CountryName)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving countries by region {Region}", region);
            return new List<CountryEnvironment>();
        }
    }

    public async Task<(bool success, Dictionary<string, object> config, string? error)> GetCountrySpecificConfigAsync(string countryCode, string configType)
    {
        try
        {
            var country = await _context.CountryEnvironments
                .FirstOrDefaultAsync(c => c.CountryCode == countryCode.ToUpper());

            if (country == null)
                return (false, new Dictionary<string, object>(), $"Country '{countryCode}' not found");

            var config = new Dictionary<string, object>();

            switch (configType.ToLower())
            {
                case "legal":
                    config["requirements"] = country.LegalRequirements ?? "";
                    config["taxRegulations"] = country.TaxRegulations ?? "";
                    break;
                case "cultural":
                    config["workCulture"] = country.WorkCulture ?? "";
                    config["automationLevel"] = country.AutomationLevel;
                    break;
                case "technical":
                    config["timeZone"] = country.TimeZone ?? "";
                    config["languageCode"] = country.LanguageCode ?? "";
                    config["currency"] = country.Currency ?? "";
                    break;
                default:
                    config["countryName"] = country.CountryName;
                    config["region"] = country.Region;
                    config["all"] = new
                    {
                        country.CountryName,
                        country.Region,
                        country.TimeZone,
                        country.Currency,
                        country.LanguageCode,
                        country.LegalRequirements,
                        country.TaxRegulations,
                        country.WorkCulture,
                        country.AutomationLevel
                    };
                    break;
            }

            return (true, config, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting country specific config");
            return (false, new Dictionary<string, object>(), ex.Message);
        }
    }

    public async Task<List<CountryWorkProcess>> GetCountryWorkProcessesAsync(string countryCode)
    {
        try
        {
            var country = await _context.CountryEnvironments
                .Include(c => c.WorkProcesses)
                .FirstOrDefaultAsync(c => c.CountryCode == countryCode.ToUpper());

            return country?.WorkProcesses ?? new List<CountryWorkProcess>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving work processes for country {CountryCode}", countryCode);
            return new List<CountryWorkProcess>();
        }
    }

    public async Task<(bool success, string? error)> UpdateCountryWorkProcessAsync(string countryCode, CountryWorkProcess process)
    {
        try
        {
            var country = await _context.CountryEnvironments
                .FirstOrDefaultAsync(c => c.CountryCode == countryCode.ToUpper());

            if (country == null)
                return (false, $"Country '{countryCode}' not found");

            process.CountryEnvironmentId = country.Id;
            process.LastUpdated = DateTime.UtcNow;

            _context.CountryWorkProcesses.Add(process);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Updated work process for country {CountryCode}", countryCode);
            return (true, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating work process for country {CountryCode}", countryCode);
            return (false, ex.Message);
        }
    }
}
