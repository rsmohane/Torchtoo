namespace HumanAssist.Services;

using HumanAssist.Data;
using HumanAssist.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Reflection;

public interface ICodeGenerationService
{
    Task<(bool success, string code, string? error)> GenerateCodeAsync(string prompt, string language, int userId);
    Task<(bool success, string result, string? error)> ValidateCodeAsync(string code, string language);
    Task<(bool success, string result, string? error)> ExecuteCodeAsync(string code, int userId);
    Task<List<CodeGenRequest>> GetUserCodeRequestsAsync(int userId);
}

public class CodeGenerationService : ICodeGenerationService
{
    private readonly ApplicationDbContext _context;
    private readonly IAIService _aiService;
    private readonly ILogger<CodeGenerationService> _logger;

    public CodeGenerationService(
        ApplicationDbContext context,
        IAIService aiService,
        ILogger<CodeGenerationService> logger)
    {
        _context = context;
        _aiService = aiService;
        _logger = logger;
    }

    public async Task<(bool success, string code, string? error)> GenerateCodeAsync(string prompt, string language, int userId)
    {
        try
        {
            var request = new CodeGenRequest
            {
                UserId = userId,
                Prompt = prompt,
                Language = language,
                Status = "Processing",
                CreatedAt = DateTime.UtcNow
            };

            _context.CodeGenRequests.Add(request);
            await _context.SaveChangesAsync();

            var languagePrompt = $"Generate {language.ToUpper()} code for: {prompt}";
            var (success, code, error) = await _aiService.GenerateResponseAsync(languagePrompt, userId);

            if (success)
            {
                request.GeneratedCode = code;
                request.Status = "Completed";
                request.CompletedAt = DateTime.UtcNow;
            }
            else
            {
                request.Status = "Failed";
                request.ErrorMessage = error;
            }

            _context.CodeGenRequests.Update(request);
            await _context.SaveChangesAsync();

            return (success, code, error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Code generation error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string result, string? error)> ValidateCodeAsync(string code, string language)
    {
        try
        {
            if (language.ToLower() == "csharp" || language.ToLower() == "cs")
            {
                return ValidateCSharpCode(code);
            }

            var syntaxTree = CSharpSyntaxTree.ParseText("// Code validation");
            var root = syntaxTree.GetRoot();
            if (root == null)
                return (false, string.Empty, "Syntax error in code");

            return (true, "Code syntax is valid", null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Code validation error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<(bool success, string result, string? error)> ExecuteCodeAsync(string code, int userId)
    {
        try
        {
            // This is a simplified execution - in production, use a sandboxed environment
            var syntaxTree = CSharpSyntaxTree.ParseText(code);
            var root = syntaxTree.GetRoot();

            if (root == null)
                return (false, string.Empty, "Invalid code syntax");

            _logger.LogInformation("Code execution requested by user {UserId}", userId);
            
            return await Task.FromResult((true, "Code validated and would execute in isolated environment", (string?)null));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Code execution error");
            return (false, string.Empty, ex.Message);
        }
    }

    public async Task<List<CodeGenRequest>> GetUserCodeRequestsAsync(int userId)
    {
        return await _context.CodeGenRequests
            .Where(r => r.UserId == userId)
            .OrderByDescending(r => r.CreatedAt)
            .ToListAsync();
    }

    private (bool, string, string?) ValidateCSharpCode(string code)
    {
        try
        {
            var syntaxTree = CSharpSyntaxTree.ParseText(code);
            var root = syntaxTree.GetRoot();

            var hasErrors = syntaxTree.GetDiagnostics().Any(d => d.IsWarningAsError || d.Severity == Microsoft.CodeAnalysis.DiagnosticSeverity.Error);
            
            if (hasErrors)
            {
                var errors = string.Join("\n", syntaxTree.GetDiagnostics().Select(d => d.GetMessage()));
                return (false, string.Empty, errors);
            }

            return (true, "C# code is valid", null);
        }
        catch (Exception ex)
        {
            return (false, string.Empty, ex.Message);
        }
    }
}
