namespace HumanAssist.Services;

using System.Diagnostics;
using System.Text.Json;
using Microsoft.Extensions.Logging;

public interface IDependencyManagementService
{
    Task<(bool success, string output, string? error)> InstallNpmDependenciesAsync(string projectPath);
    Task<(bool success, string output, string? error)> InstallNuGetDependenciesAsync(string projectPath);
    Task<(bool success, string output, string? error)> InstallPythonDependenciesAsync(string projectPath);
    Task<(bool success, List<DependencyInfo> packages, string? error)> ListInstalledDependenciesAsync(string projectPath, string packageManager);
    Task<(bool success, DependencyInfo? package, string? error)> CheckDependencyVersionAsync(string packageName, string packageManager);
    Task<(bool success, string output, string? error)> UpdatePackagesAsync(string projectPath, string packageManager);
    Task<(bool success, string report, string? error)> AuditSecurityVulnerabilitiesAsync(string projectPath);
}

public class DependencyManagementService : IDependencyManagementService
{
    private readonly ILogger<DependencyManagementService> _logger;

    public DependencyManagementService(ILogger<DependencyManagementService> logger)
    {
        _logger = logger;
    }

    public async Task<(bool success, string output, string? error)> InstallNpmDependenciesAsync(string projectPath)
    {
        try
        {
            var result = await ExecuteCommandAsync("npm", "install", projectPath);
            if (!result.success)
                return (false, "", result.error);

            _logger.LogInformation("Successfully installed npm dependencies in {ProjectPath}", projectPath);
            return (true, result.output, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error installing npm dependencies");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, string output, string? error)> InstallNuGetDependenciesAsync(string projectPath)
    {
        try
        {
            var result = await ExecuteCommandAsync("dotnet", "restore", projectPath);
            if (!result.success)
                return (false, "", result.error);

            _logger.LogInformation("Successfully restored NuGet dependencies in {ProjectPath}", projectPath);
            return (true, result.output, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error installing NuGet dependencies");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, string output, string? error)> InstallPythonDependenciesAsync(string projectPath)
    {
        try
        {
            var result = await ExecuteCommandAsync("pip", "install -r requirements.txt", projectPath);
            if (!result.success)
                return (false, "", result.error);

            _logger.LogInformation("Successfully installed Python dependencies in {ProjectPath}", projectPath);
            return (true, result.output, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error installing Python dependencies");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, List<DependencyInfo> packages, string? error)> ListInstalledDependenciesAsync(string projectPath, string packageManager)
    {
        try
        {
            var (success, output, error) = packageManager.ToLower() switch
            {
                "npm" => await ExecuteCommandAsync("npm", "list --depth=0", projectPath),
                "dotnet" => await ExecuteCommandAsync("dotnet", "list package", projectPath),
                "pip" => await ExecuteCommandAsync("pip", "list", projectPath),
                _ => (false, "", "Unknown package manager")
            };

            if (!success)
                return (false, new List<DependencyInfo>(), error);

            var packages = ParseDependencies(output, packageManager);
            _logger.LogInformation("Listed dependencies from {PackageManager} in {ProjectPath}", packageManager, projectPath);
            return (true, packages, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing dependencies");
            return (false, new List<DependencyInfo>(), ex.Message);
        }
    }

    public async Task<(bool success, DependencyInfo? package, string? error)> CheckDependencyVersionAsync(string packageName, string packageManager)
    {
        try
        {
            var (success, output, error) = packageManager.ToLower() switch
            {
                "npm" => await ExecuteCommandAsync("npm", $"view {packageName} version", ""),
                "pip" => await ExecuteCommandAsync("pip", $"show {packageName}", ""),
                _ => (false, "", "Unknown package manager")
            };

            if (!success)
                return (false, null, error);

            var package = new DependencyInfo
            {
                Name = packageName,
                Version = output.Trim(),
                PackageManager = packageManager,
                InstalledAt = DateTime.UtcNow
            };

            _logger.LogInformation("Checked version for {PackageName}: {Version}", packageName, output.Trim());
            return (true, package, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking dependency version");
            return (false, null, ex.Message);
        }
    }

    public async Task<(bool success, string output, string? error)> UpdatePackagesAsync(string projectPath, string packageManager)
    {
        try
        {
            var (success, output, error) = packageManager.ToLower() switch
            {
                "npm" => await ExecuteCommandAsync("npm", "update", projectPath),
                "dotnet" => await ExecuteCommandAsync("dotnet", "add package --allow-pre-release", projectPath),
                "pip" => await ExecuteCommandAsync("pip", "list --outdated", projectPath),
                _ => (false, "", "Unknown package manager")
            };

            if (!success)
                return (false, "", error);

            _logger.LogInformation("Updated packages in {ProjectPath} using {PackageManager}", projectPath, packageManager);
            return (true, output, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating packages");
            return (false, "", ex.Message);
        }
    }

    public async Task<(bool success, string report, string? error)> AuditSecurityVulnerabilitiesAsync(string projectPath)
    {
        try
        {
            // Try npm audit
            var (npmSuccess, npmOutput, npmError) = await ExecuteCommandAsync("npm", "audit --json", projectPath);
            
            if (npmSuccess)
            {
                var auditData = JsonSerializer.Deserialize<JsonElement>(npmOutput);
                var vulnerabilities = auditData.TryGetProperty("metadata", out var metadata) 
                    ? metadata.GetProperty("vulnerabilities").GetProperty("total").GetInt32() 
                    : 0;

                _logger.LogInformation("Security audit completed: {Vulnerabilities} vulnerabilities found", vulnerabilities);
                return (true, $"Found {vulnerabilities} vulnerabilities in npm packages", null);
            }

            // Try dotnet audit
            var (dotnetSuccess, dotnetOutput, _) = await ExecuteCommandAsync("dotnet", "list package --vulnerable", projectPath);
            if (dotnetSuccess)
            {
                _logger.LogInformation("Security audit completed for .NET packages");
                return (true, dotnetOutput, null);
            }

            return (false, "", "No security audit tool available");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error auditing security vulnerabilities");
            return (false, "", ex.Message);
        }
    }

    private async Task<(bool success, string output, string error)> ExecuteCommandAsync(string command, string arguments, string workingDirectory)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = command,
                Arguments = arguments,
                WorkingDirectory = workingDirectory,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using var process = Process.Start(psi);
            if (process == null)
                return (false, "", "Failed to start process");

            var output = await process.StandardOutput.ReadToEndAsync();
            var error = await process.StandardError.ReadToEndAsync();

            await process.WaitForExitAsync();

            if (process.ExitCode != 0)
                return (false, output, error);

            return (true, output, "");
        }
        catch (Exception ex)
        {
            return (false, "", ex.Message);
        }
    }

    private List<DependencyInfo> ParseDependencies(string output, string packageManager)
    {
        var dependencies = new List<DependencyInfo>();

        var lines = output.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        foreach (var line in lines)
        {
            var parts = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length >= 2 && !line.StartsWith("npm") && !line.StartsWith("Package") && !line.StartsWith("---"))
            {
                dependencies.Add(new DependencyInfo
                {
                    Name = parts[0],
                    Version = parts[parts.Length - 1],
                    PackageManager = packageManager,
                    InstalledAt = DateTime.UtcNow
                });
            }
        }

        return dependencies;
    }
}

public class DependencyInfo
{
    public string Name { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
    public string PackageManager { get; set; } = string.Empty;
    public DateTime InstalledAt { get; set; }
    public bool IsOutdated { get; set; }
    public bool HasVulnerabilities { get; set; }
}
