using HumanAssist.Data;
using HumanAssist.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog for logging
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/app-.txt", rollingInterval: RollingInterval.Day)
    .MinimumLevel.Information()
    .Enrich.FromLogContext()
    .CreateLogger();

builder.Host.UseSerilog();

// Add services to the container
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configure JWT Authentication
var jwtSettings = builder.Configuration.GetSection("Jwt");
var secretKey = jwtSettings["SecretKey"] ?? "change-this-to-a-very-long-secret-key-minimum-32-characters";
var key = Encoding.ASCII.GetBytes(secretKey);

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = true,
        ValidIssuer = jwtSettings["Issuer"],
        ValidateAudience = true,
        ValidAudience = jwtSettings["Audience"],
        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };
})
.AddGoogle(options =>
{
    options.ClientId = builder.Configuration["Authentication:Google:ClientId"];
    options.ClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
})
.AddFacebook(options =>
{
    options.AppId = builder.Configuration["Authentication:Facebook:AppId"];
    options.AppSecret = builder.Configuration["Authentication:Facebook:AppSecret"];
})
.AddMicrosoftAccount(options =>
{
    options.ClientId = builder.Configuration["Authentication:Microsoft:ClientId"];
    options.ClientSecret = builder.Configuration["Authentication:Microsoft:ClientSecret"];
})
.AddTwitter(options =>
{
    options.ConsumerKey = builder.Configuration["Authentication:Twitter:ConsumerKey"];
    options.ConsumerSecret = builder.Configuration["Authentication:Twitter:ConsumerSecret"];
});

builder.Services.AddAuthorization();

// Register custom services
builder.Services.AddScoped<IEncryptionService, EncryptionService>();
builder.Services.AddScoped<IAuthenticationService, AuthenticationService>();
builder.Services.AddScoped<IAIService, AIService>();
builder.Services.AddScoped<ICodeGenerationService, CodeGenerationService>();
builder.Services.AddScoped<IApiKeyService, ApiKeyService>();
builder.Services.AddScoped<IApiKeyMonitoringService, ApiKeyMonitoringService>();
builder.Services.AddScoped<IInstructionService, InstructionService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<ISupportService, SupportService>();
builder.Services.AddScoped<IEnvironmentService, EnvironmentService>();
builder.Services.AddScoped<ITranslationService, TranslationService>();
builder.Services.AddScoped<IGeolocationService, GeolocationService>();
builder.Services.AddScoped<IAudioService, AudioService>();
builder.Services.AddScoped<IImageService, ImageService>();
builder.Services.AddScoped<IImageEditingService, ImageEditingService>();
builder.Services.AddScoped<IAdvancedLanguageService, AdvancedLanguageService>();
builder.Services.AddScoped<IMultiEnvironmentService, MultiEnvironmentService>();
builder.Services.AddScoped<IMultiEnvironmentConfigurationService, MultiEnvironmentConfigurationService>();
builder.Services.AddScoped<IAdvancedImageEditingService, AdvancedImageEditingService>();
builder.Services.AddScoped<IAdvancedTranslationService, AdvancedTranslationService>();
builder.Services.AddScoped<ISoundReplacementService, SoundReplacementService>();
builder.Services.AddScoped<ICountryEnvironmentService, CountryEnvironmentService>();
builder.Services.AddScoped<ICognitiveSkillsService, CognitiveSkillsService>();
builder.Services.AddScoped<IWorkProcessManagementService, WorkProcessManagementService>();
builder.Services.AddScoped<IGoogleApiIntegrationService, GoogleApiIntegrationService>();
builder.Services.AddScoped<IGitHubIntegrationService, GitHubIntegrationService>();
builder.Services.AddScoped<IDependencyManagementService, DependencyManagementService>();
builder.Services.AddScoped<ICodeReviewService, CodeReviewService>();
builder.Services.AddHttpClient();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "GRT HumanAssist Platform API",
        Version = "v1",
        Description = "Advanced AI-powered human assistance platform by GRT Assist 369 Automations and Security Pvt Ltd. Comprehensive platform with social authentication, multi-environment support, and industry-grade security."
    });
    
    // Add JWT Bearer definition
    c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "JWT Authorization header"
    });
    
    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] { }
        }
    });
});

// CORS configuration
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Human Assist Platform API v1");
    });
}

app.UseHttpsRedirection();
app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

// Apply migrations on startup and seed initial admin user
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.Migrate();

    // create default admin account if configuration present
    var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();
    var authService = scope.ServiceProvider.GetRequiredService<IAuthenticationService>();

    var adminEmail = configuration["Admin:Email"];
    var adminPassword = configuration["Admin:Password"];

    if (!string.IsNullOrEmpty(adminEmail) && !string.IsNullOrEmpty(adminPassword))
    {
        var existing = db.Users.FirstOrDefault(u => u.Email == adminEmail);
        if (existing == null)
        {
            var registerResult = authService.RegisterAsync(adminEmail, adminPassword, "System", "Administrator").GetAwaiter().GetResult();
            if (registerResult.success && registerResult.user != null)
            {
                registerResult.user.Role = "Admin";
                db.Users.Update(registerResult.user);
                db.SaveChanges();
            }
        }
    }
}

app.Run();
